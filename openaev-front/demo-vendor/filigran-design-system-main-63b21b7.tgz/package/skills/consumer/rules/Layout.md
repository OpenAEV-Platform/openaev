# Layout — platform shell contract (mandatory)

> **Cross-cutting rule, not a component.** Normalizes how a Filigran product
> composes its application shell. **Mandatory reading before any page-level
> layout work**, for every product (OpenCTI, OpenAEV, XTM CRQ, XTM One, XTM Hub),
> whatever components you use.
>
> **Self-contained by design.** Every value below is either a shipped token you
> reference or a layout constant stated here. You do not need any external design
> source: this file is the concrete, ready-to-apply projection. Use the tokens
> from the `@filigran/design-system/tokens/theme.css`
> that shipped with your installed version — when this file disagrees with that
> `theme.css` (or the shipped `llms-full.txt`), those win.

## Invariants — never break these

1. **Never hand-roll the shell.** Top bar = library `Header` (+ `HeaderGroup`);
   side nav = library `Navbar` (+ `NavbarItem` / `NavbarSubmenu` / …). Do not
   rebuild either with raw markup ("never fork").
2. **Two fixed zones + a residual one, plus one conditional.** Navbar (left)
   and Header (top) are `position: fixed`, out of the grid. Content is the
   **residual, in-flow space** and the **only page-level scrollable zone** — it
   never overlaps Navbar/Header. (Component-owned internal scroll is separate:
   the `Navbar` scrolls its own nav-list, which the library owns — you neither
   add nor remove it.) Zone 4 *Secondary navigation* is conditional: **below the
   Header**, right of the Content, full Content height, `position: fixed` (does
   not scroll). It is built with `Navbar` + `NavbarItem` (whose items may carry
   `NavbarSubmenu`) — **not** the `Menu` component, which is an action/command
   dropdown, never persistent navigation.
3. **12-column grid, token-bound spacing.** The Content uses a 12-col grid at
   every breakpoint. All margins / gutters / padding / gap must reference the
   spacing tokens recensed below — **raw `px` is forbidden** in layout code.
4. **Overlays layer above the shell.** Drawer / Dialog / Tooltip layer
   over the shell and never reorganise zones — their geometry belongs to their
   own component systems, not to page code.
5. **Dark mode is class-based.** Toggle `.dark` / `.light` on the root; never
   `prefers-color-scheme`.

## The shell

```
┌───────────────┬───────────────────────────────────┐
│ Navbar (fixed)│  Header (fixed, full width)        │
│               ├────────────────────────┬──────────┤
│  nav links    │  Content (in-flow,     │ 2nd nav  │
│  (scroll)     │  residual, the only    │ (Navbar  │
│               │  scroll) · 12-col grid │  Item,   │
│  nav footer   │  left = navbar width   │  fixed)  │
└───────────────┴────────────────────────┴──────────┘
```

- **Ownership.** Header owns its height/surface/hairline/padding/distribution;
  Navbar owns its width/background/collapse/toggle. The product supplies only the
  page positioning they don't ship (fixed `top`/`right` + dynamic `left`). The
  **one** legitimate inline `style` is that `left` offset (tracks Navbar
  collapse). Any hardcoded design value in `style={{}}` is a defect.
- **Offsets track the components at runtime.** Header/Content `left` follows the
  Navbar's live collapsed width, and Content's top offset follows the height the
  `Header` publishes. Both dimensions are owned by their components — never
  restate the navbar width or the header height, as a literal or as a token.

## Tokens you must use (recensed — shipped in `theme.css`)

| Purpose | Use | Never |
|---|---|---|
| Content padding | spacing utility `p-6` (the `--spacing-*` scale) | a literal `24px` |
| Shared shell surface | `bg-gradient-default` utility class | an inline gradient |
| Header hairline | `border-b border-elevation-subtle` | the Navbar has **no** border |
| Grid margins / gutters / gap | spacing utilities `p-*` / `gap-*` on the `--spacing-*` scale | raw `px` or non-shipped token names |
| Any other layout spacing | the `--spacing-*` scale | raw `px` |

The Navbar's own width is owned by the `Navbar` component — you do not set it and
do not restate it; the Header/Content `left` offset follows it at runtime.

## Display modes & breakpoints

- **Fluid** (default): Content fills the available width.
- **Contain**: capped, centred max-width — **explicit only**, for text-heavy
  surfaces; applies at ≥1536 and up (fluid below).
- **Reference format:** desktop-large **1728px**. Desktop-only B2B — the
  Fluid/Contain breakpoints above are the whole responsive contract; **no
  mobile/tablet rules** (out of scope).

## Thresholds (layout constants — no token by design)

| Rule | Value |
|---|---|
| Min screen width before horizontal scroll | `1080px` — below it, Content goes fixed-width + global horizontal scroll; Navbar/Header unaffected, shell never compresses |
| Content min-width (no secondary menu) | `880px` |
| Content min-width (with secondary menu) | `680px` |

## Checklist

1. Compose from `Navbar` + `Header` + an in-flow, residual Content that is the
   only scrolling zone — never hand-rolled markup; add a secondary-navigation
   column (Zone 4, below the Header) built from `Navbar` + `NavbarItem`
   (with `NavbarSubmenu` for nested items) only when secondary nav is required —
   never the `Menu` component.
2. Navbar/Header (and the secondary-nav column when present) are
   `position: fixed`; Content is
   residual, in-flow and the only **page-level** zone that scrolls (the Navbar's
   own nav-list scroll is component-owned); Content is a 12-col grid.
3. Header/Content `left` tracks the Navbar's live collapsed width; Content's top
   offset follows the Header's own height — restate neither.
4. Spacing from the recensed tokens only — no raw `px`, no inline gradient (use
   `bg-gradient-default`).
5. Overlays (Drawer/Dialog/Tooltip) above the flow, via their components.
6. Dark mode via `.dark`/`.light`; below `1080px` scroll rather than compress.
