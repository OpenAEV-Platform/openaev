# Input — usage contract

- **Component:** `Input` · **Package:** `@filigran/design-system`
- **Source of truth:** `Input.rfc.md` + `Input.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** none (native `<input>` + FDS tokens)

> Read this before using `Input`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { InputMeta } from "@filigran/design-system/meta"`.

## Intent

The base **single-line text field** of the design system — the equivalent of MUI
`TextField` and `@filigran/ui` `Input`. It wraps a native `<input>` styled with
the `--*-input-*` token family and bundles the standard field anatomy: optional
label, required marker, info icon, helper/error text, optional character-limit
counter, an optional leading decorative `startIcon`, and an optional trailing
`endIcon` slot (decorative icon or interactive `<IconButton>`). Core `type`
scope is `text` / `password` / `number` / `email`.

## Composition

Standalone component, no sub-components. Label, required marker, info icon,
helper/error text and counter are rendered internally from props and wired for
accessibility. The `endIcon` slot **composes the FDS `<IconButton>`** when
`type: "iconButton"` (the one cross-component composition). `startIcon` is a
plain decorative `ReactNode`. `Input` forwards its ref directly to the native
`<input>` (no wrapper div between ref and DOM node) — required for
react-hook-form's `register()` / `Controller` and for `focus()` / `select()`.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<TextField label="Name" />` | `<Input label="Name" />` | |
| `<TextField value={v} onChange={fn} />` | `<Input value={v} onChange={fn} />` | Native event passthrough |
| `<TextField required />` | `<Input required />` | Renders `*` + `aria-required` |
| `<TextField type="password" />` | `<Input type="password" endIcon={{type:"iconButton", …}} />` | Visibility toggle via `endIcon` |
| `<TextField type="number" />` | `<Input isTypeNumber />` | Native spinbutton + drawn stepper |
| `<TextField error helperText="msg" />` | `<Input error="msg" />` | `error` string carries the message |
| `<TextField helperText="hint" />` | `<Input helperText="hint" />` | |
| `<TextField disabled />` | `<Input disabled />` | |
| `<TextField placeholder="…" />` | `<Input placeholder="…" />` | |
| `<TextField fullWidth />` | `<Input />` | Width intrinsic — drop the prop |
| `<TextField variant="outlined" />` | `<Input />` | Drop — single FDS style |
| `<TextField size="small" />` | `<Input />` | Drop — single FDS size |
| `<TextField multiline rows={3} />` | `<Textarea rows={3} />` | Separate component |
| `<TextField InputProps={{ endAdornment: <Icon/> }} />` | `<Input endIcon={{type:"icon"\|"iconButton", …}} />` | Single trailing slot |
| `<TextField InputProps={{ startAdornment: <Icon/> }} />` | `<Input startIcon={<Icon/>} />` | Decorative only |
| `@filigran/ui <Input />` | `<Input />` | Direct 1:1 |

## Accessibility notes

- Native `<input>`. When `label` is provided a `<label htmlFor>` is associated;
  when omitted, an `aria-label`/`aria-labelledby` **must** be passed. `required`
  sets `aria-required`; `error` sets `aria-invalid` and links the message via
  `aria-describedby` (a consumer-provided `aria-describedby` is merged, not
  replaced). The trailing state icon is decorative — meaning is carried by text
  + `aria-invalid`, never color/icon alone.
- Keyboard is native. With `isTypeNumber` the field is a native `spinbutton`:
  `ArrowUp`/`ArrowDown` step by `step` and clamp at `min`/`max`; the two drawn
  arrows carry `tabIndex={-1}` (the focused input already offers that path) and
  no focus ring.
- `endIcon` a11y: `type: "iconButton"` requires an accessible `label`; `type:
  "icon"` is decorative and `aria-hidden`. Focus uses the standard ring. Full
  contrast pairs are in `InputMeta`.

## Behavior

- **Responsive:** intrinsic width (100% of container), no breakpoints; height and
  typography fixed. Long values scroll horizontally within the field (native).
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic.

## Usage rules

- **Label is mandatory** — always provide `label`, `aria-label`, or
  `aria-labelledby`.
- **`error` is a string, not a boolean** — when set, the message is mandatory and
  replaces any `helperText`. Never signal error by border/icon color alone.
- **`success`** is decorative confirmation only — not a blocking/validation state
  for assistive tech.
- **`endIcon`** carries a trailing action or decorative icon (password toggle,
  askAI trigger, copy-to-clipboard…). Use `type: "iconButton"` for interactive
  actions (requires an accessible `label`) and `type: "icon"` for decorative
  only — never make a `type: "icon"` clickable. When `error`/`success` is active
  the state indicator masks/replaces `endIcon` (no coexistence). `Input` has no
  built-in "copied!" feedback — build transient confirmation yourself.
- **No multiline** — use the separate `Textarea` component.
- **No `variant` / `size` / `fullWidth`** — single style, single 36px size,
  intrinsic width.
- **Character counter** — when `maxLength` is set, always render the `N/max`
  counter in the helper row rather than emulating it in `helperText`.
- **Value binding** — bind `value` / `onChange` as native controlled/uncontrolled
  props; keep `Input` decoupled from any form library (bind Formik / RHF at the
  wrapper level).
- Style overrides go only through `className` — no `sx` / inline `style`.

## Out of scope — do not reach for Input here

| Need | Use instead |
|---|---|
| multiline entry (`multiline` / `rows`) | `Textarea` |
| `type="file"` | `FileSelect` / File input |
| datepicker / time / color inputs | dedicated components |
| an arbitrary multi-adornment system | the two slots (`startIcon` + `endIcon`) only |
| `variant` / `size` / `fullWidth` | single style, single size, intrinsic width |
| `sx` / `style` | `className` |
| a search variant | `SearchField` |
| a dropdown field | `Select` (single) / `Combobox` (single or `multiple`) |
