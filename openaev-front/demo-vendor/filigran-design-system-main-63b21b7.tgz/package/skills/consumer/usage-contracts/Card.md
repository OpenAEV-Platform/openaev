# Card — usage contract

- **Component:** `Card` · **Package:** `@filigran/design-system`
- **Source of truth:** `Card.rfc.md` + `Card.meta.ts` (this file is a published
  subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** none (a card has no behaviour of its own; it composes on
  `Paper`)

> Read this before using `Card`. It carries the rules the TypeScript types do not
> encode. For exact prop names/types and contrast pairs, also read
> `import { CardMeta } from "@filigran/design-system/meta"`.

## Intent

Card is the composed surface that sits on top of `Paper`. It adds an anatomy —
media, header, title, subtitle, content, footer, meta strip — and one explicit
whole-surface interaction. It declares **no** surface, **no** typography and
**no** spacing of its own (those come from Paper and `Text`). One set of optional
parts covers every observed anatomy (entity, marketplace, object, headline,
media, stat).

The design rule: **what varies in STRUCTURE composes; what varies in APPEARANCE
is a prop.**

## Usage rules

- **RULE-01 — Card composes on Paper.** A surface with no anatomy is a `Paper`,
  not a Card.
- **RULE-02 — A section title above the surface is Paper's `title`,** not a Card.
- **RULE-03 — Interactivity is declared on the root, never inferred.**
- **RULE-04 — The card's accessible name is its title.**
- **RULE-05 — Card never fixes a height** (the host's grid owns height).
- **RULE-06 — `disabled` only exists on an interactive card.**

## Composition

Compound. Parts — all optional, all combinable, no fixed order:
`CardHeader` (slots `icon`, `action`) · `CardTitle` (slot `endAdornment`) ·
`CardSubtitle` (slot `endAdornment`) · `CardContent` · `CardFooter` ·
`CardMetaBar`. A card with no header is valid; with no footer too. The media
band has **no library part** — the host supplies its own `<img>` in a Card at
`padding={0}`; there is no `CardMedia` component.

**Making a card clickable:** the link is carried by the TITLE and wired by the
ROOT. Declare intent once on the root (`<Card href>` or `onClick`); `CardTitle`
renders the anchor and stretches it over the whole surface, and every interactive
descendant (header action slot, footer, meta) is lifted above that overlay. The
result is ONE control whose accessible name is the title — not a `<button>`
wrapping `<div>`s. `href` with no `CardTitle` warns in development.

Root props: `elevation` (`0|1|2|3`), `padding` (`0|8|16|24|32`) — both
pass-through to Paper — plus `href`, `onClick`, `selected`, `disabled`. Hover and
focus are browser states painted by the root, not props.

## Accessibility notes

- The root is a `Paper` `<div>` with no role — a card is not a landmark.
- The single control is a real `<a href>` or `<button type="button">`; its
  accessible name comes from the title.
- `disabled` renders the title as text, not as a dead link.
- Colour is never the only cue for selection — a Checkbox in the header carries
  it; hover and selected paint the same surface couple by design.
- Focus ring: the library's standard pattern, painted on the whole surface. Full
  contrast pairs are in `CardMeta`.

## Behavior

Intrinsic sizing, no breakpoints, no height. Same structure in both themes,
tokens switched by `.dark` / `.light`, no conditional logic. Pointing at a nested
control drops the card highlight rather than promising a click that control will
intercept.

## Out of scope — do not reach for Card here

| Need | Use instead |
|---|---|
| accent banner with overhanging avatar | not in v1 |
| hover lift and shadow | not applicable (hover is background + border) |
| imposed / fixed heights | the host's grid owns height |
| dense row variant | that is a `List` |
| accent-border selection | the node's `selected` state |
| key/value block as a part | host-composed in v1 |
| a section panel with an external title | `Paper`'s `title` / `action` |
