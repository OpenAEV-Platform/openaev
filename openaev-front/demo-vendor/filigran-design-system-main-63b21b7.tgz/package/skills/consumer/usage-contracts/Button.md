# Button — usage contract

- **Component:** `Button` · **Package:** `@filigran/design-system`
- **Source of truth:** `Button.rfc.md` + `Button.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-slot` (enables `asChild`)

> Read this before using `Button`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { ButtonMeta } from "@filigran/design-system/meta"`.

## Intent

The primary interactive control for **triggering actions** (submit, confirm,
cancel, destructive). It **always represents an action** — never navigation,
state display, or content selection. A Button must not duplicate the function of
a link, accordion, tab or tile.

Structured on three axes:
- **priority** — visual weight: `primary` / `secondary` / `tertiary`
- **variant** (type) — semantic nature: `default` / `destructive` / `ia` / `highlight`
- **size** — `md` (default) / `sm`

## Usage rules

- **RULE-01 — Label is mandatory.** Buttons almost always have a text label.
  Icon-only is acceptable only under strict space limits — never the default;
  use `IconButton` for that. Keep labels short: a verb, or verb + noun ("Edit
  Scenario", not "Scenario Details"). Single nouns ("Views", "Options") are fine
  when no verb applies.
- **RULE-02 — Icon placement.** An icon goes to the **left** of the label. Icon
  on the right only when the button opens a menu (dropdown trigger) or opens/links
  an external resource. **One icon max** per button.
- **RULE-03 — No icons in system controls.** No icons on buttons in menus,
  modals, dialogs, messages, or any system-like button set.
- **RULE-04 — Priority × type constraints.** Not all combinations are valid:
  **no `primary` for `ia` and `highlight`** (primary weight is reserved for
  `default`/`destructive`). Info / Success / Warning / Alert are **not** Button
  types — they are a notification color overlay owned by the Notification
  component; do not add them to Button's props or types.
- **RULE-05 — Primary density.** Limit primary buttons on screen: 1 ideal, 2 max.
  Never two primary (solid) buttons next to each other. Place the primary to the
  **right** of the secondary.
- **RULE-06 — Grouping.** No more than 3 buttons side by side; beyond that,
  consolidate into a group or use action icons. Never mix sizes within a set.
- **RULE-07 — Tertiary usage.** Use `tertiary` sparingly — its contexts are
  menus, modals, and system-like controls, or when several levels of action
  importance coexist on one surface.
- **RULE-08 — Action prioritization.** Each screen has a clear primary-action
  hierarchy; too many calls to action create confusion.

## Composition

Standalone component, no sub-components. It also exports `buttonVariants` (a cva
function) to apply Button styling to a **non-Button** element via
`cn(buttonVariants({ ... }), className)` — use for styling a `<Link>` or an
accordion trigger without instantiating `<Button>`. For a real link that looks
like a button, prefer `<Button asChild><a href="…">…</a></Button>` so the
semantic element is the `<a>`.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Button variant="contained" color="primary">` | `<Button priority="primary">` | `variant` can be omitted (default) |
| `<Button variant="outlined" color="secondary">` | `<Button priority="secondary">` | |
| `<Button variant="text">` | `<Button priority="tertiary">` | |
| `<Button variant="contained" color="error">` | `<Button variant="destructive" priority="primary">` | |
| `<Button startIcon={<Icon/>}>` | `<Button startIcon={<Icon/>}>` | same API |
| `<Button size="small">` | `<Button size="sm">` | rename |
| `<Button size="medium">` / `"large"` | `<Button size="md">` | no large button in FDS |
| `<Button disabled>` | `<Button disabled>` | native HTML |
| `<Button component="a" href="…">` | `<Button asChild><a href="…">…</a></Button>` | Radix `asChild` |
| `<LoadingButton loading>` | `<Button loading>` | built-in prop, no separate component |
| `<Button fullWidth>` | `<Button fullWidth>` | same API |
| `<Button sx={{…}}>` | `<Button className="…">` | Tailwind classes only — no `sx`/`style` |
| `buttonClasses` (theme overrides) | `buttonVariants()` | cva export, with `cn()` |
| opengrc `<Button variant="outline">` | `<Button priority="secondary">` | |
| opengrc `<Button variant="default">` | `<Button priority="primary">` | |

## Accessibility notes

- Renders a native `<button>`. With `asChild`, styles merge onto the child and
  the semantic element becomes the child's (e.g. `<a>` for navigation).
- Keyboard: native — `Tab` to focus, `Enter`/`Space` to activate. No deviation.
- The `ia` and `highlight` variants render **gradient text on a neutral
  background**; contrast is verified per gradient stop. The `highlight` label
  is the gradient in **both** modes. Never restore a solid label or add a
  mode-scoped `text-*` override: the light-mode solid label was retired on
  2026-10-20, when the gradient's end stop moved to a token that passes.
  Full contrast pairs are in `ButtonMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints; adapts to content (inline-flex).
  `fullWidth` forces `width: 100%` of the parent.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic in the component. `ia` / `highlight` gradients have different
  stops per mode.

## Out of scope — do not reach for Button here

| Need | Use instead |
|---|---|
| `color` prop (MUI) | the `variant` axis |
| `sx` / `style` overrides | `className` (Tailwind) |
| `component` prop (MUI) | `asChild` + child element |
| gradient props (opencti wrapper) | the `ia` / `highlight` variants |
| icon-only button | `IconButton` |
| selected / toggle button | `ToggleButton` (roadmap) |
| `href` / `to` navigation | `asChild` + `<a>` / `<Link>` |
| a row of related buttons | `ButtonGroup` |
| ripple / elevation toggles | not applicable (no ripple in FDS) |
