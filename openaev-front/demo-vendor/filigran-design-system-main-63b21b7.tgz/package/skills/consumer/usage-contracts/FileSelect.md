# FileSelect — usage contract

- **Component:** `FileSelect` · **Package:** `@filigran/design-system`
- **Source of truth:** `FileSelect.rfc.md` + `FileSelect.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** none — built on a hidden native `<input type="file">`

> Read this before using `FileSelect`. It carries the rules the TypeScript types
> do not encode. For exact prop names/types and contrast pairs, also read
> `import { FileSelectMeta } from "@filigran/design-system/meta"`.

## Intent

A field for choosing one or several local files, wrapping a hidden native
`<input type="file">` behind an FDS-styled trigger. It carries an integrated
label, helper text, an optional size counter, optional MIME/size validation, a
clear control, and — in `multiple` mode — a chip list of the selected files. It
is the design-system home for the near-duplicate `CustomFileUploader` /
`FileField` wrappers products ship today.

## Composition

Standalone component, no exported sub-components. Internally composed from:
`<Button>` (the "Select your file(s)" trigger), `<IconButton>` (the clear `×`
control and each chip's delete), `<Chip>` (one per file in `multiple` mode),
`<Spinner>` (loading), `<Tooltip>` (info icon and truncated long-error), and a
visually hidden native `<input type="file">` (the actual picker).

## Migration from MUI

File upload is a product-custom abstraction, not a MUI component; the mapping is
from the existing product wrappers:

| Product usage | FDS equivalent | Notes |
|---|---|---|
| opencti `<CustomFileUploader setFieldValue label acceptMimeTypes sizeLimit formikErrors required />` | `<FileSelect onValueChange={f => setFieldValue('file', f)} label accept maxSize error={e.file} required showSizeCounter />` | Formik glue moves to the consumer's `onValueChange` |
| openaev `<CustomFileUploader name fieldOnChange label acceptMimeTypes sizeLimit errors />` | `<FileSelect name onValueChange label accept maxSize error={errors[name]} showSizeCounter />` | RHF glue via `onValueChange` |
| openaev `<FileField name filters={[…]} />` (multi) | `<FileSelect name multiple accept="…" onValueChange />` | `filters` substring → `accept` MIME |
| `<VisuallyHiddenInput type="file">` inside a `Button component="label"` | internal to `<FileSelect>` | Hidden native input is now encapsulated |
| `noFileSelectedLabel="…"` | `placeholder="…"` | Rename — same empty-state caption |
| `onChange={(key, file) => …}` | `onValueChange={file => …}` | Single callback |

## Accessibility notes

- The picker is a real `<input type="file">`, visually hidden (not
  `display:none`) so it stays focusable/labelable, associated to the label via
  `htmlFor`/`id` (auto-generated when `id` is absent). `accept`, `multiple`,
  `disabled`, `name` map to native attributes. `required` does **not** set the
  native `required` attribute (deliberately — on the visually-hidden,
  `tabIndex=-1` input Chromium anchors its validation bubble to an invisible box
  and can block submission with no visible message); it emits `aria-required`
  and the empty/rejected state is surfaced in-field instead.
- The trigger is a native `<button>`; activating it opens the OS dialog. The
  paperclip icon is decorative (`aria-hidden`).
- `error` sets `aria-invalid` and `aria-describedby`; the message is a visible
  in-field cue (color is never the sole indicator). Long errors are truncated
  visually but exposed in full via `<Tooltip>` and the accessible description.
- `loading` sets `aria-busy` and announces via an sr-only `role="status"`; the
  trigger is made **inert** with `aria-disabled` (not the native `disabled`
  attribute) so keyboard users keep their tab stop.
- Clear and chip-delete controls carry `aria-label`s. Full contrast pairs are in
  `FileSelectMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints; takes container width (`w-full`).
  Single filename truncates (+ Tooltip); `multiple` chips wrap to further rows,
  growing the field height.
- **Size counter:** when `maxSize` is set, `used` is the aggregate size of the
  selection, `max` is `maxSize`; empty renders `0/max`, and `used` renders `-`
  while loading.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic.

## Usage rules

- **Label is mandatory** — provide `label`, `aria-label`, or `aria-labelledby`.
  The `placeholder` ("No file selected.") is the empty-state caption, not a label.
- **`error` is a message string, not a flag** — its presence is the error state.
  It shows in-field when no file is selected, or moves to the (always-visible,
  recolored) helper row when chips occupy the in-field slot. Never signal error
  by border/icon color alone.
- **Rejected picks are surfaced, never swallowed** — a wrong-MIME or over-`maxSize`
  pick is rejected: the field keeps its previous value, fires `onReject(rejections)`,
  and renders a built-in message. In `multiple`, accepted files still emit via
  `onValueChange` while rejected ones go to `onReject`. A consumer `error` string
  always wins over the built-in rejection message.
- **Helper doubles as the accepted-formats hint** (e.g. "PNG, JPG — 12 Mb max")
  and stays visible in every state.
- **Size counter** — when `maxSize` is set, render the `used/max` counter via
  `showSizeCounter` rather than emulating it in `helperText`.
- **Multiple vs single** — single draws the filename as in-field text emptied via
  the global clear; multiple draws one removable `<Chip>` per file. In `multiple`
  a later pick **adds** to the selection. Use `multiple` only when several files
  are genuinely accepted; default is single.
- **Clear control** renders only when a selection exists (no disabled state) and
  empties the whole selection.
- **Value binding** — bind `value` / `onValueChange` as native controlled/
  uncontrolled props; keep FileSelect decoupled from any form library (bind
  Formik / RHF / final-form at the product wrapper level).
- Style overrides go only through `className` — no `sx` / inline `style`.

## Out of scope — do not reach for FileSelect here

| Need | Use instead |
|---|---|
| drag-and-drop / bulk import | the separate dialog-based importers (e.g. `ImportFilesDropzone`) |
| read-only file field | not supported |
| per-file size inside chips | aggregate `used/max` counter only |
| substring type `filters` | `accept` (MIME) |
| `size` / `variant` axes | single size, single style |
| upload progress bar (%) | not supported — `loading` is an indeterminate Spinner |
