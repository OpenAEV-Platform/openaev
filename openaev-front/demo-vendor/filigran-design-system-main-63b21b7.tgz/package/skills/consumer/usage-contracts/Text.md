# Text — usage contract

- **Component:** `Text` · **Package:** `@filigran/design-system`
- **Source of truth:** `Text.rfc.md` + `Text.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved

> Read this before using `Text`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { TextMeta } from "@filigran/design-system/meta"`.

## Intent

`Text` is the design system's typography primitive. It renders any of the 19
arbitrated Named Styles while deliberately **decoupling the HTML tag from the
visual style**: the `as` prop picks the semantic element (an intrinsic tag like
`h1`, `p`, `span`, `label`, or a custom component), the `variant` prop
independently picks the Named Style. The two are orthogonal — you set them
together on nearly every usage, and neither is derived from the other (an `h1`
can carry any visual scale). It is the primary migration vehicle for the ~227
opencti and 147 openaev files rendering `<Typography>` from MUI.

## Edge cases seen in products

- **Real `as`/`variant` decoupling already exists in the wild** — several openaev
  sites hand-roll exactly what `Text` formalizes (`variant="h1" component="div"`,
  `variant="caption" component="div"`, `variant="body2" component="span"`): they
  want a style without its default tag.
- **11% of usages omit `variant` entirely**, silently relying on MUI's `body1`
  default. `Text`'s `variant` is a **required** prop (no silent default) — an
  explicit-over-implicit choice; migration must make the choice explicit.
- No wrapper/abstraction component sits on top of `<Typography>` — usages are direct.

## Composition

Standalone component. No sub-components, no compound pattern.

**Divergence from the `asChild` convention.** Other polymorphic components in this
repo (`Button`, `TooltipTrigger`) use Radix's `asChild`/`Slot` pattern. `Text`
deliberately does **not**: `asChild` conflates rendering delegation with tag choice
and cannot express "pick `h3` here, `span` there" as a typed, per-usage prop. `Text`
uses an `as`-with-generics pattern instead — a genuinely new convention in this repo.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Typography variant="h1">` | `<Text as="h1" variant="title-2xl">` | Size jump 22px→32px, weight 400→500 — intentional |
| `<Typography variant="h2">` | `<Text as="h2" variant="title-xl">` | Size jump 16px→28px |
| `<Typography variant="h3">` | `<Text as="h3" variant="title-lg">` | Size jump 13px→24px (highest-volume variant) |
| `<Typography variant="h4">` | `<Text as="h4" variant="title-md">` | Size + font jump |
| `<Typography variant="h5">` | `<Text as="h5" variant="title-sm">` | Exact visual match |
| `<Typography variant="h6">` | `<Text as="h6" variant="title-xs">` | Exact visual match |
| `<Typography variant="subtitle1">` / `subtitle2` | `<Text as="p" variant="content-highlight">` | ⚠️ MUI defaults `subtitle1` to `<h6>`; FDS default is `<p>` — a deliberate semantic improvement. Pass `as="h6"` only where it genuinely is a heading |
| `<Typography variant="body1">` | `<Text as="p" variant="content-base">` | No delta |
| `<Typography variant="body2">` | `<Text as="p" variant="content-compact">` | ~1px delta, negligible |
| `<Typography variant="caption">` | `<Text as="span" variant="content-caption">` | Visual-checkpoint a few call sites before bulk migration |
| `<Typography variant="overline">` | *(not applicable — dead variant)* | 0 confirmed real usages |
| `<Typography variant="button">` | *(not applicable)* | this text role belongs to `Button` |
| `<Typography component="X" variant="Y" ...>` | `<Text as="X" variant="{Y mapped per above}">` | Preserve an explicit `component` override into `as`; the visual `variant` always follows this table |
| *(no variant prop, implicit `body1`)* | `<Text as="p" variant="content-base">` | migration must make the choice explicit |

## Accessibility notes

- With an **intrinsic tag** (the default per variant, or an `as="h3"`-style
  override), `Text` renders exactly that one native HTML element and its native
  semantics apply as-is (e.g. `as="h3"` participates in the heading outline like a
  hand-written `<h3>`). No ARIA role is added or implied, and semantics are never
  inferred or overridden from `variant`.
- With a **consumer-owned custom component** (`as={MyLink}`), the rendered output
  and its accessibility/keyboard behavior are whatever that component renders —
  `Text` cannot guarantee a single native element or native semantics, and the
  custom component is responsible for forwarding `className` and `ref` onto its
  own root.
- Keyboard: native, no deviation. If rendered `as="a"`/`as="button"`, the browser's
  native keyboard behavior for that element applies.
- `content-highlight`'s default tag is `p`, not MUI subtitle's `h6` — avoids spurious
  headings.
- `content-button`'s default tag is `span`, never `button` — prevents a `Text`
  instance from masquerading as a non-interactive fake button. Real CTAs must use
  `Button`.
- `Text` sets no colour of its own; documented recommended token pairs (e.g.
  `--text-default-primary` on `--bg-elevation-default`) are in `TextMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints. Font sizes come from fixed token values
  per Named Style; `Text` does not implement responsive type scaling.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic. `Text` sets no colour itself, so dark/light behavior is inherited
  from whatever colour the consumer applies via `className`.

## Usage rules

- Always pass `variant` explicitly (no default) — pick the Named Style first, then
  only override `as` when the default tag doesn't match the real semantic outline.
- Don't nest a `Text` inside another `Text` — each renders exactly one element;
  compose adjacent `Text` siblings instead.
- Prefer the default `as` for each `variant` unless there's a genuine document-outline
  reason to override it. Silently forcing `as="h1"` everywhere for SEO/visual reasons
  defeats the decoupling this component exists for.
- `content-button`'s text role is reserved for `Button`'s internal label rendering —
  don't reach for `Text` to hand-roll a button-styled clickable element.

## Out of scope — do not reach for Text here

| Need | Use instead |
|---|---|
| `color` prop | `className` (Tailwind) |
| `align` prop | `className="text-*"` |
| `noWrap` prop | `className="truncate"` |
| `gutterBottom` prop | `className="mb-*"` |
| `sx` prop | `className` |
| `asChild` / Radix Slot pattern | the `as` prop (explicit divergence) |
| Any icon / badge / adornment slot | not applicable — v1 is text-only |
| Responsive / fluid type scaling | intrinsic sizing only |
| A styled clickable element | `Button` |
