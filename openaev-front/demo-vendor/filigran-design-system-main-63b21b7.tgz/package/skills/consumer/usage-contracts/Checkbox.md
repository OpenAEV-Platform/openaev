# Checkbox — usage contract

- **Component:** `Checkbox` · **Package:** `@filigran/design-system`
- **Source of truth:** `Checkbox.rfc.md` + `Checkbox.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-checkbox` (Root + Indicator)

> Read this before using `Checkbox`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { CheckboxMeta } from "@filigran/design-system/meta"`.

## Intent

The binary (and tri-state) selection control. It renders a 16×16 box with an
**optional inline label and description** and supports three value states:
`checked`, unchecked, and `"indeterminate"`. Built on `@radix-ui/react-checkbox`,
which provides the ARIA `checkbox` role, `aria-checked` (incl. `"mixed"`),
keyboard toggling, and controlled/uncontrolled behaviour. It is also the base of
the multiple-selection option rows in `Combobox`.

## Usage rules

- Use `checked="indeterminate"` for "select all" / partial-selection headers —
  never a separate boolean prop. Indeterminate is set programmatically only; it
  is not reachable by direct keyboard toggle.
- **Always provide either `label` or `aria-label`** — the control must never be
  unlabeled. Do not wrap it in a separate `FormControlLabel`; label and
  description render internally from the `label` / `description` props.
- **No error/invalid state.** There is no `error` prop and there will not be one:
  validation state is carried by the surrounding form field, not the box.
- Do not expose `size` or `color` — a single 16px box and a single token set, no
  density/palette variants.
- Bind `checked` / `onCheckedChange` as native Radix controlled/uncontrolled
  props only — do not embed Formik/react-hook-form APIs in the box; product
  wrappers keep doing that binding above Checkbox.
- Style overrides go only through `className` (box) / `wrapperClassName` (label +
  description block) — no `sx` / inline `style`.
- **The box has no background at rest and must keep none** — it is transparent and
  inherits its container's surface by design.
- **Never call `stopPropagation` on the box**, and keep `onCheckedChange`
  optional: presentational checkboxes inside a clickable row rely on the click
  reaching the surrounding row.
- When composed inside a `Combobox` multiple-selection option row, its own focus
  ring is never suppressed — it renders additively to the row's focus indicator.

## Composition

Compound-capable but primarily standalone. The default `<Checkbox>` renders the
full field (box + indicator + optional label + description) from props — no
separate `FormControlLabel` needed.

```tsx
<Checkbox
  checked={checked}
  onCheckedChange={setChecked}
  label="Enable notifications"
  description="You can change this later in settings"
/>

// Tri-state (select-all header)
<Checkbox checked="indeterminate" onCheckedChange={selectAll} label="Select all" />
```

`Combobox`'s multiple-selection option rows compose this Checkbox directly (only
the bare box + indicator; label/description come from the row) — never a parallel
implementation.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<FormControlLabel control={<Checkbox checked={v} onChange={fn} />} label="X" />` | `<Checkbox checked={v} onCheckedChange={fn} label="X" />` | label absorbed; `onChange(e)` → `onCheckedChange(bool)` |
| `<Checkbox checked={v} onChange={fn} />` (bare) | `<Checkbox checked={v} onCheckedChange={fn} />` | signature change |
| `<Checkbox indeterminate />` | `<Checkbox checked="indeterminate" />` | tri-state via `checked` |
| `<Checkbox disabled />` | `<Checkbox disabled />` | |
| `<Checkbox size="small" />` | `<Checkbox />` | drop — single size |
| `<Checkbox color="primary" />` | `<Checkbox />` | drop — single token set |
| `<Checkbox disableRipple />` / `edge="start"` | `<Checkbox />` | drop — MUI-only artifacts |
| `@filigran/ui <Checkbox checked onCheckedChange />` | `<Checkbox checked onCheckedChange />` | near 1:1 (target pattern) |

**The biggest mechanical change — the event shape.** MUI hands the handler a
`ChangeEvent`; Radix hands it the new value directly:

```tsx
// before (MUI)
<Checkbox checked={v} onChange={(e) => setV(e.target.checked)} />
// after (FDS)
<Checkbox checked={v} onCheckedChange={(checked) => setV(checked === true)} />
```

`checked` is `boolean | "indeterminate"`, so a handler writing into a `boolean`
state must narrow (`checked === true`). Handlers that need the event keep
`onClick` (a native DOM prop, passes straight through).

**Presentational checkboxes inside a list/option row** (e.g. MUI `Autocomplete`
`renderOption`) stay unchanged in shape: pass `checked` with no handler. A
Checkbox with `checked` and no handler is a valid, fully controlled, read-only-
looking control — it is *not* `disabled`. Clicks bubble to the row.

## Accessibility notes

- Radix renders a `role="checkbox"` button with `aria-checked` =
  `true`/`false`/`"mixed"`. With `label`, association is automatic via generated
  `id`; when omitted, an `aria-label` **must** be passed. `description` links via
  `aria-describedby`; `required` sets `aria-required="true"`.
- Keyboard: `Tab` focuses, `Space` toggles. No custom keys. Indeterminate is
  programmatic only.
- State is never conveyed by box/border colour alone — the check/dash glyph +
  `aria-checked` carry meaning.
- Disabled substitutes each colour for its disabled counterpart (removed from tab
  order) — **never an opacity tint**. Full contrast pairs are in `CheckboxMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints. Fixed 16px box; label/description
  wrap within their container.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic. Contrast verified in both modes.

## Out of scope — do not reach for Checkbox here

| Need | Use instead |
|---|---|
| `size` (small/medium) | not applicable (single 16px size) |
| `color` (MUI palette) | not applicable (single token set) |
| `disableRipple`, `edge` | not applicable (MUI-only artifacts) |
| `icon` / `checkedIcon`, `slotProps` | not applicable (glyph fixed by the design system) |
| error / invalid variant | the surrounding form field |
| switch-style toggle | `Switch` |
| single-choice (radio) | `Radio` |
| checkbox group / list layout | a group wrapper (composition concern) |
| `sx` / `style` | `className` / `wrapperClassName` |
