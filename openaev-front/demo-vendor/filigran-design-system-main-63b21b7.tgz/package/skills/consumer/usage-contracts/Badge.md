# Badge — usage contract

- **Component:** `Badge` · **Package:** `@filigran/design-system`
- **Source of truth:** `Badge.meta.ts` + `process/BADGE-API-PROPOSAL.md` (this
  file is a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it). No standalone
  `Badge.rfc.md` — the proposal and the meta are the record.
- **RFC status:** beta (shipped)
- **Radix primitive:** none (a presentational `<span>`; never interactive)

> Read this before using `Badge`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { BadgeMeta } from "@filigran/design-system/meta"`.

## Intent

The notification marker attached to another element: a small **count**, or a
**dot** when the count itself does not matter. It replaces MUI `Badge` (27 render
sites across OpenCTI and OpenAEV, all hand-styled through `sx`). Purely
presentational and **never interactive** — there is no keyboard model, no state
and nothing to focus.

Boundary with `Chip`: a **Chip labels** (its own text carries the whole meaning
and reads on its own line); a **Badge marks** (remove the element it sits on and
it means nothing). The dot is DERIVED from an absent `content`, and can also be
FORCED while a count exists — "something is waiting, do not show how much" — and
the accessible name stays complete either way.

## Usage rules

- **RULE-01 — Marks, never labels.** Use `Badge` to mark an anchor with a count
  or a dot. A standalone token that carries its own meaning is a `Chip`, not a
  Badge.
- **RULE-02 — Anchored or standalone.** With `children`, the badge positions
  itself absolutely on the anchor's corner. Omit `children` to render the badge
  inline in normal flow — the status-dot / inline-count shape products used to
  hand-write — with no wrapper and no absolute positioning.
- **RULE-03 — Tone is a redundant cue; the announced text carries the meaning.**
  `tone` ∈ `brand` / `error` / `success` / `neutral`. The default is **`error`
  (red) since 2026-08-13** — a badge rendered with no `tone` now paints red; pass
  `tone="brand"` to keep the previous appearance. There is no amber `alert` tone:
  that family cannot meet the dot's contrast floor, so it was not drawn.
- **RULE-04 — A dot must be named.** The dot form (`content` omitted, or `dot`
  forcing it over a count) renders no text, so `accessibleText` is **required**
  for the pure-dot case — omitting it is a TypeScript error, and a dev-only
  `console.warn` catches untyped call sites the compiler never sees. A bare
  coloured dot would carry its meaning by colour alone (WCAG 1.4.1).
- **RULE-05 — `accessibleText` describes the anchor, it never renames it.** When
  `children` is a single React element, the badge wires `aria-describedby` from
  the anchor to itself: the anchor's accessible **name** is left untouched and the
  value becomes its **description**. A string replaces the announced value and
  hides the visible digits from assistive technology (never both at once).
  `false` takes the badge out of the accessibility tree and wires nothing — for an
  anchor you have already named. Never hand a bilingual product a hardcoded
  English phrase.
- **RULE-06 — `max` caps numbers only.** Above it, the badge renders `` `${max}+`
  ``. No default (uncapped); a negative or non-finite value is treated as
  uncapped; a string `content` is never capped.
- **RULE-07 — `showZero` / `invisible` govern whether it mounts.** `content={0}`
  is hidden unless `showZero`. `invisible` does not mount the node at all, so
  nothing is left in the accessibility tree. When anchored, the anchor still
  renders in both cases — only the badge is gone.
- **RULE-08 — Anchor geometry: `circularAnchor` and `bareAnchor`.**
  `circularAnchor` tucks the badge onto a round anchor (14% inset, MUI's own
  circular formula). `bareAnchor` declares that the anchor paints no resting
  surface (a `tertiary` `IconButton`): `"md"` tucks the badge 8px in so it stays
  visually attached to the glyph a filled anchor gets for free; `"sm"` resolves to
  the default geometry today, but declare it anyway so a later `sm` change lands
  in the library and not in your call site. Only `"md"` overrides `circularAnchor`
  — `"sm"` leaves it in effect.
- **RULE-09 — Never interactive.** No `onClick`, `role`, `tabIndex` or focus ring.
  A clickable counter is your own `<button>` wrapped by `Badge`, not a Badge prop.
- **RULE-10 — No live region by default.** Polling counters would chatter, so no
  `aria-live` is imposed; pass one through when you genuinely need the change
  announced.

## Composition

Standalone marker, or a wrapper around one anchor. With `children`, `Badge`
renders a `relative inline-flex` span holding the anchor plus the
absolutely-positioned badge, and **clones the single child** to add
`aria-describedby`. The cloned child MUST forward `aria-describedby` onto the
element it renders, or the description is silently lost: `IconButton` does (it
spreads props onto its native `<button>`), but a **bare `Icon` does NOT** — it
renders an `<svg>`/`<span>` and reads only its own known props, so
`<Badge><Icon/></Badge>` wires no description. For an icon-only anchor use
`IconButton`, or wrap the `Icon` in an element that forwards the attribute. The
`IconButton` case (named by `aria-label`) is exactly why the value must arrive as
a **description**: the label owns the name. Only a single React element can carry
the reference; a bare string, a fragment or an array renders the badge but wires
no description (dev-only warn).

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Badge badgeContent={n}><Icon/></Badge>` | `<Badge content={n}><IconButton .../></Badge>`, or wrap the `Icon` in a forwarding element | anchor must forward `aria-describedby`; a bare `Icon` drops it, so `content`/`badgeContent` would be unannounced |
| `<Badge color="error">` | `<Badge>` (default) or `<Badge tone="error">` | `error` is the default tone |
| `<Badge color="primary">` | `<Badge tone="brand">` | `brand` was the old default |
| `<Badge variant="dot">` | omit `content` (or pass `dot`) + `accessibleText` | a dot must be named |
| `<Badge max={99}>` | `<Badge max={99}>` | same; renders `${max}+` |
| `<Badge showZero>` | `<Badge showZero>` | same rule as MUI |
| `<Badge invisible>` | `<Badge invisible>` | node is not mounted at all |
| `<Badge overlap="circular">` | `<Badge circularAnchor>` | 14% inset |
| corner offsets via `sx` on a tertiary anchor | `<Badge bareAnchor="md">` | 8px inset for a surface-less anchor |
| implicit English count SR text | `accessibleText={t('…')}` | never a hardcoded English phrase |
| clickable `sx`-wrapped badge | your own `<button>` wrapped by `<Badge>` | Badge is never interactive |

## Accessibility notes

- The badge **describes** its anchor: when `children` is given, the wrapper clones
  the single child and gives it `aria-describedby` pointing at the badge, so the
  anchor's accessible **name** is untouched and the count is its accessible
  **description**. This replaces relying on the accname algorithm sweeping the
  badge's text out of the anchor's subtree — which fails for an `IconButton` named
  by `aria-label` (7 of the 27 inventory sites), where the label wins and the
  count would be announced by nobody.
- `accessibleText` (string) replaces the announced value and hides the visible
  digits from assistive technology, so the description is your phrase alone.
  `accessibleText={false}` takes the badge out of the accessibility tree and adds
  no `aria-describedby`. An anchor that already had an `aria-describedby` keeps it
  — the badge appends.
- A dot with no `accessibleText` is a **type error**; the same dev-only warning
  catches untyped call sites, because a bare coloured dot carries meaning by
  colour alone (WCAG 1.4.1). Forcing the dot while `content` is set is exempt —
  the value is still described.
- Contrast: the counter label clears 4.5:1 on its own fill (1.4.3); the dot fill
  clears 3:1 against the reference surface (1.4.11, a graphical object that carries
  information). Full pairs, per tone, are in `BadgeMeta`.
- No live region, no disabled state, and never interactive — all by design.

## Behavior

- **Responsive:** intrinsic. The counter is `h-5 min-w-5` with horizontal padding;
  the dot is `size-2`. When anchored, the badge is absolutely positioned on the
  anchor's corner (`translate` keeps it centred on the offset point). No
  breakpoints.
- **Dark / Light:** tokens switch via `.dark` / `.light`; no conditional logic. If
  you re-scope a theme class around a badge, a nested-theme surface also needs
  `.layer-0` to re-resolve the elevation alias — see the board note in `BadgeMeta`.

## Out of scope — do not reach for Badge here

| Need | Use instead |
|---|---|
| a standalone labelled token | `Chip` |
| a clickable badge | your own `<button>` wrapped by `Badge` |
| an amber / `alert` tone | not available (fails the dot contrast floor) |
| extra sizes | single counter / dot geometry |
| built-in live-region announcements | pass `aria-live` through |
| a disabled state | not available |
