# DatePicker — usage contract

- **Component:** `DatePicker` · **Package:** `@filigran/design-system`
- **Source of truth:** `DatePicker.rfc.md` + `DatePicker.meta.ts` (this file is
  a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-popover` (the floating surface only — the calendar grid is the library's own)

> Read this before using `DatePicker`. It carries the rules the TypeScript types
> do not encode. For exact prop names/types and contrast pairs, also read
> `import { DatePickerMeta } from "@filigran/design-system/meta"`.

## Intent

A form or filter field holding a calendar date, or a date and a clock time
(`withTime`). The field is editable text wearing the Input shell — same label,
required marker, helper and error rows, same hover/focus/disabled/error states —
with a calendar button in its end slot that opens a popover calendar following
the WAI-ARIA date picker dialog pattern. It replaces MUI X `DatePicker` and
`DateTimePicker` (including a `DateTimePicker` restricted to date views) and
XTM CRQ's react-day-picker wrapper. The component is **controlled or
uncontrolled** and form-library-agnostic — bind `value` + `onChange`, submit on
`onAccept`.

## Usage rules

- **RULE-01 — Label.** Always provide `label`, `aria-label` or `aria-labelledby`.
  A missing accessible name warns in development, never throws.
- **RULE-02 — The value is a `Date` instant or `null`, nothing else.** It is
  read and edited in the browser's zone by default, or in the zone `timezone`
  names (RULE-08); a date-only pick is midnight of that zone, `withTime` keeps
  the clock. Convert to an ISO string at your wrapper. Never pass an
  `Invalid Date`.
- **RULE-03 — `withTime` is the date-time field.** Do not look for a second
  component: MUI's `DateTimePicker` maps to `<DatePicker withTime>`, and a
  `DateTimePicker` with `views={['year','month','day']}` maps to a plain
  `<DatePicker>`.
- **RULE-04 — Read `validationError` before trusting `onChange`.** `onChange`
  fires on every keystroke, pick and clear with a MUI X shaped context: text that
  does not resolve reports `null` with `"invalidDate"`; a resolved date outside
  `minDate` / `maxDate` / `disableFuture` / `disablePast` reports the date with
  the rejecting bound, and a clock outside `minDateTime` / `maxDateTime` reports
  `minTime` / `maxTime`. Ignore the value while `validationError` is set if you
  want MUI's exact behaviour.
- **RULE-05 — Error is a message, and the commit is `onAccept`.** `error` is
  string-only; presence paints the error state and replaces `helperText`. Submit
  on `onAccept` (calendar pick, OK, Enter, blur after typing, clear), not on
  `onChange`.
- **RULE-06 — Locale drives the default, `format` overrides it.** Pass the
  product's locale (`locale="fr-FR"`); the pattern, the month and weekday names,
  the AM/PM strings and the week start follow it. Pass `format` only for a fixed
  contract (`"yyyy-MM-dd HH:mm:ss"`), with the tokens `yyyy MM dd HH hh mm ss a`.
  Seconds and a 12-hour clock come from the pattern, never from a prop.
- **RULE-07 — `clearable` is opt-in.** Turn it on for filters and optional
  fields; never render your own clear button in the end slot.
- **RULE-08 — `timezone` names the zone the calendar is read in; the value
  stays an instant.** `"default"` (the browser's, the default), `"UTC"` or an
  IANA name such as `"Europe/Paris"`. Never convert the value yourself and pass
  `timezone` too.

## Composition

Standalone. The field wears Input's classes; the four buttons are `IconButton`;
month, year and AM/PM are `Select`; hours, minutes and seconds are
`Input isTypeNumber`; OK is `Button`; the panel is `Paper` elevation 1 on a Radix
Popover. Every rendered string (button names, panel name, clock labels, OK) is a
prop with an English default — pass the product's translations.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<DatePicker value={d} onChange={setD} slotProps={{ textField: { label, fullWidth, variant: 'outlined', error, helperText } }} />` | `<DatePicker label value={d} onChange={setD} error={message} helperText />` | width is intrinsic; `error` is the message |
| `<DateTimePicker … />` | `<DatePicker withTime … />` | |
| `<DateTimePicker views={['year','month','day']} … />` | `<DatePicker … />` | |
| `<Field component={DateTimePickerField} name="x" withSeconds onSubmit={…} />` (Formik) | `<DatePicker withTime format="dd/MM/yyyy HH:mm:ss" value={values.x} onChange={(v) => setFieldValue('x', v)} onAccept={…} clearable />` | the per-locale format map becomes the locale-derived default, or an explicit `format` |
| `<Controller render={({ field, fieldState }) => <DateTimePicker … />} />` (react-hook-form) | `<DatePicker withTime value={field.value ? new Date(field.value) : null} onChange={(d) => field.onChange(d?.toISOString())} error={fieldState.error?.message} />` | |
| `minDate`, `maxDate`, `minDateTime`, `maxDateTime`, `disableFuture`, `onAccept` | same names | instant bounds report `minTime` / `maxTime` |
| `ampm={false}` + `format="yyyy-MM-dd HH:mm:ss"` | `format="yyyy-MM-dd HH:mm:ss"` | `HH` is the 24-hour clock |
| `slotProps.field.clearable` | `clearable` | |
| `<TimePicker … />` | `<TimePicker … />` | the time-only field, its own component and usage contract |
| `variant="standard"`, `size="small"`, `sx`, `style` | `className` | |

## Accessibility notes

- The field is a native text `<input>` with Input's `aria-required`,
  `aria-invalid` and merged `aria-describedby`; the calendar button carries
  `aria-haspopup="dialog"` and `aria-expanded`; the panel is a modal dialog named
  after the label (`calendarLabel` overrides).
- On open, focus lands on the selected day (else today). The grid is a
  `role="grid"` table labelled by a live month caption; days are gridcells with a
  full spoken date, `aria-selected`, `aria-current="date"` on today and
  `aria-disabled` outside the bounds (still focusable, never selectable).
- Keyboard: arrows move by day and week, Home/End to the week's ends,
  PageUp/PageDown by month, Shift+PageUp/PageDown by year, Enter/Space select,
  Escape closes and returns focus to the calendar button. Typing in the field
  is always possible; Enter accepts.
- Today and the selected day carry a 2px border as well as a fill, so neither
  state rests on colour alone. Full contrast pairs are in `DatePickerMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints. The field follows its container;
  the panel is a fixed-width popover positioned by Radix.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic.

## Out of scope — do not reach for DatePicker here

| Need | Use instead |
|---|---|
| time-only field (MUI X `TimePicker`, native `type="time"`) | `TimePicker` |
| date range field | two `DatePicker`s, as every product does today |
| `shouldDisableDate` | not available — use `minDate` / `maxDate` / `disableFuture` / `disablePast` |
| year or month grid views (`views`, `openTo`) | the header's month and year selects |
| relative-date syntax (`now-1d`) | a product text field with presets |
