# Switch — usage contract

- **Component:** `Switch` · **Package:** `@filigran/design-system`
- **Source of truth:** `Switch.rfc.md` + `Switch.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved — ⚠️ revision pending human re-validation
- **Radix primitive:** `@radix-ui/react-switch`

> Read this before using `Switch`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { SwitchMeta } from "@filigran/design-system/meta"`.

## Intent

Boolean on/off toggle. Wraps `@radix-ui/react-switch`, rendering a native
`<button role="switch">` with an optional integrated label. Used across all three
products as the standard binary-setting control (feature flags, per-row toggles in
admin forms, schedule/notification enablement).

## Edge cases seen in products

- **Formik / react-hook-form integration is the dominant real pattern**, not raw
  `<Switch>`. Both wrappers pair the control with a visible label, matching the
  Figma's integrated label.
- **`color="secondary"` appears once** (opencti) with no discernible semantic
  meaning — inherited MUI theming boilerplate. `color` is not migrated.
- **No confirmation-before-toggle pattern** exists anywhere — every real call site
  toggles immediately.
- **No loading-state-during-toggle pattern** exists — toggles are synchronous local
  form state; async persistence happens on form submit, not per-toggle.

## Composition

Standalone component. No sub-components exposed — `label` is a prop, not a composed
sibling. Internally composes Radix's `Root` / `Thumb`; those are not re-exported.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<MuiSwitch checked={v} onChange={fn} />` | `<Switch checked={v} onCheckedChange={(c) => fn({ target: { checked: c } })} />` | `onChange(event)` → `onCheckedChange(checked: boolean)` — signature change, not a rename |
| `<SwitchField name="x" label="…" tooltip="…" helpertext="…" />` | `<Switch name="x" label="…" />` | `tooltip` / `helpertext` have no direct equivalent — compose externally |
| `<SwitchFieldController name="x" label="…" size="small" required disabled />` | `<Switch name="x" label="…" required disabled />` | `Controller` wiring stays consumer-side; `size="small"` has no v1 equivalent |
| `<MuiSwitch color="secondary" />` | `<Switch />` | `color` dropped |

## Accessibility notes

- Native `<button role="switch" aria-checked>` (Radix `Root`) — no custom ARIA
  beyond what Radix sets automatically.
- When `label` is provided, it renders inside a native `<label htmlFor>` wrapping
  both control and text, so the accessible name comes from standard label
  association. When `label` is omitted, the consumer must supply an accessible name
  directly (`aria-label` or `aria-labelledby`).
- Keyboard: native — `Space`/`Enter` toggle, `Tab`/`Shift+Tab` move focus. No
  deviation.
- No confirmation-before-toggle step and no loading state — matches every real
  product usage and Radix's own default.
- The off-track's translucent fill has one residual contrast pair below the 3:1
  threshold (allow-listed, deferred to a global colour-token pass); identifiability
  is carried by the thumb, which passes thumb-vs-background ≥ 3:1 in both modes.
  Full contrast pairs are in `SwitchMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints — fixed track/thumb dimensions
  regardless of viewport.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic. Both modes independently verified.

## Usage rules

- **RULE-01 — Integrated label only.** `label` renders inside the same `<label>`
  element as the control. There is no "label as sibling" mode — consumers needing a
  detached label supply their own accessible name via `aria-label` /
  `aria-labelledby` and omit `label`.
- **RULE-02 — No indeterminate state.** Switch exposes exactly two states, checked
  and unchecked. Use a different control if a tri-state is required.
- **RULE-03 — Immediate toggle, no confirmation step.** The control toggles
  immediately on interaction; consumers needing confirmation compose it externally
  (e.g. wrap in a Dialog).

## Out of scope — do not reach for Switch here

| Need | Use instead |
|---|---|
| `size` ("small" / compact) | single Figma size — logged as debt |
| `color` (alternate / "secondary") | single Figma colour — does not migrate |
| Track contour | rejected — does not exist in Figma |
| Indeterminate / tri-state | not part of Radix Switch's API |
| Confirmation-before-toggle | compose externally (Dialog) |
| Loading state during toggle | persist on form submit |
| `tooltip` / `helpertext` first-class props | compose externally (this repo's Tooltip) |
