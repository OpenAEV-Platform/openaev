# Thumbnail — usage contract

- **Component:** `Thumbnail` · **Package:** `@filigran/design-system`
- **Source of truth:** `Thumbnail.meta.ts` + `Thumbnail.tsx` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it). No standalone `Thumbnail.rfc.md` —
  the meta and the component are the record.
- **RFC status:** beta (shipped)
- **Radix primitive:** none (it is a composed FDS `<Paper>`)

> Read this before using `Thumbnail`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { ThumbnailMeta } from "@filigran/design-system/meta"`.

## Intent

A **48px framed slot** for a glyph or a small image. It is a `Paper` with its
content centred and **nothing else** — it declares no colour of its own, so it
inherits Paper's surface, border, radius and the elevation mechanism, and sits
correctly on any surface. Used as the leading slot of a card header, and anywhere
a small object needs a frame.

## Usage rules

- **RULE-01 — One fixed 48px frame.** There is no `size` prop. The set carried
  three sizes until 2026-08-23 and now carries one; a second size is a design
  decision, not a prop to anticipate.
- **RULE-02 — It is a `Paper`, not a bespoke box.** Never hardcode a fill, border
  or radius. The surface, border, radius and elevation are Paper's — a hand-built
  box with a hardcoded fill would look right on one surface and wrong on every
  other.
- **RULE-03 — The frame is decorative.** It carries no text and no role. A glyph
  inside it that *means* something needs its own accessible name, through `Icon`'s
  `aria-label`; the frame adds none.
- **RULE-04 — Content is centred, not padded.** The frame renders with
  `padding={0}`: a 24px glyph gets the node's 12px inset from being centred in the
  48px frame, not from a padding step. Anything smaller than 48 sits centred by
  itself; an image is clipped to the frame by `overflow-hidden`.

## Composition

A single composition: `Thumbnail` **is an instance of the FDS `<Paper>`**
(`padding={0}`), never a re-built box — its surface/border/radius/elevation are
inherited, not redefined. The `children` (normally an `<Icon size={24} />`,
sometimes an image) are centred inside the 48px frame. `className` is merged onto
the Paper, and the component forwards the remaining `<div>` props.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Avatar variant="rounded"><Icon/></Avatar>` | `<Thumbnail><Icon size={24}/></Thumbnail>` | 48px frame; no colour of its own |
| `<Avatar variant="square" src={img} />` | `<Thumbnail><img …/></Thumbnail>` | `overflow-hidden` clips the image to the frame |
| hand-built `<Paper sx={{ p, border }}>` centring an icon | `<Thumbnail>…</Thumbnail>` | the frame already *is* a Paper — do not rebuild it |
| `<Avatar sx={{ width, height }}>` (custom size) | `<Thumbnail>` | single 48px size; sizing is a design decision |
| `<Avatar sx={{ bgcolor }}>` | `<Thumbnail>` | inherit Paper's surface; never hardcode a fill |

## Accessibility notes

- The frame is **decorative**: it carries no text and no role, and adds no
  accessible name of its own.
- A glyph that conveys meaning must name itself via `Icon`'s `aria-label`; a
  purely decorative glyph stays `aria-hidden` (Icon's default).
- Contrast: the glyph against the frame's surface clears 3:1
  (`--icon-default` on `--bg-elevation-default`, WCAG 1.4.11) — the pair is in
  `ThumbnailMeta`.

## Behavior

- **Responsive:** fixed 48px (`size-12`), `shrink-0`, `overflow-hidden`; the frame
  stays 48 whatever it holds, and never grows or shrinks with the row. No
  breakpoints.
- **Dark / Light:** no mode-specific logic; the surface, border and radius come
  from Paper's tokens, which switch via `.dark` / `.light`.

## Out of scope — do not reach for Thumbnail here

| Need | Use instead |
|---|---|
| additional sizes | single 48px frame |
| a coloured / custom fill | inherit Paper's surface (do not hardcode) |
| an avatar with a status ring or presence dot | not in scope |
| a clickable tile | wrap the `Thumbnail` in your own control |
| a full-bleed image card | `Card` / `Paper` directly |
