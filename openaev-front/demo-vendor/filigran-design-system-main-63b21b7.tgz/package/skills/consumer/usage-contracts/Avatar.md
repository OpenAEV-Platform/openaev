# Avatar — usage contract

- **Component:** `Avatar`, `AvatarGroup` · **Package:** `@filigran/design-system`
- **Source of truth:** `Avatar.rfc.md` + `Avatar.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-avatar` (Avatar only; AvatarGroup composes it with the library's `Tooltip`)

> Read this before using `Avatar` or `AvatarGroup`. It carries the rules the
> TypeScript types do not encode. For exact prop names/types and contrast pairs,
> also read `import { AvatarMeta } from "@filigran/design-system/meta"`.

## Intent

A **person**, or an entity identified by its name: a round disc holding two
initials or a photo (xs 16 / sm 24 / md 32 / lg 44 px), optionally followed by
the name and a one-line description. `AvatarGroup` stacks several people as
overlapping md discs followed by a `+N` counter whose tooltip lists the hidden
names. One fill for everyone: colour never carries meaning.

## Usage rules

- **RULE-01 — A person or an entity, identified by name.** A user, an author, a
  contact, or a named entity such as an attack pattern. Never an icon, an event
  type, a status, a count or a product logo: use `Thumbnail`, `Icon`, `Badge` or
  `Chip`.
- **RULE-02 — Pass the name, never initials.** Give `name` whenever it is known;
  Avatar computes the two initials. When the name is unknown, omit `name` (never
  `"?"` or `""`): Avatar draws the anonymous state, labelled by `anonymousLabel`
  (default "Unknown" — localise it).
- **RULE-03 — One announcement per name.** When the host already renders the name
  next to the avatar (a `CardHeader` title, a table cell, a list's primary text),
  pass `aria-hidden` to Avatar. When the name must sit next to the disc and
  nothing else renders it, use `showName`.
- **RULE-04 — Size by context.** `lg` in a Card header or a profile header; `md`
  (the default) in lists, rows and presence groups; `sm` in dense tables and
  inline mentions; `xs` only beside caption-sized text.
- **RULE-05 — Tooltips on demand.** Use `withTooltip` only when the name is visible
  nowhere else on screen. Never wrap Avatar in a host `Tooltip`: the disc would
  not be focusable.
- **RULE-06 — Several people means AvatarGroup.** Never line up Avatars by hand.
  Name the group with `aria-label` ("Users editing this entity") or
  `aria-labelledby` — the type requires exactly one. Every item carries a stable
  `id` (a user id), never an array index: the group keeps focus and an open
  tooltip on the same person when people join or leave.
- **RULE-07 — No restyling.** Never override the fill, the size, the group ring or
  the 220px name cap with `className`. A different look is a design request.

## Composition

- `Avatar` is a disc alone, or with `showName` a disc plus a name block capped at
  220px that truncates with an ellipsis; the root shrinks inside a narrow flex row
  or grid cell. `description` is one line under the name (lg, md) or after it
  (sm, xs), and is ignored without `showName`.
- `CardHeader` composes an Avatar **alone** in its `icon` slot; the title and
  subtitle stay `CardHeader`'s children, so the Avatar is `aria-hidden`.
- `AvatarGroup` takes data, not children: `items: { id, name?, src? }[]`, `max`
  (default 4) and `overflowLabel(hiddenNames)` for the localised `+N` text.
- `AvatarGroup` keeps its intrinsic width (127px for four discs and `+N`) and
  never shrinks: in a narrow host row, let the row wrap rather than squeeze it.
- Avatar is never a control. To make one clickable, wrap it in your own link or
  button, which owns the focus ring and the name.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<CardHeader avatar={<Avatar>{author.charAt(0)}</Avatar>} title={author} />` | `<CardHeader icon={<Avatar name={author} size="lg" aria-hidden />}>…</CardHeader>` | name stays in CardHeader's children (RULE-03) |
| `<Avatar sx={{ bgcolor: stringToColour(name) }}>{name.charAt(0)}</Avatar>` in a `Tooltip`, one per user | `<AvatarGroup aria-label="Users editing this entity" items={users.map((u) => ({ id: u.id, name: u.name }))} />` | per-user colour dropped; overlap, `max`, `+N` and keyboard access gained |
| an author medallion built from a `Box` and computed initials | `<Avatar name={author} size="md" />` | never compute initials yourself |
| an avatar followed by a hand-placed name | `<Avatar name={name} showName />` | the disc becomes decorative |
| a small avatar in a `Tooltip`, focusable | `<Avatar name={name} size="sm" withTooltip />` | |
| `<Avatar src={url} />` for a person | `<Avatar name={user.name} src={user.avatarUrl} size="lg" />` | always pass `name`: initials show while the photo loads and if it fails |
| `<Avatar>{entity.name.substring(0, 1)}</Avatar>` | `<Avatar name={entity.name} size="sm" />` | a named entity (RULE-01) |
| `<Avatar><SomeIcon /></Avatar>` | `<Thumbnail><Icon … /></Thumbnail>` | not a person or a named entity |
| `<Avatar variant="square">{n}</Avatar>` (numbered status) | stays MUI | a status, not a person |

## Accessibility notes

- A disc with no visible name is `role="img"`, named by the person (or
  `anonymousLabel`). Its photo is `alt=""`, so the name is announced once and does
  not change while the photo loads or fails. These semantics cannot be overridden
  from the call site.
- With `showName`, or when the host passes `aria-hidden`, the disc carries no role
  and no label.
- Keyboard: a standalone Avatar is not focusable unless `withTooltip`. In
  `AvatarGroup` every visible disc and `+N` is a Tab stop; focus opens its tooltip
  and `Escape` closes it. The focused disc is lifted so its ring is never covered.
- Focus ring: the standard `ring-focus` / `ring-offset-focus` pattern, measured on
  every elevation layer. The group ring follows the nearest `Paper` layer and is
  decorative separation, not a WCAG 1.4.11 boundary.

## Behavior

- **Responsive:** intrinsic, no breakpoints. The name block never wraps and
  truncates at 220px; the full text stays in the DOM.
- **Dark / Light:** no mode-specific logic; tokens switch via `.dark` / `.light`.

## Out of scope — do not reach for Avatar here

| Need | Use instead |
|---|---|
| an icon in a disc (history event types, bookmark widgets) | `Thumbnail` + `Icon`; history discs are a separate future component |
| a numbered or square status | `Badge` / `Chip` |
| a 64px (xl) size | `lg` (44px) |
| a colour per user or per entity | not in scope: one fill for everyone |
| a presence dot or a badge overlay | not in scope |
| a product logo in a disc | `Icon` or `<img>` |
| a skeleton placeholder | not in the library yet |
