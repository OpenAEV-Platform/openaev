# ColorPicker — usage contract

- **Component:** `ColorPicker` · **Package:** `@filigran/design-system`
- **Source of truth:** `ColorPicker.rfc.md` + `ColorPicker.meta.ts` (this file is
  a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-popover` + `@radix-ui/react-slider` (via a
  vendored DiceUI color-picker on a radix base)

> Read this before using `ColorPicker`. It carries the rules the TypeScript types
> do not encode. For exact prop names/types and contrast pairs, also read
> `import { ColorPickerMeta } from "@filigran/design-system/meta"`.

## Intent

A form field that lets a user pick a color through a trigger input (closed state,
showing the current value + a swatch preview) that opens a panel with a 2D
saturation/brightness area, hue and optional alpha sliders, an optional
eyedropper, a format selector, editable value inputs, and an optional grid of
preset swatches. It replaces three divergent product implementations (Formik,
react-hook-form, react-final-form on MUI `TextField` + `react-color`). The
component is **headless/controlled** — bind `value` + `onValueChange`, never
coupled to a form library.

## Usage rules

- **RULE-01 — Label.** Always provide `label`, `aria-label`, or `aria-labelledby`
  — the field must never be unlabeled. Placeholder text is not a substitute.
- **RULE-02 — Value binding is form-library-agnostic.** Bind `value` /
  `onValueChange` as native controlled props; Formik/RHF/react-final-form bind at
  the product wrapper level, never inside the component.
- **RULE-03 — Hex is the default; alpha and non-hex formats are opt-in.** The
  out-of-the-box value is a `#RRGGBB` hex string. `formats` (rgb/hsl/hsb), a
  non-hex initial `format`, and `alpha` are opt-in. Enabling `alpha` changes the
  output to `#RRGGBBAA` — a deliberate data-contract change you must handle on
  persistence.
- **RULE-04 — Error message.** When `error` is set the message is mandatory and
  replaces `helperText`; `error` is string-only (no boolean). Never signal error
  through border/icon color alone.
- **RULE-05 — Required state.** `required` renders a `*` next to the label (only
  when a `label` is present); submitting empty while required moves it to Error.
- **RULE-06 — Disabled state.** `disabled` makes the trigger non-interactive and
  the panel unopenable. Never emulate disabled by hiding the trigger.
- **RULE-07 — Preset swatches.** `showSwatches` toggles the preset grid; keep it
  opt-in. Its default is the official Filigran palette (`DEFAULT_PRESETS`);
  `presets` overrides the values but should carry a purposeful product palette.
- **RULE-08 — Eyedropper is best-effort, never required.** It returns `null` where
  `window.EyeDropper` is unsupported (Firefox/Safari); the layout must read
  correctly without it. Never make a workflow depend on it.
- **RULE-09 — Hex entry works in both the trigger and the panel** — two views of
  the same controlled value; never treat the panel input as the sole entry point.
- **RULE-10 — Sliders are the component's own, not the FDS `Slider`** — do not
  attempt to reroute the gradient hue/alpha sliders through `Slider`.
- **RULE-11 — No `variant` / `size` / `fullWidth`.** A single style, a single 36px
  field height, intrinsic (100%) width.
- **RULE-12 — Style overrides go only through `className`** — no `sx`/inline
  `style`, and no restyling the panel's chrome (Paper background, radius, shadow,
  gradient tracks). Panel placement is the supported adjustment surface.

## Composition

Compound, vendored from DiceUI (radix base), re-tokenized. The public surface is
the `ColorPicker` field; the panel is assembled from DiceUI parts (Trigger,
Content, Area, HueSlider, AlphaSlider, EyeDropper, FormatSelect, Input, Swatch)
whose chrome is swapped for FDS components (Paper, IconButton, Select Field, Input
Field). Preset swatches are an FDS overlay.

`DEFAULT_PRESETS` is exported alongside the component (16 swatches). Presets are
**application data** (persisted concrete hex literals), not style tokens, so they
resolve to stable hex values — not live `var(--token)`s — and are overridable
per-field via the `presets` prop.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Field component={ColorPickerField} name="x" label="Color" />` (Formik) | `<ColorPicker value={values.x} onValueChange={v => setFieldValue('x', v)} label="Color" />` | hex default = iso value |
| `<ColorPickerField control={control} name="x" />` (RHF) | `<Controller … render={({field}) => <ColorPicker value={field.value} onValueChange={field.onChange} />} />` | |
| `<DeprecatedColorPickerField name="x" />` (react-final-form) | same controlled wiring via `<Field>` render | legacy path |
| `required`, `disabled`, `helperText`, `error` | same-named props | |

## Accessibility notes

- Trigger is a `<button>` opening a Radix Popover (`aria-expanded`,
  `aria-haspopup`). Sliders inherit `role="slider"` + `aria-valuemin/max/now`. The
  area is a labelled 2D control; each value input is a labelled `<input>`; a hidden
  form input carries `name`/value.
- Keyboard: `Enter`/`Space` opens the trigger; `Escape` closes and returns focus
  to it. Sliders use arrows / Home / End; the area moves the thumb with arrows;
  hex/channel inputs take direct text entry.
- The EyeDropper button renders `null` on unsupported browsers — layout must stay
  correct without it. Preset swatches are focusable buttons with an accessible
  color name. Full contrast pairs are in `ColorPickerMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints. Field width follows its container;
  the panel is a fixed-width popover. Layout must stay correct when the eyedropper
  is absent.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic.

## Out of scope — do not reach for ColorPicker here

| Need | Use instead |
|---|---|
| `variant="standard"` (MUI underline) | not applicable (single FDS style) |
| outer spacing props (`style`, `marginTop`) | `className` (caller layout) |
| built-in clear/reset button | clear via the controlled `value` |
| saved / recent colors history | not available |
| multiple simultaneous colors / gradients | out of the field's remit |
