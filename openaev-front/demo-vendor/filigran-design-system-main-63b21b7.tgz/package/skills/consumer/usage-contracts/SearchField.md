# SearchField — usage contract

- **Component:** `SearchField` · **Package:** `@filigran/design-system`
- **Source of truth:** `SearchField.rfc.md` + `SearchField.meta.ts` (this file is
  a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** draft
- **Radix primitive:** none — native `<input>` composition

> Status is draft — API may still change.

> Read this before using `SearchField`. It carries the rules the TypeScript types
> do not encode. For exact prop names/types and contrast pairs, also read
> `import { SearchFieldMeta } from "@filigran/design-system/meta"`.

## Intent

Specialized text input for search and filtering. Wraps a native
`<input type="search">` with a leading search icon, optional trailing action slot
(`searchOption`), and submit-on-Enter behavior. It unifies and replaces OpenCTI's
`SearchInput` wrapper (50 files) and OpenAEV's `SearchFilter` (15 files), both of
which wrap MUI `TextField` with a search-icon adornment and Enter-to-submit logic.

## Usage rules

- **RULE-01 — Fixed search icon.** A search icon is always present on the left,
  non-interactive and not removable, at 16px in both sizes.
- **RULE-02 — Placeholder text.** Shows a `Search...` placeholder when empty,
  which disappears as soon as the user types.
- **RULE-03 — No built-in label.** No `<label>` is rendered; provide an
  accessible name via `<label htmlFor>` (preferred), `aria-label`, or
  `aria-labelledby`.
- **RULE-04 — No required / validation / error states.** Five states only:
  Default, Hover, Focus, Filled, Disabled.
- **RULE-05 — Optional action slot (`searchOption`).** A right-side slot (after
  the built-in clear cross) accepting one or more `IconButton`s for independent
  secondary actions (filter panel, options toggle). Clearing is **not** a
  `searchOption` responsibility.
- **RULE-06 — Search on validation.** Primary interaction is submit-on-Enter. An
  `onChange` callback exists for real-time filtering, but Enter-to-submit is the
  default expected pattern.
- **RULE-07 — Disabled state.** When `disabled`, the field, clear cross, and
  `searchOption` are all non-interactive; the placeholder remains visible.
- **RULE-08 — Built-in clear cross.** The field renders its own clear cross (an
  `IconButton`) only while it holds a value **and** it can actually clear it: in
  **controlled** mode the cross renders only when `onClear` is provided (the
  component must not overwrite a controlled `value`, so without `onClear` there
  is nothing it can clear); in **uncontrolled** mode it always renders when there
  is a value. The browser's UA clear widgets are suppressed so exactly one cross
  ever shows. Clicking it clears the field and fires `onClear()`; `Escape` shares
  that clear path (so in controlled mode without `onClear`, where no cross shows,
  Escape has nothing to clear). **Consumers must not add their own
  clear button to `searchOption`** — that puts two crosses in the field.

## Composition

Standalone component with one built-in trailing control and one optional slot.

- The search icon is always rendered (internal, not configurable).
- The **clear cross** is built in and rendered only while the field holds a value
  — an `IconButton` (`variant="default"`, `priority="tertiary"`, `size="sm"`),
  the same recipe as Chip's delete cross and Dialog's close button.
- `searchOption` accepts any `ReactNode` (typically an `<IconButton>`), maps to
  Figma's `hasSearchOption` boolean, and renders after the clear cross.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<SearchInput onSubmit={fn} keyword={val} variant="small" />` (opencti) | `<SearchField onSubmit={fn} value={val} size="sm" />` | `keyword` → `value`, `variant` → `size` |
| `<SearchInput onSubmit={fn} keyword={val} variant="topBar" />` (opencti) | `<SearchField onSubmit={fn} value={val} size="md" fullWidth />` | TopBar uses fullWidth md |
| `<SearchFilter onChange={fn} keyword={val} variant="small" />` (openaev) | `<SearchField onChange={fn} defaultValue={val} size="sm" />` | `keyword` → `defaultValue` (uncontrolled + debounce external) |
| `<TextField … InputProps={{ startAdornment: <Search /> }}>` | `<SearchField … />` | Search icon built-in |

## Accessibility notes

- Native `<input type="search">` wrapped in a container with `role="search"`
  (landmark). The input inherits standard HTML attributes via prop spread. The
  search icon is decorative (`aria-hidden="true"`).
- The built-in clear cross is a real `<button type="button">` with its own
  `aria-label` (`clearLabel`, default `"Clear search"`), shown only while the
  field holds a value. Additional trailing actions via `searchOption` must carry
  their own `aria-label`.
- The browser's own clear widgets are suppressed
  (`::-webkit-search-cancel-button`, `::-webkit-search-decoration`, `::-ms-clear`)
  so exactly one cross exists.
- Keyboard: `Enter` fires `onSubmit(value)` and, **when an `onSubmit` callback is
  provided**, calls `preventDefault()` so it does not also submit a parent form;
  without `onSubmit` the input stays on the parent form's normal submit path.
  `Escape` runs the same clear path as the clear cross, whose effect depends on
  control mode: **uncontrolled**, it empties the field itself and fires `onClear`
  if provided; **controlled**, it fires `onClear` if provided (your signal to
  reset `value`) and never overwrites the value it does not own — so a controlled
  field **without** `onClear` is left unchanged. `Tab` moves to the clear cross
  (when present), then the `searchOption` slot, then onward; standard text-editing
  keys apply.
- Placeholder is never the sole label — provide `aria-label` when no visible
  `<label>` is associated (common in toolbars). Full contrast pairs are in
  `SearchFieldMeta`.

## Behavior

- **Sizing:** fixed width by default (220px md / 200px sm) matching Figma; when
  `fullWidth` is true it stretches to 100% of the container. No breakpoints.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`, no
  conditional logic.

## Edge cases seen in products

- **Enter-to-submit** is the dominant opencti pattern — the input does not submit
  a form.
- **Debounced onChange:** openaev's wrapper debounces internally (~300ms). This
  is a consumer concern — the component fires `onChange` on every keystroke; wrap
  with your own debounce.
- **Clear button:** opencti renders an "×" to clear; openaev does not. Now
  built-in.
- **NLQ/AI toggle:** opencti's topBar variant adds a natural-language-query
  toggle + bulk search — product-specific, out of scope.
- **Width animation:** opencti's focus width animation (150px→250px) is a
  deprecated pattern — use fixed or `fullWidth` layout.
- **Global TopBar vs inline:** platform-wide search (`size="md"`) vs compact
  inline filtering (`size="sm"`).

## Out of scope — do not reach for SearchField here

| Excluded feature | Reason / use instead |
|---|---|
| NLQ/AI toggle | Product-specific (opencti Enterprise) — compose externally |
| Bulk search mode | Product-specific (opencti) — compose externally |
| Built-in debounce | Consumer concern — debounce `onChange` externally |
| Width animation on focus | Deprecated — use fixed width or `fullWidth` |
| Loading / spinner state | Product-specific (NLQ) — compose externally |
| Auto-complete / suggestions | Separate component — `Combobox` / `Autocomplete` |
| `variant` styling (topBar/thin/inDrawer) | Replaced by `size` + `className` |
