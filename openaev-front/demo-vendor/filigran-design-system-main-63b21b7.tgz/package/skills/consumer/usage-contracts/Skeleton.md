# Skeleton — usage contract

- **Component:** `Skeleton`, `SkeletonGroup` · **Package:** `@filigran/design-system`
- **Source of truth:** `Skeleton.rfc.md` + `Skeleton.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** none

> Read this before using `Skeleton`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types, also read
> `import { SkeletonMeta } from "@filigran/design-system/meta"`.

## Intent

A placeholder block drawn where content is loading, with the size and position
of that content, so nothing shifts when the data arrives. It replaces
`@mui/material` `Skeleton` (OpenCTI, OpenAEV) and `@filigran/ui` `Skeleton`
(OpenGRC). `SkeletonGroup` is the loading region around the placeholders: it
carries `aria-busy` and the one `role="status"` announcement, which no product
had before.

## Edge cases seen in products

- **No product marks a loading region.** None of the MUI sites sets
  `aria-busy` or `role="status"`, and MUI's `Skeleton` adds no ARIA of its own:
  assistive technology hears nothing. Wrapping in `SkeletonGroup` closes that.
- **Placeholders mirror the loaded geometry.** OpenCTI's `*LineDummy` and
  `*CardDummy` components, and OpenAEV's `TargetSkeletons`, draw one bar per
  line of the loaded row or card.
- **Sizes are pixel props in MUI code** (`width={30}`, `height="100%"`). They
  become `h-*` / `w-*` classes.
- **Spacing is set on the bar** (`marginBottom: 10`). It moves to `gap-*` on the
  parent.

## Composition

```tsx
<SkeletonGroup loading={isLoading} label="Loading threat actors">
  {isLoading ? (
    <div className="flex items-center gap-2">
      <Skeleton shape="circle" className="h-8 w-8" />
      <div className="flex flex-1 flex-col gap-1">
        <Skeleton className="h-3.5 w-9/10" />
        <Skeleton className="h-3 w-3/5" />
      </div>
    </div>
  ) : (
    <ThreatActorRow actor={actor} />
  )}
</SkeletonGroup>
```

- Keep the `SkeletonGroup` mounted for the whole life of the region and toggle
  `loading`. Do not render it only while loading: the status element must exist
  before its text changes, or screen readers announce nothing.
- `SkeletonGroup` renders a visually hidden status just before the region, then
  the region `div` that receives `className`, props and the ref.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Skeleton variant="rectangular" width="90%" height={15} />` | `<Skeleton className="h-4 w-9/10" />` | `rectangle` is the default shape |
| `<Skeleton variant="circular" width={30} height={30} />` | `<Skeleton shape="circle" className="h-7.5 w-7.5" />` | |
| `<Skeleton variant="rounded" … />` | `<Skeleton className="…" />` | `rectangle` already has `--radius-sm` |
| `<Skeleton variant="text" sx={{ fontSize: 13 }} />` | `<Skeleton className="h-3 w-…" />` | explicit height, no font-derived height |
| `<Skeleton height="100%" />` in a fixed-height row | `<Skeleton className="h-full w-…" />` | |
| `animation="wave"` | drop it | the wave is the only animation |
| `animation={false}` | drop it | reduced motion stops the wave automatically |
| `style={{ marginBottom: 10 }}` on the bar | `gap-*` on the parent | |
| No region around the skeletons | wrap in `<SkeletonGroup loading>` | the accessibility fix of the migration |

`@filigran/ui` `Skeleton` (OpenGRC) already sizes with classes: keep the
classes, wrap the area in a `SkeletonGroup`.

## Accessibility notes

- `Skeleton` is always `aria-hidden="true"`; a consumer cannot override it. It
  is not focusable and has no keyboard interaction.
- `SkeletonGroup` sets `aria-busy={loading}` on its region and announces
  `label` (default `"Loading…"`) once through `role="status"` when loading
  starts, including a group that is loading from its first render.
- The block fill has no contrast ratio to meet: a decorative placeholder is not
  a graphic WCAG 1.4.11 covers, and the status text carries the meaning.
- The wave stops under `prefers-reduced-motion: reduce`; the block stays as a
  plain fill.

## Behavior

- **Responsive:** intrinsic, no breakpoints. A bar sized in fractions follows
  its container.
- **Flex rows:** `shape="circle"` does not shrink, so a disc beside a `w-full`
  bar stays round. The `SkeletonGroup` region is `w-full` by default, so it does
  not collapse when it is itself a flex item; pass `w-*` or `flex-*` to size it
  differently.
- **Dark / Light and elevation:** tokens switch via `.dark` / `.light`, and the
  fill follows the nearest `.layer-N` ancestor (inside a `Paper`, it paints that
  layer's highlight).

## Usage rules

- **RULE-01 — Mirror the loaded layout.** Each Skeleton has the size and the
  position of the content it replaces, so nothing shifts when the data arrives.
  Do not use one generic block for an area whose final layout is known.
- **RULE-02 — Every Skeleton sits in a loading region.** Wrap it in a
  `SkeletonGroup`. A bare Skeleton is `aria-hidden` and announces nothing.
  (A `Card` loading state that opens its own region is planned with Card v2; it
  does not ship yet.)
- **RULE-03 — One region per piece of content that loads together.** A grid or
  a list gets one `SkeletonGroup` around it, not one per item. Never nest
  `SkeletonGroup`s.
- **RULE-04 — Size with classes, space with the parent.** Use `h-*` and `w-*`
  only. Spacing between bars is `gap-*` on the parent, never a margin on the
  Skeleton.
- **RULE-05 — `shape="circle"` only where the loaded content is round** (avatar,
  round icon). Everything else is `shape="rectangle"`.
- **RULE-06 — Skeleton is for content, not for actions.** An action in progress
  (save, submit) uses `Spinner`; a measurable progress uses `ProgressBar`. Never
  put a Skeleton inside a button or any other interactive element, and nothing
  inside a loading region is focusable.
- **RULE-07 — Never leave a Skeleton in place once loading ends.** Replace it
  with the content, the empty state, or the error state.
- **RULE-08 — Name the region when it helps.** Pass a translated `label`
  ("Loading threat actors") when a page has several regions loading at the same
  time. Otherwise the default `"Loading…"` is enough.

## Out of scope — do not reach for Skeleton here

| Need | Use instead |
|---|---|
| `width` / `height` props | `w-*` / `h-*` classes |
| `animation` prop (pulse, none) | nothing: one wave, stopped by reduced motion |
| `variant="text"` / font-derived height | an explicit `h-*` class |
| `variant="rounded"` | `shape="rectangle"` (already `--radius-sm`) |
| `children` and size inference | explicit size classes |
| A Card media loading shape | not drawn yet (Card scope) |
| An action in progress | `Spinner` |
| A known percentage | `ProgressBar` |
