# Banner — usage contract

- **Component:** `Banner`, `BannerAction`, `BannerStack`
  · **Package:** `@filigran/design-system`
- **Source of truth:** `Banner.rfc.md` + `Banner.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** none

> Read this before using `Banner`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { BannerMeta } from "@filigran/design-system/meta"`.

## Intent

An **application-level message strip**, full width, outside page content:
licence and trial countdowns, start-trial and register-platform prompts, SMTP
expiry, system messages. One gradient fill per variant (`default`, `warning`,
`error`, `success`), one message with an optional leading icon, an optional
action and an optional close control. Everything inside the strip paints one
ink, set by the banner, so a product never picks a colour for a gradient.

## Usage rules

- **RULE-01 — Application level only.** Banner is for messages about the
  application, outside page content. Anything inside a page, card, form,
  drawer or dialog is an `Alert`.
- **RULE-02 — One `BannerStack`.** Several banners go in one `BannerStack`,
  never in sibling `fixed` containers. The host shell positions the stack
  (fixed, sticky or in flow) and offsets its own layout by the height
  `onHeightChange` reports. Never hard-code a banner height.
- **RULE-03 — The action is a `BannerAction`.** Never a plain `Button`: its
  colours are not designed for a gradient. One action per banner.
- **RULE-04 — Dismissal is the product's.** `onDismiss` only reports the
  click. Persist the dismissal yourself (localStorage key, server flag) inside
  the handler. The close control renders only when `onDismiss` is set. When
  you unmount the banner after `onDismiss`, move focus to the next banner's
  control or to the main content: a keyboard dismissal otherwise drops focus
  on `body`.
- **RULE-05 — No colour on the content.** Pass the message as text, a bold
  run, inline links. A bare `<a>` or a router `<Link>` in the message is
  styled by the banner (its ink, Medium weight, underlined). Never add a
  `text-*` class or a link colour to anything inside the banner.
- **RULE-06 — Pick the variant from the severity.** `default` is the brand
  gradient. Map system levels as `debug`→`success`, `info`→`default`,
  `warn`→`warning`, `error` and `fatal`→`error`.
- **RULE-07 — `live` only for a banner that arrives later.** A banner rendered
  with the page needs nothing: it is read in document order. Set `live` on a
  banner that appears after page load (an expiry detected later, a broadcast
  received by subscription). Never `role="alert"` for a persistent banner.
- **RULE-08 — Localise the strings.** `dismissLabel` defaults to "Close";
  translate it, like the message and the action label.
- **RULE-09 — Full width only.** Never put a banner in a row or a grid track.
  Its min-content is 227 px (icon, action and close stay on the row): in a
  `1fr 1fr` grid at 320 px it overflows by 141 px, and a flex sibling is
  pushed off-screen.

## Composition

```tsx
<BannerStack className="fixed inset-x-0 top-0" onHeightChange={setBannerOffset}>
  <Banner variant="error">{t("Your licence has expired.")}</Banner>
  <Banner
    variant="warning"
    icon="users"
    action={<BannerAction onClick={contactSales}>{t("Reach sales")}</BannerAction>}
    onDismiss={dismissTrial}
    dismissLabel={t("Close")}
  >
    {t("You have")} <strong>{t("7 days")}</strong> {t("left in your trial period.")}
  </Banner>
</BannerStack>
```

- `BannerAction` takes Button's props except `variant`, `priority`, `size`
  and `color` (`startIcon`, `endIcon`, `asChild`, `onClick`, …). With
  `asChild`, it styles the consumer's `<a>` or `<Link>` as the action button.
- `BannerStack` is a `<section>` named "Notifications" by default; pass
  `aria-label` to rename it. It reports its height on mount and on every
  change.

## Migration from MUI

| Source usage | FDS equivalent | Notes |
|---|---|---|
| `<TopBanner bannerColor="gradient_blue" bannerText={t} />` | `<Banner>{t}</Banner>` | `default` is the default |
| `bannerColor="gradient_yellow"` / `"yellow"` | `variant="warning"` | |
| `bannerColor="gradient_green"` | `variant="success"` | |
| `bannerColor="red"` | `variant="error"` | |
| `buttonText="X" onButtonClick={fn} buttonSx={…}` | `action={<BannerAction onClick={fn}>X</BannerAction>}` | drop `buttonSx` and the hard-coded button colour |
| `onClose={fn}` (+ `dismissKey`) | `onDismiss={fn}` | keep the product's own persistence inside `fn` (RULE-04) |
| OpenAEV SystemBanners `debug` / `info` / `warn` / `error` / `fatal` | `success` / `default` / `warning` / `error` / `error` | RULE-06 |
| several strips with a hand-computed `top` (`TOP_BANNER_HEIGHT`) | `<BannerStack onHeightChange={setOffset}>…</BannerStack>` | RULE-02 |
| XTM CRQ `toast({ duration: Infinity })` for a persistent app problem | `<Banner variant="error" live>` | product decision per site |

## Accessibility notes

- A plain `<div>` with no role by default. With `live`, it takes
  `role="status"` (polite): the region mounts empty and its content follows
  right after mount, so the message arrives as a change the screen reader
  announces. An explicit `role` overrides the one `live` resolves to.
- The start icon is decorative (`aria-hidden`): the message states the
  condition, so neither the colour nor the glyph is the only cue.
- The banner is not focusable. Its links, its action and its close control
  are, in DOM order. The close control is a button named by `dismissLabel`.
- Every text pair passes WCAG 2.1 AA (4.5:1) over every gradient stop, in
  both modes. On `default`, controls use a dedicated focus indicator (a 1px
  brand ring inside a 2px band), because the brand ring disappears on the
  brand gradient.

## Behavior

- **Responsive:** no breakpoints, full width only (RULE-09). On one line the
  content is centred. A long message wraps, start-aligned; the action stays
  on the row and the close control stays at the end, so the strip never
  narrows below 227 px. The strip is at least 40 px high.
- **Dark / Light:** tokens switch via `.dark` / `.light`. `warning` keeps a
  dark ink in both modes.

## Out of scope — do not reach for Banner here

| Need | Use instead |
|---|---|
| a notice inside a page, card, form, drawer or dialog | `Alert` |
| a transient confirmation that disappears on its own | `Snackbar` |
| a classification marking (OpenCTI GREEN / RED / YELLOW, top and bottom) | not in scope: a regulatory marking, not a notification |
| an admin-chosen free colour (OpenCTI SettingsMessages) | not in scope: map the message to a severity variant |
| dismissal persistence | the product, inside `onDismiss` |
| fixed or sticky positioning, z-index | the host shell; `BannerStack` reports its height |
| a disabled action | not in scope |
