# Breadcrumbs — usage contract

- **Component:** `Breadcrumbs` · **Package:** `@filigran/design-system`
- **Source of truth:** `Breadcrumbs.rfc.md` + `Breadcrumbs.meta.ts` (this file is
  a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** implemented

> Read this before using `Breadcrumbs`. It carries the rules the TypeScript types
> do not encode. For exact prop names/types and contrast pairs, also read
> `import { BreadcrumbsMeta } from "@filigran/design-system/meta"`.

## Intent

A hierarchical path indicator: the ancestors of the current page, separated by
`/`, with the current page marked as the last item. It is data-driven — you pass
`items`, not markup. Unlike the hand-built wrappers it replaces, it marks the
current page for assistive technology (`aria-current="page"`).

## Usage rules

- **RULE-01 — Pass the FULL label.** This component truncates by itself (CSS, on
  overflow only). A host that pre-truncates ships a double ellipsis and an
  unreadable `title`. Delete any `truncate(label, …)` you had.
- **RULE-02 — Spacing is the host's.** No `variant`, no `noMargin`, no `style` —
  pass `className`.
- **RULE-03 — One `current` entry, always the last one.** Two `aria-current`
  elements is an ARIA defect the component warns about but cannot fix for you.
- **RULE-04 — With a router, pass `linkComponent` ONCE at the call site** and keep
  destinations in `items` as `to`. Do not wrap entries yourself.
- **RULE-05 — Anything that is not a path entry goes NEXT TO the component,** not
  inside it (e.g. a sensitive-zone chip renders as a sibling of the landmark).
- **RULE-06 — Do not wrap an entry in a tooltip of your own.** Every entry already
  carries a native `title`; a second tooltip shows two bubbles.

## Composition

Standalone, data-driven. No sub-components: the item body is a single text node,
so there is nothing to compose. It renders `nav > ol > li`, with separators in
their own `li aria-hidden="true"`.

## Migration from MUI

**The destination field is renamed `link` → `to`, NOT `link` → `href`.** Both
products install a react-router whose `Link` reads `to` and overwrites any `href`
you pass with the current location — passing `href` there produces a self-link.

| MUI / product usage | FDS equivalent | Notes |
|---|---|---|
| `<Breadcrumbs elements={els} />` | `<Breadcrumbs items={els} linkComponent={Link} />` | rename `link` → **`to`** (react-router). `id`/`data-testid` pass through via rest props |
| `<Breadcrumbs variant="list" elements={els} />` | `<Breadcrumbs items={els} linkComponent={Link} className="…" />` | rename `link` → **`to`**; margins move to the call site |
| A destination with NO router — a plain anchor | `href` on the item, no `linkComponent` | `href` is for the default `<a>` and for link components that read it (e.g. Next's `Link`) |
| `truncate(label, 26)` + `<Tooltip title={label}>` | pass `label` whole | truncation and full-text exposure are the component's job — delete the wrapper's Tooltip |
| `<MUIBreadcrumbs>` + `<Typography color="text.primary">` | `current: true` | adds the missing `aria-current="page"` |
| A trailing chip (e.g. sensitive-zone) inside the path | render it as a **sibling** of `<Breadcrumbs>` | it is not a path entry, so it does not belong inside `<ol>` |

## Accessibility notes

- Semantics: `<nav aria-label="Breadcrumb"> → <ol> → <li>`. Linked item is an
  `<a href>` (or your `linkComponent`); the current item is plain text with
  `aria-current="page"`, never a link; separators are `aria-hidden`.
- Keyboard: `Tab` / `Shift+Tab` through the links only, in document order. No
  arrow-key model — a breadcrumb is not a composite widget.
- Every item carries `title={label}` so a CSS-truncated label stays readable
  without a hover-only widget. The full string always stays in the DOM for
  screen readers and text search.
- The permanent underline on a link is the required non-colour cue that says
  which entry is clickable — it is not decoration; do not remove it.
- Known limit: `title` is a native tooltip with no touch equivalent. On a phone a
  truncated label cannot be read by a sighted touch user (the full string is
  still in the DOM). If you need a touch affordance, render the full path
  yourself. Full contrast pairs are in `BreadcrumbsMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints, no collapse/`maxItems` (measured
  depth ceiling is 4–5). The current entry resists shrinking (`shrink-0`) and is
  capped at `max-w-lg` (32rem); the ancestors yield first. The list does not
  grow, so trailing adornments sit beside the path. A fixed cap cannot adapt to a
  track narrower than itself — unreachable in the shipped product shells.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic in the component.

## Edge cases seen in products

- Depth is small and bounded (max 4, one dynamic path at 5) — well under MUI's
  collapse threshold of 8.
- The current item is always last (217/217 measured sites).
- Unlinked ancestors are the norm (a category heading with no destination) — an
  item without `to`/`href` renders as plain text.

## Out of scope — do not reach for Breadcrumbs here

| Need | Use instead |
|---|---|
| collapse / ellipsis / `maxItems` | not applicable (measured depth ≤ 5) |
| spacing props (`variant`, `noMargin`, `style`) | `className` (host owns layout) |
| a trailing adornment slot | render it as a sibling of the landmark |
| custom `separator` prop | not applicable (fixed to `/`) |
| `asChild` on an entry | not applicable (entry body is a single text node) |
| callback-driven entries (`onBack`-style) | a path entry is a destination, not a handler |
| multiple sizes | one size only |
