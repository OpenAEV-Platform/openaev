# Tooltip — usage contract

- **Component:** `Tooltip` · **Package:** `@filigran/design-system`
- **Source of truth:** `Tooltip.rfc.md` + `Tooltip.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** draft
- **Radix primitive:** `@radix-ui/react-tooltip`

> Status is draft — API may still change.

> Read this before using `Tooltip`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { TooltipMeta } from "@filigran/design-system/meta"`.

## Intent

Contextual popup that displays informational text when a trigger element is hovered
or focused. Tooltips never contain interactive content — they are strictly
informational. Primary use cases: explaining icon-only buttons, defining jargon
terms, and revealing truncated text. A companion to IconButton (icon-only actions
require a tooltip for disambiguation).

## Edge cases seen in products

- Icon-only buttons always paired with a tooltip for accessibility.
- Jargon terms with a dashed underline as the trigger (inline, not a button).
- Truncated text cells showing full content on hover.

## Composition

Compound component (Radix pattern):
- `TooltipProvider` — wraps application/region, configures delay
- `Tooltip` — Root, manages open/close state
- `TooltipTrigger` — attaches to the trigger element (`asChild` supported)
- `TooltipContent` — styled popup with portal

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Tooltip title="…"><Button /></Tooltip>` | `<TooltipProvider><Tooltip><TooltipTrigger asChild><Button /></TooltipTrigger><TooltipContent>…</TooltipContent></Tooltip></TooltipProvider>` | Compound pattern, more verbose but explicit |
| `placement="top"` | `side="top"` | Radix naming |
| `enterDelay={300}` | `<TooltipProvider delayDuration={300}>` | Provider-level |

## Accessibility notes

- `role="tooltip"` with `aria-describedby` on the trigger element, all handled
  automatically by `@radix-ui/react-tooltip`.
- Keyboard: the tooltip opens on trigger focus and closes on `Escape`. Native
  behavior, no deviation.
- No interactive content inside a tooltip (strictly informational).
- Jargon triggers use `tabIndex={0}` for keyboard accessibility.
- Full contrast pairs are in `TooltipMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints. Max width 300px prevents overflow;
  Radix auto-flips the side when there is insufficient space.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic.

## Usage rules

- Always pair with icon-only buttons (IconButton) for disambiguation.
- Never put interactive content inside a tooltip — use Popover instead.
- For jargon definitions, use a `<span>` trigger with a dashed underline.
- For truncated text, show the full content as the tooltip.

## Out of scope — do not reach for Tooltip here

| Need | Use instead |
|---|---|
| Arrow indicator | not in Figma design |
| Rich / interactive content | `Popover` |
| Custom animation | Out of scope — the built-in opacity fade is entrance-only; a consumer `transition` cannot add a Radix exit animation (Presence unmounts at `animationName: none`) |
