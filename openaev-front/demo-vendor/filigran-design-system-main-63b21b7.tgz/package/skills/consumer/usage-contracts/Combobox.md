# Combobox — usage contract

- **Component:** `Combobox` · **Package:** `@filigran/design-system`
- **Source of truth:** `Combobox.rfc.md` + `Combobox.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** implemented
- **Radix primitive:** `@radix-ui/react-popover` (positioning and dismissal only —
  the combobox behaviour itself is in-house)

> Read this before using `Combobox`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { ComboboxMeta } from "@filigran/design-system/meta"`.

## Intent

One field that lets a user pick from a list they can narrow by typing, with
`multiple` as a **prop** rather than a second component. It is the library's answer
to MUI `Autocomplete` and to the `<Select multiple>` sites Radix Select cannot
serve. A separate `MultiSelect` was planned and abandoned — typing is present on
every measured Autocomplete site, so single and multiple share one component.

## Usage rules

- **RULE-01 — Chevron, never a magnifier.** A magnifier means "the value acts"
  (`SearchField`); a chevron means "the value stays". No icon slot in v1 default.
- **RULE-02 — Typing happens in the field.** There is no search input inside the
  panel.
- **RULE-03 — Component choice.** Two options → `Radio`. Up to ~15 static options
  with no search → `Select`. More, or search needed → `Combobox`. Several values
  → `Combobox multiple`.
- **RULE-04 — `Select` is not replaced.** A closed list with no typing stays a
  `Select`.
- **RULE-05 — Filtering belongs to the consumer.** The default is a plain
  substring match; anything ranked/scored/accent-insensitive/server-side is
  `filterOptions`.
- **RULE-06 — Multiple keeps the panel open.** Selected options stay in the list
  with a checkbox, never removed from it.
- **RULE-07 — Chips are library `Chip` instances** (24px, `severity="neutral"`) —
  re-styling a bespoke pill inside the field is forbidden.
- **RULE-08 — The chip row is a single Tab stop.** Arrows move between chips; the
  delete controls carry `deleteTabIndex={-1}`.
- **RULE-09 — The clear control is conditional** — it appears only when there is
  something to clear, and never replaces the chevron; the two sit side by side.
- **RULE-10 — No timer here.** Async search is debounced by the consumer; the
  component owns no timer.
- **RULE-11 — A panel that cannot move has no opener.** `open` supplied with no
  `onOpenChange` mounts no panel — gate an opener on its ability to act.
- **RULE-12 — The field line's slots are the host's** — `startIcon` is decorative
  and never a tab stop; `adornment` keeps its own pointer/focus behaviour and
  reserves no width when empty.
- **RULE-13 — The label moves, the accessible name does not.** `labelPosition` is
  layout only; in `none`, an `aria-label` is mandatory.
- **RULE-14 — Every callback that can fire from more than one cause reports which.**
  `onValueChange`, `onInputChange`, `onOpenChange` and `onCreateOption` receive a
  second `meta`
  argument: `meta.cause` ∈ `"type"` (the user typed) / `"select"` (an option was
  chosen) / `"clear"` (the clear control, or a programmatic clear) / `"reset"` (a
  programmatic value/text write); and `meta.event` — the DOM event when one exists,
  `null` for a programmatic cause. Branch on it instead of guessing: gate a server
  search on `cause === "type"`, and a controlled-open host that keeps the panel
  open on a pick reads `if (!next && meta.cause === "select") return`. `event` is
  not a convenience — sites that wrote `if (!event) return` are expressing
  `if (cause === "type")` through the event's presence. `onValueChange` gains the
  argument source-compatibly: existing call sites that ignore it are unaffected.

## Composition

Three library components are **instances**, never re-styled copies: `Chip` for
each selected value in multiple mode (24px, `severity="neutral"`, `onDelete`,
`deleteTabIndex={-1}`); `Checkbox` in the option row when `multiple` (rendered in
its presentational form, since a real control inside `role="option"` is a
`nested-interactive` failure); and `Icon`/`IconButton` for the chevron and clear
`×`. Radix Popover provides positioning, dismissal and portalling — none of the
combobox behaviour (no listbox, no virtual focus, no filtering).

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Autocomplete options={o} value={v} onChange={fn} />` | `<Combobox options={o} value={v} onValueChange={fn}>` | `onChange(event, value)` → `onValueChange(value, meta)`; the cause moves into `meta` (`meta.cause` / `meta.event`), see RULE-14 |
| `<Autocomplete multiple />` | `<Combobox multiple />` | chips are rendered by the component |
| `<Autocomplete renderOption={fn} />` | `<Combobox renderOption={fn} />` | `renderOption(option, state)`; `state` carries `selected`/`active`. Rich rows take the 48px floor |
| `<Autocomplete renderTags={fn} />` | drop | the field renders `Chip` instances |
| `<Autocomplete selectOnFocus />` | drop it, or `<Combobox selectOnFocus />` | on by default; a migrating site can stop passing it |
| `<Autocomplete openOnFocus />` | `<Combobox openOnFocus />` | same name |
| `<Autocomplete groupBy={fn} />` | `<Combobox groupBy={fn} />` | headers rendered by the component |
| `<Autocomplete loading />` | `<Combobox loading />` | plus `loadingMessage` on `<ComboboxContent>` |
| `<Field component={AutocompleteField} …>` | `<Combobox …>` inside the product's own Formik glue | no form adapter ships here |
| `<Select multiple renderValue={chips} />` | `<Combobox multiple />` | the enumerated `<Select multiple>` sites |
| `<Select>` single value, no typing | **stays `<Select>`** | not replaced, ever |

## Accessibility notes

- The text input carries `role="combobox"`, `aria-expanded`, `aria-controls` (only
  while the listbox exists), `aria-activedescendant` naming the highlighted option,
  and `aria-autocomplete="list"` (the APG "Editable Combobox With List
  Autocomplete" pattern; forwarded, so a consumer can override it).
- The panel list is `role="listbox"` (`aria-multiselectable="true"` when
  `multiple`); options carry `role="option"` and `aria-selected` reflecting
  **selection**, never highlight. Grouped options sit in a named `role="group"`.
- **Highlight never moves DOM focus** — focus stays on the text input for the whole
  interaction and the active option is named by `aria-activedescendant` alone.
  Option styling is driven by a highlight attribute, never `:focus-visible`.
- Keyboard: `ArrowDown`/`ArrowUp` open/move; `Home`/`End` first/last; `Enter`
  selects (single: close; multiple: toggle and stay open); `Space` toggles in
  multiple (unless the input has text); `Escape` closes and keeps the typed text;
  `Tab` closes without selecting; `Backspace` on empty input removes the last
  chip (multiple) or clears (single, when `clearable`); `ArrowLeft`/`ArrowRight`
  move between chips; `Delete`/`Backspace` on a focused chip removes it.
- A disabled option is never highlightable (inert to pointer and keyboard) and
  keeps `cursor-default`. `loading` sets `aria-busy` and announces copy via
  `aria-live`; the empty state is announced too. The chip row is a `role="list"`
  with an `aria-live="polite"` region announcing the chips a selection change
  adds; with `maxVisibleChips` a hidden status announces the added labels
  instead, so a re-fit is not read out. Full contrast
  pairs are in `ComboboxMeta`.

## Behavior

- **Responsive:** the panel takes the field's width and is clamped to the viewport
  by Popover collision handling. Long option labels truncate with an ellipsis and
  expose the full text on hover, as `Chip` does. The field never scrolls
  horizontally — chips wrap and the field grows, unless you hold it to one line
  with `maxVisibleChips` (below).
- **Dark / Light:** nothing mode-specific; every token carries both modes.

## One-line chips — `maxVisibleChips`

Use it where a field cannot grow a line per chip: a table cell, a narrow drawer, a
dense toolbar. It is opt-in, multiple mode only, set on `Combobox` itself:

```tsx
<Combobox multiple maxVisibleChips="fit" ...>
  <ComboboxField>
    <ComboboxChips overflowLabel={(n, labels) => t("moreChips", { count: n, labels: labels.join(", ") })} />
    <ComboboxInput />
  </ComboboxField>
</Combobox>
```

- `maxVisibleChips="fit"` — as many whole chips as the field's width holds, the
  rest in a `+N` chip (a tooltip lists them). It follows the width and the
  labels, so it is the default choice. In a very narrow field, with more than
  one value selected, it shows `+N` alone rather than a chip too small to read.
- `maxVisibleChips={2}` — at most that many, then `+N`: fewer when the first
  chip whole and the second cut to `minChipWidth` would not fit beside `+N`. Pick it only
  when a small, usually-predictable count matters more than using the room.
- `minChipWidth` — a chip after the first is never cut below that many px. Default
  96 (read from the rendered spacing scale; a number you pass is px); leave it. The
  first chip has its own 72px floor instead, whatever this is: it is kept, cut down
  to 72px, before `+N` alone takes its place.
  Count about 45px of it for the chip's padding and delete control. `0` opts out:
  a count is then that many chips, cut down in a narrow field but never below a
  chip with no label, and fewer when even that does not fit.
- Several fields over the SAME option set (a table column)? Wrap them in
  `ChipWidthsProvider labels={...}` so the chips are measured once, above the
  rows. It is your word that they are styled alike. Its children are not in
  server-rendered HTML (they mount once the widths are in). It draws two off-screen
  chips per option once, before its children mount, so it suits a bounded option
  set (tens to a few hundred); set `maxSelected`. A standalone field needs
  nothing.
- Translate `overflowLabel` — it is the `+N` chip's accessible name. The name
  always starts with the visible `+N` (WCAG 2.5.3): return a name that starts with
  it (`"+2 more: A, B"`, the default) or only the words after it (`"more: A, B"`);
  `"2 more: A, B"` would read as `"+2 2 more: A, B"`.
- Do not build your own capped chip row: this is it. The keyboard is the
  wrapping row's: the arrow keys walk the chips that are drawn, and the `+N`
  chip is its own Tab stop, before the input. A value folded into `+N` is removed
  from the list.

## Out of scope — do not reach for Combobox here

| Need | Use instead |
|---|---|
| a separate no-typing `MultiSelect` | `Combobox multiple` (abandoned, folded in) |
| virtualization / `ListboxComponent` | not available (0 measured usage) |
| `limitTags` / `+N` overflow | `maxVisibleChips` on `Combobox` (above); the default stays wrap |
| a form adapter (Formik / react-hook-form) | the product's own glue |
| a selection counter badge | the field shows chips, not a count |
| `success` state on the field | owned by `Input` |
