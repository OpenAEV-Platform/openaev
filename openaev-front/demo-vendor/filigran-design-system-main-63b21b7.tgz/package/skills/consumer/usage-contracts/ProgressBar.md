# ProgressBar — usage contract

- **Component:** `ProgressBar` · **Package:** `@filigran/design-system`
- **Source of truth:** `ProgressBar.rfc.md` + `ProgressBar.meta.ts` (this file is
  a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** implemented (arbitrations closed, visual checkpoint passed,
  shipped)
- **Radix primitive:** none

> Read this before using `ProgressBar`. It carries the rules the TypeScript types
> do not encode. For exact prop names/types and contrast pairs, also read
> `import { ProgressBarMeta } from "@filigran/design-system/meta"`.

## Intent

The horizontal bar products draw when the share of work already done is **known**:
a task's completion, an upload, a score. It replaces `@mui/material`
`LinearProgress`, which both products use almost exclusively in its determinate
form. There is no indeterminate mode — for unknown progress use `Spinner`.

## Usage rules

- **RULE-01 — never the only carrier of the value.** Render the percentage or
  counter beside the bar (as every product site already does) and point
  `aria-labelledby` at that text when it names the task.
- **RULE-02 — pass a percentage.** The component has no `max`; convert before
  calling it. `value` is clamped to 0–100.
- **RULE-03 — an unknown value is not a bar.** Use `Spinner`; an indeterminate
  bar is out of scope for v1.
- **RULE-04 — `tone` repeats a status, it never states one.** Colour may not be
  the sole carrier of meaning (WCAG 1.4.1). Set `tone` only where the status is
  *already* legible without it — the icon and caption rendered beside the bar. A
  bar whose only difference between "finished" and "failed" is hue is a 1.4.1
  failure; nothing about `tone` reaches assistive technology by design.

## Composition

Standalone component. No sub-components.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<LinearProgress variant="determinate" value={v} />` | `<ProgressBar value={v} aria-label={…} />` | The name is new and is required |
| `<LinearProgress … style={{ borderRadius: 4, height: 10 }} />` | `<ProgressBar size="lg" … />` | Drop the inline style |
| `<LinearProgress sx={{ flex: 1 }} … />` | `<ProgressBar className="flex-1" … />` | |
| `<LinearProgress value={v} sx={{ backgroundColor: alpha(c,.15), '& .MuiLinearProgress-bar': { backgroundColor: c } }} />` | `<ProgressBar value={v} tone={…} … />` | Drop both colours, pass the status. Keep the icon and caption (RULE-04) |
| `<LinearProgress color="warning" />` | *not migrated* | No conformant token, and that site is indeterminate anyway |
| `<LinearProgress variant="buffer" valueBuffer={…} />` | *not migrated in v1* | |
| `<LinearProgress />` (indeterminate) | *not migrated in v1* | Use `Spinner` |

## Accessibility notes

- Renders a `<div role="progressbar">` with `aria-valuenow` (the clamped value),
  `aria-valuemin={0}`, `aria-valuemax={100}`, plus the mandatory accessible name.
  The filled indicator is presentational and not exposed separately.
- `aria-valuetext` is not set — the value is a plain percentage against a 0–100
  range, which AT already announces from `aria-valuenow`.
- Not focusable, no keyboard interaction.
- **`value` is clamped to 0–100** rather than trusted — real product data can
  overrun the range, and an unclamped `aria-valuenow` outside min/max is an ARIA
  violation as well as an overflowing bar.
- Colour is never the sole indicator (WCAG 1.4.1): the filled length is the cue,
  and the caller renders the number beside the bar.
- The judged 1.4.11 adjacency is **indicator-against-its-own-track** (where the
  fill ends), one pair per tone (default / success / error). Full pairs are in
  `ProgressBarMeta`.

## Behavior

- **Responsive:** fills the width its parent gives it; intrinsic height, no
  breakpoints.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`, no
  conditional logic.
- The one legitimate inline style is `width` (the runtime percentage) — no token
  or utility can express an arbitrary percentage. Height, radius and colours are
  all token classes.

## Edge cases seen in products

- **Nothing coloured the bar** in opencti's 7 determinate sites — the one styled
  bar merely restated the default primary.
- **The value is always a caller-computed percentage** (`score`,
  `Math.round((processed / expected) * 100)`, `100 - percentRemaining`); no site
  uses a non-100 maximum.
- **Every site renders its own label** next to the bar, none wired to the bar for
  AT — RULE-01 formalizes wiring it.
- **openaev's `BulkOperationsIndicator`** paints determinate bars by
  `bulk_operation_status` (success / error / default) over a translucent tint of
  the fill, always alongside a status icon and caption — the pattern behind
  `tone` and RULE-04. `warning` is deliberately absent (it cannot be drawn
  conformantly and its only site is indeterminate).

## Out of scope — do not reach for ProgressBar here

| Excluded feature | Reason / use instead |
|---|---|
| Indeterminate mode | Deferred in v1 (product scope) — use `Spinner` for unknown progress |
| Buffer variant (`valueBuffer`) | 2 placeholder-only sites; a second bar behind the first is its own design decision |
| `max` other than 100 | Every real site already computes a percentage |
| `tone="warning"` | Blocked on tokens — `--color-feedback-warning-primary` fails 1.4.11 3:1 against every track token in both modes; its one site is indeterminate anyway |
| `tone="info"` / `"alert"` and the rest of the feedback family | No product site paints them on a bar — an unused tone is an untested tone |
| A built-in label or percentage slot | Every product composes its own text with its own formatting/translation |
| Heights other than 4px and 10px | The 2px/3px bars are the excluded indeterminate sites |
