# Select — usage contract

- **Component:** `Select` · **Package:** `@filigran/design-system`
- **Source of truth:** `Select.rfc.md` + `Select.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-select`

> Read this before using `Select`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { SelectMeta } from "@filigran/design-system/meta"`.

## Intent

Single-value dropdown selector for choosing one option from a predefined list.
It wraps `@radix-ui/react-select` with FDS token styling and a compound-component
API (Root / Trigger / Content / Item), plus an integrated label, helper text, and
error state — one coherent field composition. `multiple` is explicitly and
**permanently** out of scope; multi-value selection is served by `<Combobox multiple>`.

## Composition

Compound-component pattern (Radix-style):

```tsx
<Select value={value} onValueChange={setValue}>
  <SelectLabel required>Relative time</SelectLabel>
  <SelectTrigger>
    <SelectValue placeholder="Select an option..." />
  </SelectTrigger>
  <SelectContent>
    <SelectItem value="days-1">Last 24 hours</SelectItem>
    <SelectItem value="days-7">Last 7 days</SelectItem>
    <SelectItem value="months-1">Last month</SelectItem>
  </SelectContent>
  <SelectHelperText>Choose a time range</SelectHelperText>
</Select>
```

`error` lives on the Root **only** and propagates by context; `SelectTrigger`
and `SelectHelperText` need no prop.

Exported parts: `Select` (Root), `SelectTrigger`, `SelectValue`, `SelectContent`,
`SelectItem`, `SelectLabel`, `SelectHelperText`, `SelectGroup` (grouped items),
`SelectSeparator` (visual separator between groups).

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<FormControl><InputLabel>Label</InputLabel><Select value={v} onChange={e => set(e.target.value)}><MenuItem value="a">A</MenuItem></Select></FormControl>` | `<Select value={v} onValueChange={set}><SelectLabel>Label</SelectLabel><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="a">A</SelectItem></SelectContent></Select>` | Full pattern replacement |
| `<Select variant="outlined">` / `variant="standard">` | `<SelectTrigger>` | Single visual style, no variant prop |
| `<Select size="small">` | `<SelectTrigger>` | Single size (36px) — no size prop |
| `<Select fullWidth>` | `<SelectTrigger className="w-full">` | Via className |
| `<Select disabled>` | `<Select disabled>` | Same API (on Root) |
| `<Select displayEmpty>` + `renderValue` | `<SelectValue placeholder="...">` | Placeholder via Radix pattern |
| `<MenuItem value="">None</MenuItem>` (empty-value "no choice") | `<SelectItem value="__none__">None</SelectItem>` + map the sentinel back to empty | **Radix forbids `<SelectItem value="">`** (it reserves the empty string to clear the selection and show the placeholder). MUI's "no choice" empty option needs a non-empty sentinel value, converted back to `""`/`null` in `onValueChange` |
| `<MenuItem value="x">Text</MenuItem>` | `<SelectItem value="x">Text</SelectItem>` | Direct rename |
| `<MenuItem disabled>` | `<SelectItem disabled>` | Same API |
| `<InputLabel>Label</InputLabel>` | `<SelectLabel>Label</SelectLabel>` | Integrated in compound |
| `<FormHelperText>Help</FormHelperText>` | `<SelectHelperText>Help</SelectHelperText>` | Integrated in compound |
| `<FormControl error>` | `<Select error>` | Error state on **Root** (not on Trigger) |
| `onChange={(event) => event.target.value}` | `onValueChange={(value) => ...}` | Direct value (no event wrapping) |

## Accessibility notes

- Trigger renders as `<button>` with `role="combobox"`, `aria-expanded`,
  `aria-haspopup="listbox"`, `aria-controls`. Content is `<div role="listbox">`;
  items render with `role="option"`, `aria-selected`, `aria-disabled`. All of
  these are managed by Radix.
- **Label association is wired by FDS explicitly.** Radix's `Select.Label` is
  presentational only and does not name the trigger by itself. FDS generates an
  id on the Root, `SelectLabel` consumes it, and `SelectTrigger` reads it to set
  `aria-labelledby` when a `SelectLabel` is present (without overriding a
  consumer-supplied `aria-label` / `aria-labelledby`).
- The trigger must have a visible label — either via `<SelectLabel>` or
  `aria-label` / `aria-labelledby`. Placeholder text is **not** a label. A
  dev-only warning fires if neither is present (silent in production).
- Keyboard: `Space`/`Enter` open or select; `ArrowDown`/`ArrowUp` move; `Home`/`End`
  jump to first/last; `Escape` closes and returns focus to the trigger; type-ahead
  jumps to matching items; `Tab` moves focus without opening. When `clearable` is
  on and a value is set, the clear control is the next tab stop after the trigger.
- Disabled items are announced but not selectable.

## Behavior

- **Responsive:** intrinsic width by default (adapts to content/container). Use
  `className="w-full"` on `SelectTrigger` for full-width. The trigger is `w-fit`
  by default, so width is the consumer's responsibility via `className`; in a
  flex-row parent, put the width on the row **track**, not the trigger. Dropdown
  content positions itself via Radix's popper logic (avoids viewport overflow).
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic in the component.

## Usage rules

- **RULE-01 — Label optional but named.** The label row is optional; when omitted
  you MUST provide `aria-label` / `aria-labelledby` on the trigger. When present,
  the label must clearly identify the data collected.
- **RULE-02 — Required state.** `required` shows a `*` inline next to the label
  and sets the native HTML constraint. It does NOT auto-derive the error state:
  `error` is an independent prop that the consumer sets (together with the helper
  / error text) after its own validation. `Select` never transitions to Error on
  submit or value change on its own.
- **RULE-03 — Helper / description text.** One optional slot below the field,
  used for either contextual description or the error message (only one visible
  at a time).
- **RULE-04 — Error triggers.** Error is reached when a required field is submitted
  empty, or when the value fails cross-field validation. The message is passed via
  the helper-text slot.
- **RULE-05 — Disabled state.** `disabled` makes the whole field non-interactive;
  individual items can also be disabled independently.
- **RULE-06 — Dropdown scroll.** More than 5 items activates scroll on the panel,
  using a custom scrollbar (not the native browser one).
- **RULE-07 — Consistent item format.** Don't mix icons and plain text within one
  dropdown unless explicitly designed.
- **RULE-08 — Avoid nested selects.** Never place a Select inside another Select's
  content; use groups and separators for categorized options.
- **RULE-09 — Selection mode and component choice.** Single value, permanently.
  For 2 options consider Radio; for 3–15 static options use Select; for >15 or
  when search is needed use `<Combobox>`; for multiple values use `<Combobox multiple>`.
- **RULE-10 — Content width.** The dropdown hugs its content's width, with the
  trigger's width as the floor; wrapping is permitted only past `max-w-82` (328px),
  and content wraps onto extra lines rather than being clipped.
- **RULE-11 — Option cursor.** `SelectItem` uses `cursor-pointer` (not the shadcn
  `cursor-default`) to stay iso with the MUI selects it replaces and with `Menu` rows.
- **RULE-12 — The clear control.** `clearable` adds a control that empties the
  selection back to the placeholder. It renders only when there is something to
  clear, never while disabled, and sits beside the chevron (it never replaces it).
  It is a real tab stop, clearing writes `""`, and focus returns to the trigger on
  activation. It also renders in the Error state (emptying a value is often how the
  error is resolved).

## Out of scope — do not reach for Select here

| Need | Use instead |
|---|---|
| Multi-select (`multiple`) | `<Combobox multiple>` (dedicated `MultiSelect` deferred) |
| Searchable / autocomplete | `<Combobox>` |
| `variant` prop (outlined/standard) | single visual style — omit it |
| `size` prop (small/medium) | single size (36px) |
| `renderValue` (custom display) | `SelectValue` / composition |
| `sx` / `style` props | `className` (Tailwind) |
| Hierarchical selection | `TreeSelect` is not shipped — flag the gap (invariant 2) and keep the product's existing MUI/product tree selector until FDS ships one |
| Item icons / avatars | not in current spec |
| `FormControl` wrapper | the compound component IS the form control |
