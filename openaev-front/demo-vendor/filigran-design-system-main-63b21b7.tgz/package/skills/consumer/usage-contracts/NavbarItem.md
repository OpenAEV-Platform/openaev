# NavbarItem — usage contract

- **Component:** `NavbarItem` · **Package:** `@filigran/design-system`
- **Source of truth:** `NavbarItem.rfc.md` + `NavbarItem.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-slot` (enables `asChild`; no dedicated
  primitive exists for a nav row itself)

> Read this before using `NavbarItem`. It carries the rules the TypeScript types
> do not encode. For exact prop names/types and contrast pairs, also read
> `import { NavbarItemMeta } from "@filigran/design-system/meta"`.

## Intent

`NavbarItem` is the single interactive row used throughout `Navbar`: a plain
navigation link (leaf item), the trigger row for a `NavbarSubmenu` (same anatomy,
chevron shown), and the `Navbar` footer's collapse toggle all render the same
row. It renders icon + label + optional trailing chevron and exposes five
interactive states (default / hover / focus / selected / disabled). It supports
`asChild` (so it can render as a router `Link` with `aria-current="page"`) and a
`showIcon` prop to hide the icon without breaking the row's layout.

## Composition

Standalone component, designed to be composed by `NavbarSubmenu` as its trigger
row (`NavbarItem` has no compile-time dependency on `NavbarSubmenu`). It reads
`NavbarContext` (from the ancestor `Navbar`) for the `collapsed` flag to (a)
force the icon visible in collapsed/icon-only mode and (b) wrap itself in a
`Tooltip` so a text alternative exists on hover/focus. Read the collapsed flag
in your own `asChild` child via the exported `useNavbarCollapsed()` hook.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<ListItemButton selected={isActive}><ListItemIcon>{icon}</ListItemIcon><ListItemText>{label}</ListItemText></ListItemButton>` | `<NavbarItem icon={icon} aria-current={isActive ? "page" : undefined}>{label}</NavbarItem>` | `selected` boolean → `aria-current="page"` |
| `renderMenuItem(icon, label, selected, showIcon, …)` (opencti internal) | `<NavbarItem icon={icon} showIcon={showIcon} aria-current={selected ? "page" : undefined}>{label}</NavbarItem>` | Direct 1:1 for `showIcon` |
| Manual `<Tooltip title={label}>` wrapping icon-only rows | Automatic via `NavbarContext.collapsed` | No longer the consumer's responsibility |
| `component="a" href={…}` / router `<Link>` wrapping | `<NavbarItem asChild><Link to={…} aria-current={…}>{label}</Link></NavbarItem>` | Same `asChild` pattern as `Button` |

## Accessibility notes

- Renders a native `<button>` by default (matches the collapse-toggle action
  use). With `asChild` it becomes the child element — typically an `<a>`/router
  `Link`, the correct element for a navigational row.
- Set `aria-current="page"` **only** on the navigational (link) usage, never on
  the plain action-button usage. There is no `selected` boolean:
  `aria-current="page"` is the source of truth for the selected visual state.
- Icon and chevron are decorative (`aria-hidden`); the accessible name comes from
  the text `children` (or, when icon-only in collapsed mode, from the `Tooltip`).
- Keyboard: native — `Tab` to focus, `Enter`/`Space` (button) or `Enter` (link)
  to activate. Focus is shown as Figma's inset 2px border, not the library ring.
- `asChild` + `disabled` caveat: native `disabled` has no effect on an `<a>` —
  handle a disabled link yourself (omit the row, or `aria-disabled` +
  `tabIndex={-1}`). Full contrast pairs are in `NavbarItemMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints; the row is always 100% of its
  `Navbar` container (180px expanded / 48px collapsed). It has no independent
  width logic.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic.

## Usage rules

- `showIcon={false}` is intended for the submenu-item context (where the label
  stays visible). When the ancestor `Navbar` is collapsed, the icon is always
  shown regardless of `showIcon`, to avoid a content-less but focusable row.
- **`asChild` + collapsed composition:** `asChild` ignores `icon` / `showIcon` /
  `chevron` (Slot cannot inject wrappers around an arbitrary child), so a
  consumer composing a router `Link` must replicate the icon/label markup inside
  the child — an `aria-hidden` icon span and a `flex-1 truncate` label span
  (adding `sr-only` to the label while collapsed) — and reproduce NavbarItem's
  own icon-color conditionals verbatim:

  ```tsx
  const collapsed = useNavbarCollapsed();
  <span aria-hidden className={`inline-flex shrink-0 ${collapsed ? "text-default-primary mr-0.5" : "text-default-secondary"}`}>
    {icon}
  </span>
  ```

  Pass `tooltipLabel` for the collapsed-mode Tooltip (in `asChild` mode
  `children` is the slotted element, not plain text).

## Out of scope — do not reach for NavbarItem here

| Need | Use instead |
|---|---|
| a `badge` / `badgeNum` trailing indicator | not in v1 (no confirmed product usage) |
