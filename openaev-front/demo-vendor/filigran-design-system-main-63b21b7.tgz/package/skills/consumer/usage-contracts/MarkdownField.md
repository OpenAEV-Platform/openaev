# MarkdownField — usage contract

- **Component:** `MarkdownField` · **Package:** `@filigran/design-system`
- **Source of truth:** `MarkdownField.rfc.md` + `MarkdownField.meta.ts` (this file
  is a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-popover` for the toolbar's "More" panel
  only — the field itself is a native `<textarea>`

> Read this before using `MarkdownField`. It carries the rules the TypeScript
> types do not encode. For exact prop names/types and contrast pairs, also read
> `import { MarkdownFieldMeta } from "@filigran/design-system/meta"`.

## Intent

A form field whose value is **markdown that is displayed rendered elsewhere**
(descriptions, reports, notes, comments). The author edits raw markdown in a
native `<textarea>`; a formatting toolbar inserts the syntax at the selection.
Optional parts, each rendered only when the host can make it work: a
Write/Preview switch (`renderPreview`), image paste/drop/pick
(`onImageUpload`), an Ask AI menu (`aiActions` + `onAiAction`) and a soft
character limit (`characterLimit`). It replaces OpenCTI's `react-mde` wrapper
and OpenAEV's `@uiw/react-md-editor` wrapper.

## Usage rules

- **Pick the field by what the value becomes (RULE-01).** Rendered markdown →
  `MarkdownField`. Plain multi-line text never rendered → `Textarea`; one line →
  `Input`. Never code, JSON or queries: no highlighting, and the shortcuts would
  corrupt them.
- **Preview must equal the final display (RULE-02).** Pass `renderPreview` with
  the SAME renderer the product displays this content with once saved. The
  library ships **no** markdown renderer. Without `renderPreview` there is no
  Write/Preview switch — never an inert control.
- **Always an accessible name (RULE-03).** `label` by default; only a field whose
  purpose is given by its immediate context (an inline reply) may drop it, and
  then `aria-label` is mandatory.
- **An error is a message (RULE-04).** Pass `error` as the message string, only
  once the field is touched or the form submitted.
- **Images only where they persist (RULE-05).** Pass `onImageUpload` only where
  the product can store the image for this entity; without it, paste, drop and
  the add-images button do not exist. Whenever it is passed, wire
  `onImageReject` — a refused or failed image is never silent. Reasons:
  `"accept"`, `"maxSize"`, `"upload"` (the callback rejected **or threw**),
  `"maxLength"` (the image's text would pass the native `maxLength`).
- **Ask AI only when it can answer (RULE-06).** Pass `aiActions` + `onAiAction`
  only when the feature is available to THIS user (licence, settings,
  permissions resolved before render). Those props decide what is **shown**;
  they are **not an authorization boundary**: `onAiAction` receives the field's
  full value, so the host authorizes the action — server side included — before
  sending anything to the AI. The component stops at "action chosen": the AI
  call and its result dialog are product code.
- **The character limit is soft; the form enforces it (RULE-07).**
  `characterLimit` shows a counter, warns from `limitWarningAt` (default 90 %,
  rounded down) and errors past the limit, but never truncates — the form's
  validation must block submission. Native `maxLength` keeps its hard meaning.
- **Width comes from the container, not below 275px (RULE-08).** In a flex row
  or a grid the field narrows to its column and collapses its toolbar there;
  side-by-side fields need no wrapper.
- **Hide the toolbar only in compact, repeated contexts (RULE-09).**
  `toolbar={false}` is for dense repeated inputs such as inline replies;
  shortcuts keep working. Forms keep the toolbar.
- **Localise every string (RULE-10).** Pass `labels` with every key translated,
  AND `imageRejectionMessage` — the rejection message is built from the
  rejected files, so it is a callback outside `labels`. Ask AI item labels
  arrive translated in `aiActions`.
- **Preview keeps the field's frame (RULE-11).** In Preview the label, helper,
  counter and error stay as in Write; only the editable surface is replaced.
- Style overrides go through `className`, which lands on the root. `style` is
  accepted but lands on the inner `<textarea>`, not on the root; no `sx`.

## Composition

Standalone component, no exported sub-components. Internally composed from
library parts, never re-implemented: `IconButton` + `Tooltip` (toolbar tools
and "More"), `Menu` (Ask AI), `ButtonGroup` (Write/Preview), `Button` (add
images, over a hidden native `<input type="file">`), `Icon` (every glyph), and
Textarea's field surface.

## Migration from product editors

| Product usage | FDS equivalent | Notes |
|---|---|---|
| OpenCTI `<Field component={MarkdownField} name label required … />` (react-mde, 149 sites) | Formik adapter → `<MarkdownField label required value onValueChange error />` | the adapter forwards the error **message**, only when touched or submitted |
| `rows={4} multiline fullWidth variant=…` | dropped | already ignored by the OpenCTI wrapper |
| `style={{ marginTop: 20 }}` | wrapper `className` / layout spacing | not on the root — use a wrapper `className` (`style` lands on the inner `<textarea>`) |
| `onSubmit={(name, value) => …}` | adapter: field-level `onBlur` + changed-since-focus check | `onFocus` / `onBlur` fire once per entry into / exit from the whole field |
| `helperText={…}` | `helperText` | ⚠️ behaviour change: the OpenCTI wrapper drops it today; it will render |
| image upload props (`uploadEntityId`, …) | adapter-owned `onImageUpload` | the temp-token flow stays in the adapter; resolve with the temp URL |
| `askAi` | `aiActions` + `onAiAction`, product dialog unchanged | see RULE-06 |
| `controlledSelectedTab="write"` | `mode="write"` | — |
| OpenAEV `<MarkDownFieldController name label disabled askAi />` (6 sites) | RHF adapter → `<MarkdownField … aiActions={[…]} />` | OpenAEV gains `required` / helper support |

## Accessibility notes

- Native `<textarea>` with a real `<label for>`. `error` sets `aria-invalid`;
  `aria-describedby` points only at rendered, non-empty nodes (message line and
  counter), merged with the consumer's own.
- The formatting toolbar is a WAI-ARIA toolbar: one tab stop, roving focus
  (Left/Right, Home/End); Enter/Space insert the syntax and return focus to the
  textarea. Ctrl/Cmd+B, I and K insert bold, italic and a link.
- In Preview and Disabled the tools stay visible and `aria-disabled`, still in
  the roving order. The preview is a named, focusable region (keyboard-
  scrollable), not a live region; it carries the field's `aria-describedby`
  because the textarea is hidden there.
- Uploads set `aria-busy` on the textarea and announce through a `role=status`
  line; rejections are announced too.
- `wcagStatus` is `"fail"`, allow-listed: the Write/Preview toggle is
  `ButtonGroup` composed unchanged and inherits its accepted WCAG 1.4.11
  selected-segment shortfall; the state is exposed through `aria-checked`. Full
  contrast pairs are in `MarkdownFieldMeta`.

## Behavior

- **Responsive:** width from the container; the toolbar's content and list
  groups move behind "More" when the row is too narrow (measured, not a prop).
  The Ask AI button and the Write/Preview switch never collapse.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`.

## Out of scope — do not reach for MarkdownField here

| Need | Use instead |
|---|---|
| WYSIWYG editing | not supported — Write is raw markdown |
| read-only rendered markdown | the product's own renderer (no library display component yet) |
| code, JSON, query editing | a code editor, never this field |
| copy button in preview code blocks, custom scrollbar, two-step collapse | not supported |
| AI call, streaming, result dialog, licence gating | product code; the field stops at "action chosen" |
| upload transport, Formik / RHF adapters, debounced sync | product adapters |
| `success` state | none — the green field is the drop target |
