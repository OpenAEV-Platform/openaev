# CustomizePanel — usage contract

- **Component:** `CustomizePanel`, `CustomizePanelTrigger`, `CustomizePanelContent`
  · **Package:** `@filigran/design-system`
- **Source of truth:** `CustomizePanel.rfc.md` + `CustomizePanel.meta.ts` (this
  file is a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-popover` (modal); reordering by
  `@dnd-kit/core` + `@dnd-kit/sortable`

> Read this before using `CustomizePanel`. It carries the rules the TypeScript
> types do not encode. For exact prop names/types and contrast pairs, also read
> `import { CustomizePanelMeta } from "@filigran/design-system/meta"`.

## Intent

A panel that opens next to its icon button and lets a user choose **which items
of a collection they see, in what order, and which stay in the main area**:
table columns, toolbar actions or the tabs of a tab bar. Each row has a drag
handle, a checkbox (visible or hidden), its label and a pin toggle. Every change
stays in a draft until **Save**; Cancel, × and Escape discard it. The panel is
controlled and storage-agnostic: `items` in, `onSave` out, and the product
persists the result.

## Composition

```tsx
<CustomizePanel
  mode="pin"
  items={columns}
  defaultItems={defaultColumns}
  maxPinned={2}
  onSave={setColumns}
>
  <CustomizePanelTrigger asChild>
    <IconButton
      aria-label="Customize columns"
      priority="secondary"
      icon={<Icon name="sliders-horizontal" size={16} />}
    />
  </CustomizePanelTrigger>
  <CustomizePanelContent title="Columns" />
</CustomizePanel>
```

- `mode` only changes the words: `"pin"` for table columns (sections **Pinned**
  / **Scrollable**), `"show"` for toolbars and tab bars (**Shown** / **More**).
  Both look the same.
- `items` is the committed state, `{ id, label, visible, pinned }`. **Array order
  is display order, pinned items first.** `onSave` receives the full ordered
  list once, on Save.
- `defaultItems` is what "Reset to default" restores into the draft.
- Every rendered or announced string is in `labels` on `CustomizePanelContent`,
  with English defaults per `mode`. Override words there, never by forking.
- The trigger icon in the examples (`sliders-horizontal`) is a placeholder until
  design picks the customize icon.

## Usage rules

- **RULE-01 — When to use it.** Users need to choose which columns, actions or
  tabs they see; there are more items than fit on screen; different users care
  about different items or orders; the setup is saved per user or per view.
- **RULE-02 — Not for filtering or sorting data.** Use Filter or Sort.
- **RULE-03 — Not for fewer than 5 items.** Show them all instead.
- **RULE-04 — Not for picking one option.** Use a dropdown (`Select`).
- **RULE-05 — Not for instant changes.** The panel always applies on Save; when
  each change must apply immediately, use a checkbox menu.
- **RULE-07 — Toolbars and tab bars change only the words.** Title, section
  labels, counter, hints and the limit tooltip go through `title` and `labels`;
  never fork the component.
- **RULE-08 — Long labels truncate.** One line with an ellipsis, the full label
  in a tooltip. Never shorten product labels to make them fit.
- **RULE-09 — The pin limit is 5 at most.** A product may set a lower
  `maxPinned` (2 for a table), never a higher one; values outside 1–5 are
  clamped with a dev-only warning.
- **RULE-10 — A table's selection column is not an item.** Never pass the
  row-selection checkbox column in `items`: the table always shows it, fixed
  first, and it does not count toward `maxPinned`.
- **RULE-11 — Search is built in.** Above 10 items a search field appears by
  itself and filters both sections; do not add your own filter field to the
  panel. Search finds, checks and pins; reordering is done on the full list.

(RULE-06 was withdrawn in review: an empty Pinned section is a normal state.)

## Behaviour

- **Pinning and visibility.** Pinning an item checks it; unchecking a pinned
  item unpins it. A hidden item is never pinned.
- **Pin limit.** At `maxPinned`, the other pin toggles are disabled with the
  tooltip "Max N can be pinned. Unpin one first." Pressing one keeps the tooltip
  open and announces the message; a full Pinned section refuses dropped rows.
- **Height.** Pinned always shows in full and never scrolls. Scrollable shows at
  least 5 rows and at most 9.5, growing with the space on screen, then scrolls;
  the half row at the bottom shows there is more. If the screen is too short for
  that, the whole list scrolls.
- **Closing.** Save applies and closes. Cancel, × and Escape discard the draft.
  A click outside closes the panel only while nothing has changed; with unsaved
  changes it does nothing, so a stray click never loses work.
- **Narrow screens.** Below the 420px design width the panel takes the viewport
  width minus 16px on each side, drops Cancel and always shows ×.
- **Search.** While a query is active, checking and pinning still work and
  dragging pauses ("Clear the search to reorder."). Escape clears the query
  first, then closes.

## Migration from MUI

New component: there is **no MUI equivalent** and nothing in the products is
replaced.

## Accessibility notes

- The panel is a modal dialog named by its title and described by the counter;
  focus moves in on open, stays inside and returns to the trigger on close.
- Row controls are native: the handle is a button named "Reorder <label>", the
  checkbox is named by the row label, the pin toggle is an `IconButton` named
  "Pin <label>" with `aria-pressed`. Pinned and unpinned also differ by glyph
  shape and by section, never by colour alone.
- Disabled pins use `IconButton`'s `aria-disabled` state, so the limit tooltip
  stays reachable by hover and by keyboard.
- Reordering is never pointer-only: Space or Enter on a handle lifts the row,
  the arrow keys move it across both sections, Space or Enter drops it, Escape
  cancels. Every step is announced with the label, position and section from a
  live region inside the panel.
- With reduced motion, rows move without animation.

## Out of scope — do not reach for CustomizePanel here

| Need | Use instead |
|---|---|
| Changes that apply instantly, without Save | a checkbox menu |
| Filtering or sorting the data | Filter or Sort |
| Picking one option | `Select` |
| An "Available / Selected" catalog with remove | not supported (a different pattern) |
| Column width, resizing or other table settings | not part of this component |
| Locked items that cannot move or hide | don't pass them in `items` |
| More than 5 pinned items | not supported (RULE-09) |
