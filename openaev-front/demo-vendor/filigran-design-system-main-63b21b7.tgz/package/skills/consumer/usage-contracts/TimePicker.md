# TimePicker — usage contract

- **Component:** `TimePicker` · **Package:** `@filigran/design-system`
- **Source of truth:** `TimePicker.rfc.md` + `TimePicker.meta.ts` (this file is
  a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-popover` (the floating surface only — the engine is DatePicker's)

> Read this before using `TimePicker`. It carries the rules the TypeScript types
> do not encode. For exact prop names/types and contrast pairs, also read
> `import { TimePickerMeta } from "@filigran/design-system/meta"`.

## Intent

A form field holding a time of day. The field is editable text wearing the
Input shell — same label, required marker, helper and error rows, same
hover/focus/disabled/error states — with a clock button in its end slot that
opens a panel holding hours, minutes, seconds when asked, AM/PM on a 12-hour
pattern, and OK. It replaces MUI X `TimePicker` and the native
`<input type="time">`. Controlled or uncontrolled, form-library-agnostic — bind
`value` + `onChange`, submit on `onAccept`.

## Usage rules

- **RULE-01 — Label.** Always provide `label`, `aria-label` or `aria-labelledby`.
- **RULE-02 — The value is a `Date` whose clock is the field's, or `null`.** The
  calendar day is left alone: the value's own day, else the day of the last
  non-null value (today at first). Convert to `"HH:mm"` or ISO at your wrapper.
- **RULE-03 — One field per time.** A date and a time on one form value are a
  `DatePicker` and a `TimePicker` bound to the same `Date`; a single date-time
  is `<DatePicker withTime>`.
- **RULE-04 — Read `validationError` before trusting `onChange`.** Unparsable
  text reports `null` with `"invalidDate"`; a time outside `minTime` / `maxTime`
  reports it with `"minTime"` / `"maxTime"`.
- **RULE-05 — Error is a message, and the commit is `onAccept`.** `error` is
  string-only. Submit on `onAccept` (OK, Enter, blur after typing, clear).
- **RULE-06 — Locale drives the default, `format` overrides it.** Pass the
  product's locale; the default is `HH:mm` or `hh:mm a`. Pass `format` for
  seconds (`"HH:mm:ss"`) with the tokens `HH hh mm ss a`.
- **RULE-07 — `clearable` is opt-in.** Never render your own clear button.
- **RULE-08 — `timezone` names the zone the clock is read in; the value stays
  an instant.** `"default"` (the browser's), `"UTC"` or an IANA name.

## Composition

Standalone. The field wears Input's classes; the clock and clear buttons are
`IconButton`; hours, minutes and seconds are `Input isTypeNumber`; AM/PM is
`Select`; OK is `Button`; the panel is `Paper` elevation 1 on a Radix Popover.
Every rendered string is a prop with an English default.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<TimePicker label value={d} onChange={setD} slotProps={{ textField: { fullWidth, error, helperText } }} />` | `<TimePicker label value={d} onChange={setD} error={message} helperText />` | |
| `<Field component={TimePickerField} name="time" withMinutes onSubmit={…} />` (Formik) | `<TimePicker label value={values.time} onChange={(v) => setFieldValue('time', v)} onAccept={…} />` | the per-locale format map becomes the locale-derived default |
| `timeSteps={{ minutes: 15 }}` | `minutesStep={15}` | |
| `minTime`, `disabled`, `onAccept` | same names | |
| `closeOnSelect={false}` | default | the panel closes on OK or Escape only |
| `ampm={false}`, `withSeconds` | `format="HH:mm"`, `format="HH:mm:ss"` | |
| `<TextField type="time" value="09:30" … />` | `<TimePicker value={parseHm(v)} onChange={(d) => onChange(d && formatHm(d))} />` | keep your `"HH:mm"` strings at the wrapper |
| `openTo`, `views`, `skipDisabled` | not available | the panel is a form row |
| `style`, `sx`, `size` | `className` | |

## Accessibility notes

- Native text `<input>` with Input's `aria-required`, `aria-invalid` and merged
  `aria-describedby`; the clock button carries `aria-haspopup="dialog"` and
  `aria-expanded`; the panel is a modal dialog named after the label.
- On open, focus lands on the hours field; Tab cycles hours → minutes →
  (seconds) → (AM/PM) → OK; ArrowUp/ArrowDown step each field, the minutes by
  `minutesStep`; OK accepts and closes; Escape closes and returns focus to the
  clock button. Typing in the field is always possible; Enter accepts.

## Behavior

- **Responsive:** intrinsic, no breakpoints.
- **Dark / Light:** tokens switch via `.dark` / `.light`; no conditional logic.

## Out of scope — do not reach for TimePicker here

| Need | Use instead |
|---|---|
| date and time in one field | `<DatePicker withTime>` |
| clock face or digital clock column | not available |
| time range | two `TimePicker`s |
| `shouldDisableTime`, hour or second steps | not available |
