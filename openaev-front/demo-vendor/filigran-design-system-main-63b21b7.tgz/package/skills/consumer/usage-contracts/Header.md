# Header — usage contract

- **Component:** `Header` · **Package:** `@filigran/design-system`
- **Source of truth:** `Header.rfc.md` + `Header.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** none — a top bar packages no behaviour (focus, dismissal,
  positioning), so no primitive applies.

> Read this before using `Header`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { HeaderMeta } from "@filigran/design-system/meta"`.

## Intent

`Header` is the horizontal bar at the top of an application screen — the band
above the page content, beside the left navigation rail, holding whatever global
controls a product puts there (search, workspace context, notifications, account
menu). It is a **structure with slots, not a content component**: it renders a
`<header>` (the `banner` landmark), pins the Figma geometry (68px tall,
asymmetric padding — 24px leading / 16px on the other three edges — a bottom
hairline, the shared background gradient at 94% opacity) and
lays its children out as a row. It renders no search field, account menu,
notification bell or logo. It has **no colour prop** and **no scroll/condensed
state** by design.

## Composition

Ships two sub-parts: **`HeaderGroup`** (always) and **`HeaderSearch`**
(opt-in). Use one `HeaderGroup` per visual cluster of controls;
`justify-between` on the root handles placement. `HeaderSearch` is the opt-in
integrated search field with an in-field mode-toggle radio group — nothing
renders unless a product writes `<HeaderSearch>`; drop it in as one of the
clusters and it forwards cluster growth to a `HeaderGroup` internally (see
`HeaderMeta` for its `modes` / `value` / `grow` props). All are `forwardRef`.
The account button is a **composition, not a prop** — a trigger that opens the
library `Menu` with the product's own options; wrap that trigger in
`MenuTrigger asChild` (an `IconButton` dropped straight into `Menu` renders but
never opens).

## Migration from MUI

| MUI | FDS | Note |
|---|---|---|
| `<AppBar position="fixed">` | `<Header fullWidth={false} className="fixed top-0 left-45 right-0 z-10">` | **Pin both edges** — see positioning below |
| `<AppBar elevation={0}>` / `{1}` | `<Header>` | No shadow by design; the hairline is the separation |
| `<AppBar sx={{ backgroundColor: 'transparent' }}>` + product gradient | `<Header>` | The surface *is* the themed gradient |
| `<Toolbar sx={{ minHeight: 68 }}>` | *(nothing)* | The root is 68px |
| `<Toolbar>` children | `<HeaderGroup>` × n | One per visual cluster |
| `sx={{ backdropFilter: 'blur(4px)' }}` | *(nothing)* | Not in the Figma node |

## Accessibility notes

- Renders `<header>`, which exposes the `banner` landmark. A top bar is
  **`banner` only** — `navigation` belongs to `Navbar`. No `aria-label` is set
  (with one banner per page there is nothing to disambiguate).
- The Header intercepts nothing: **no roving tabindex, no arrow-key handling, no
  focus trap.** `Tab` moves through the slotted controls in DOM (visual) order.
  `role="toolbar"` was deliberately rejected because it would make the whole bar
  a single tab stop.
- The 1px hairline is decorative; the 94% background opacity is a transparency,
  not a contrast risk. Full contrast pairs are in `HeaderMeta`.

## Behavior

- **Responsive:** a flex row with one growing cluster; it reflows by shrinking
  the search (via `min-w-0` on the growing group). No breakpoints are baked in —
  products manage width themselves.
- **Positioning:** the component ships **no page positioning** (computed
  `position: relative`). The doctrine is that the bar is **always fixed to the
  top and `sticky` is not supported**, but the top offset and `z-index` are the
  consumer's, supplied via `className` (products offset by stacked banner
  heights, rail width, etc.). Use `fullWidth={false}` when positioning so the
  default `w-full` doesn't fight your offset.
- **Height:** published as the `--fds-header-height` custom property (default
  fallback `--spacing(17)` = 68px). Offset your content with
  `top-(--fds-header-height,--spacing(17))` rather than hard-coding `68px`; a
  host may override `:root { --fds-header-height: 80px }`.
- **Dark / Light:** both modes come entirely from tokens; the component carries
  no `dark:` variant.

## Usage rules

- **Exactly one banner per page, and it must be the app's top bar.** Use
  `<Header>` once per page. **Do not** use it for a section, panel, card or
  dialog header — that is a landmark regression. If a bar belongs to a
  subsection, nest it inside `<article>`/`<aside>`/`<main>`/`<nav>`/`<section>`
  or pass `as="div"`. A docs page showing several `<Header>` examples must wrap
  each in a `<section aria-label="…">`.
- **Rail-width trap:** products that keep a `55px` collapsed-rail constant get a
  7px gap against the library `Navbar` (48px collapsed). Use the same source for
  both offsets: `left-45` (180px) expanded, `left-12` (48px) collapsed.
- Theme through tokens (the surface is the product's own background gradient at
  reduced opacity) — there is no colour prop.

## Out of scope — do not reach for Header here

| Need | Use instead |
|---|---|
| a section / panel / card / dialog header | a plain `<header>`/`<div>` inside a sectioning element (not `Header`) |
| positioning (top offset, `z-index`) | consumer `className` (the offset varies per product) |
| scroll behaviour (hide-on-scroll, condensed, elevate-on-scroll) | not supported — no Figma symbol, no product need |
| banners stacked above the bar | product layout (offset the bar yourself) |
| integrated search field (with in-field mode toggles) | `<HeaderSearch>` — the opt-in sub-part, not a raw `HeaderGroup` |
| notifications / account menu / workspace selector | compose them as content into `HeaderGroup`s |
| `color` / `variant` / `elevation` prop | theming via tokens |
| `padding` / `bordered` prop | the Figma spec is fixed (asymmetric padding — 24px leading, 16px other edges — 1px hairline) |
