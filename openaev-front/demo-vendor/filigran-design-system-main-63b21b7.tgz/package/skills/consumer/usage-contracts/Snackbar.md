# Snackbar — usage contract

- **Component:** `Snackbar` · **Package:** `@filigran/design-system`
- **Source of truth:** `Snackbar.rfc.md` + `Snackbar.meta.ts` (this file is a
  published subset; on conflict, those win)
- **RFC status:** review

> Read this before using `Snackbar`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { SnackbarMeta } from "@filigran/design-system/meta"`.

## Intent

The transient feedback message: a severity-tinted surface with a matching left
rule, a severity glyph, the message, an action slot and an optional close control.

It is the visual half of the global message both products already build by hand —
a `@mui/material` `Snackbar` wrapped around a `@mui/material` `Alert`, in
`components/Message.tsx` (OpenCTI) and `components/Message.jsx` (OpenAEV).

**Delete your MUI wrapper — do not port it.** Placement, stacking, the timer and
the dismissal all ship here, on `@radix-ui/react-toast`.

## Three parts — set two up once, then raise messages

```tsx
// 1 + 2: once, at the app root.
<SnackbarProvider duration={6000}>
  <App />
  <SnackbarViewport />
</SnackbarProvider>
```

```tsx
// 3: from anywhere inside it.
{messages.map((m) => (
  <Snackbar
    key={m.id}
    severity={m.severity}
    title={m.text}
    onOpenChange={(open) => { if (!open) retire(m.id); }}
  />
))}
```

- The **viewport** is where every message lands: 24px from the top and right of
  the window by default, and portalled into `document.body` so no layout of yours
  can bury it. A different placement is a `className` on the viewport, never on
  the card.
- The **provider** owns the shared `duration`, the swipe axis and the hidden live
  region. One per app.
- `onOpenChange(false)` fires for **every** dismissal — the close control, the
  timer and a swipe alike. There is no `onClose`.
- **Flip `open`; do not unmount the card there.** See RULE-05 — this is the one
  mistake that silently deletes the exit animation.
- The card is translucent behind a 16px backdrop blur, so it has to sit over real
  page content for either to be visible.

### What you get for free, and must not rebuild

| | |
|---|---|
| auto-dismiss that **pauses on hover and focus** | `duration` on the provider, or per message |
| a message that never retires on its own | `duration={Infinity}` |
| swipe-to-dismiss | on the provider's `swipeDirection` (default right) |
| **F8** to jump focus to the messages | the viewport's `hotkey` |
| the announcement, at the right politeness | derived from `severity` — never write an `aria-live` |
| slide in from the edge, slide back out | automatic; follows the provider's `swipeDirection` |

## Edge cases seen in products

- **Two render sites is the whole inventory**, one per product, and that measures
  centralisation rather than low value: every transient message in the product
  reaches the screen through that single component. Both are a MUI `Snackbar`
  wrapper around a MUI `Alert`; the wrapper goes away entirely.
- **Every product message is one line.** That line is the **message**, so it goes
  in `title`. A one-line Snackbar is a title, never a lone description.
- **`clickaway` is a MUI concept.** MUI's `Snackbar` closes on an outside click and
  hands you the reason; both products immediately filter it back out. This
  component has no outside-click behaviour, so there is no reason to forward — and no
  `onClose` prop at all: `onOpenChange` reports every dismissal.
- **The AI message exists in production and is hand-styled.** That is
  `severity="ia"`.
- **The message content is arbitrary React**, not a string.
- The IA wash is **10 %** where the four feedback severities are 30 %.

## Composition

Three exported parts: `SnackbarProvider`, `SnackbarViewport`, `Snackbar`. Radix's
inner parts (`Toast.Title`, `Toast.Description`, `Toast.Action`, `Toast.Close`)
are deliberately **not** exposed — they are the frame's anatomy, filled from
props. The close control in particular is internal by contract: exposing it would
let you render a Snackbar whose close button does something other than close it.

`children` is not part of the type: with two text slots it would let the message
land in the slot the design treats as secondary.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Snackbar open={o} onClose={c}><Alert severity="error" onClose={c}>Body</Alert></Snackbar>` | `<Snackbar severity="error" title="Body" open={o} onOpenChange={setO} />` | control `open`; do NOT wrap it in `{o && …}` — see RULE-05 |
| `anchorOrigin={{vertical:'top',horizontal:'right'}}` | `<SnackbarViewport />` | that IS the default placement |
| `autoHideDuration={4000}` | `<SnackbarProvider duration={4000}>` | and it pauses on hover, which yours did not |
| `onClose={(_, reason) => reason !== 'clickaway' && close()}` | `onOpenChange={(open) => !open && close()}` | nothing to filter; fires for every dismissal path |
| `<Snackbar>` wrapper per site | `<SnackbarProvider>` + `<SnackbarViewport />` once at the root | the wrapper is deleted, not ported |
| `<Alert icon={<AiLogo/>} style={{aiPalette}}>` | `<Snackbar severity="ia" title={…} />` | the OpenCTI `nlq` case |
| `<Alert onClose={c}>` | `<Snackbar closeLabel={t('Close')} …/>` | the close control ships by default and dismisses the message itself; there is no `onClose` prop. `closable={false}` removes it |
| a message that is not transient | `<Alert severity={…} …/>` | an inline banner is an Alert |

## Accessibility notes

- The root is a **live region**. `role="alert"` (assertive) for `error` and
  `warning`, `role="status"` (polite) otherwise. Pass `role` to override. Unlike
  `Alert`, the live region earns its keep here: a snackbar is mounted after the
  page, which is exactly when a live region announces.
- **The close control renders by default** and dismisses the message itself —
  there is no handler to wire. `closable={false}` removes it.
- **`actionAltText` is required whenever you pass an `action`**: it is what a
  screen-reader user is told when the message has already gone. Without it the
  control is rendered outside Radix's `Toast.Action`, so it stops dismissing the
  message, and a dev-only warning says so.
- **F8** moves focus to the messages from anywhere in the page.
- **Every viewport is an ARIA landmark.** One per app needs no label; a page
  rendering several must give each a distinct `label`, or two landmarks share a
  name — axe flags it, and it flagged this library's own documentation page.
- `closeLabel` is the component's only user-facing string. It defaults to
  `"Close"` — pass your own translation.
- The severity glyph is decorative; the close control is a real `<button>` with a
  required accessible name and the library's standard focus ring.
- The card is not focusable, does not trap focus and does not focus itself on
  mount — a snackbar that stole focus would interrupt whatever is being typed.
- **Motion respects `prefers-reduced-motion`**: the travel collapses to zero and
  the card fades instead of sliding.
- **Layer caveat, measured.** Every surface here is translucent, so its real
  background is whatever it sits on. The declared contrast ratios hold on
  elevation layers 0, 1 and 2. On a layer-3 surface in dark mode the composited
  wash lightens enough that the IA glyph falls to 2.83:1, under the 3:1 floor for
  a graphical object (text is unaffected — 7.99:1 at worst). See RULE-02.
- No disabled state exists.

## Behavior

- **Responsive:** intrinsic, no breakpoints. The text column shrinks, so a long
  description wraps instead of pushing the action and close controls out of the
  card.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic.
- **Nested theme panels do not work on this component**, for the same reason as
  `Alert` — every colour token it paints is a `:root` alias. Switch the whole page.

## Usage rules

- **RULE-01 — The message goes in `title`.** `description` is a second line, never
  the only one.
- **RULE-02 — Put it over the page, not inside a panel.** A snackbar is a
  top-level transient surface; its wash is translucent, and nesting it in a deep
  elevation layer dilutes the tint (see the layer caveat above).
- **RULE-03 — State the severity.** It is required, and it is the message's
  meaning.
- **RULE-04 — Drop the message on `onOpenChange(false)`.** It is the only signal
  that covers the close control, the timer and a swipe at once.
- **RULE-05 — Never unmount a `Snackbar` in response to `onOpenChange(false)`.**
  A closing card is only animated while it is still rendered: drop it from your
  array there and Radix unmounts it on the spot, so the message vanishes instead
  of sliding out — and nothing warns you. Flip an `open` flag instead and prune
  closed messages later (the next raise is a fine moment; no timer needed).

  ```tsx
  // ✅
  open={message.open}
  onOpenChange={(open) => { if (!open) markClosed(message.id); }}

  // ❌ the exit animation never plays
  onOpenChange={(open) => { if (!open) remove(message.id); }}
  ```
- **RULE-06 — Translate `closeLabel`.** The default is English.
- **RULE-07 — Placement goes on the viewport, never on the card.** One viewport
  per app; `className` on a `Snackbar` is for that one card only.
- **RULE-08 — Keep the message short enough to read before it goes.** The host
  controls how long that is; the card does not.
- **RULE-09 — If it stays on the page, it is an Alert.**

## Out of scope — do not reach for Snackbar here

| Need | Use instead |
|---|---|
| A message that stays in the flow | `Alert` |
| Placement, stacking | `SnackbarViewport` — it ships |
| Auto-hide timing | `duration` on the provider or the message — it ships |
| A different entry/exit motion | override `fds-snackbar-motion`'s keyframes in your own CSS — but no Figma frame draws motion yet, see /status |
| A modal that demands a decision | `Dialog` |
| A custom icon | `severity="ia"` if it is the AI mark; otherwise flag the gap |
| A replaceable close control | not applicable — it is internal by contract |
