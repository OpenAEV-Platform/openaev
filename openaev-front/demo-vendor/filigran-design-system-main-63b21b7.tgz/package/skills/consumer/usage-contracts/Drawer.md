# Drawer — usage contract

- **Component:** `Drawer`, `DrawerTrigger`, `DrawerClose`, `DrawerContent`,
  `DrawerHeader`, `DrawerSubHeader`, `DrawerTabs`, `DrawerBody`, `DrawerFooter`
  · **Package:** `@filigran/design-system`
- **Source of truth:** `Drawer.rfc.md` + `Drawer.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-dialog` (the same primitive as `Dialog`)

> Read this before using `Drawer`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { DrawerMeta } from "@filigran/design-system/meta"`.

## Intent

A **modal side panel** on the right edge, used to create, edit or inspect one
object while the page stays in view behind it. Four widths (`sm` 420 / `md` 640
/ `lg` 960 / `xl` 1360 px, default `lg`), a header with the title and its
context, an optional fixed sub-header, and one scrolling body that holds the
content and the footer. The panel sits on elevation layer 2. A drawer may open
one second-level drawer above itself.

## Usage rules

- **RULE-01 — An object, beside the page.** Use Drawer to create, edit or
  inspect one object while the page stays in view. Use `Dialog` for a
  confirmation or a short focused question. Never use Drawer for a permanent
  side menu, a knowledge bar or a bottom toolbar: those are docked panels, not
  drawers.
- **RULE-02 — `lg` unless the content says otherwise.** Leave `size` at its
  default. Choose `sm` or `md` only for a short form of a few fields, and `xl`
  only for side-by-side or table content. Never pick a width to avoid
  scrolling: the body scrolls.
- **RULE-03 — One line of title, context around it.** The `title` is the
  object's name or the action ("Create a malware"), on one line; it truncates
  and shows the full text in a tooltip, never wraps. Put a category above it
  with `overline`, never as a prefix in the title. Put a short status beside it
  with `badge`: a `Badge` for a dot or a count, a `Chip` for a labelled value
  such as a score.
- **RULE-04 — Three icons, then a menu.** In `md`, `lg` and `xl`, `actions`
  holds at most three IconButtons plus one text Button or one Combobox. One
  more action and every action moves into a single `⋮` (`ellipsis-vertical`)
  IconButton menu. In `sm`, every action goes in the `⋮` menu and a Combobox
  is forbidden. The title's 280 px wins over adding actions: if the actions
  leave it less, move them into the `⋮` menu. The close or back control is
  never squeezed out: when the panel itself is too narrow, the title truncates
  further instead.
- **RULE-05 — The footer belongs to the body.** `DrawerFooter` is the last
  child of `DrawerBody`, never its sibling: it scrolls with the content and
  sits at the bottom when the content is short. When the drawer holds a form,
  the form is the body — `<DrawerBody asChild><form>…fields…<DrawerFooter />
  </form></DrawerBody>` — so the submit button stays inside its form.
- **RULE-06 — No buttons for auto-saving forms.** A form that saves each field
  on change or blur renders no `DrawerFooter`. A footer with nothing to submit
  is a decoy.
- **RULE-07 — Saving blocks everything.** While a submit is in flight, set
  `busy` on `DrawerContent`, `loading` on the primary button, and disable the
  fields. Nothing closes and nothing changes until the request ends.
- **RULE-08 — Loading data is a Spinner, not a second drawer.** While the
  drawer's own data loads, render a `Spinner` centred in `DrawerBody` and no
  footer. Never open a placeholder drawer and swap it for the real one.
- **RULE-09 — Unsaved changes ask first.** When closing would lose user input,
  intercept `onEscapeKeyDown`, `onInteractOutside` and the close control, and
  confirm in a `Dialog` (`size="sm"`). Never silently disable Escape or the
  overlay click.
- **RULE-10 — One second level, never a third.** A drawer may open one drawer
  above itself. The second level shows a back control instead of the close
  control, is at least as wide as the first, and Escape or a click on the
  overlay brings the user back to level 1. Anything deeper opens a `Dialog`.
- **RULE-11 — Fixed zone for tabs and list tools.** Tabs go through
  `DrawerTabs`, with the `TabsList` in `DrawerSubHeader` and each
  `TabsContent` in `DrawerBody`. A list drawer's search, filters and creation
  buttons go in `DrawerSubHeader` too, so they stay visible while the list
  scrolls. Nothing else goes there.
- **RULE-12 — People are an AvatarGroup.** Show the users viewing or editing
  the object through `avatars={<AvatarGroup … />}`, with an `aria-label`
  saying who they are. Never line up Avatars or put them in `actions`.
- **RULE-13 — Banner insets are set once.** A product with a classification
  banner sets `--fds-drawer-inset-top` / `--fds-drawer-inset-bottom` once at
  its root. Never offset a single drawer by hand.
- **RULE-14 — No restyling.** Never override the width, the header colours,
  the paddings, the scrim or the motion with `className`. A different look is
  a design request.

## Composition

```tsx
<Drawer open={open} onOpenChange={setOpen}>
  <DrawerTrigger asChild><Button>{t("Create malware")}</Button></DrawerTrigger>
  <DrawerContent busy={isSubmitting}>
    <DrawerHeader title={t("Create a malware")} closeLabel={t("Close")} />
    <DrawerBody asChild>
      <form onSubmit={submit}>
        {/* fields */}
        <DrawerFooter>
          <DrawerClose asChild><Button priority="secondary">{t("Cancel")}</Button></DrawerClose>
          <Button type="submit" loading={isSubmitting}>{t("Create")}</Button>
        </DrawerFooter>
      </form>
    </DrawerBody>
  </DrawerContent>
</Drawer>
```

- `DrawerHeader` renders the drawer's title itself, so a drawer always has an
  accessible name. Its slots are `overline`, `badge`, `avatars` and `actions`;
  `closeLabel` and `backLabel` name the close and back controls (defaults
  "Close" and "Back" — localise them).
- **Second level.** Render a second `Drawer` inside the first one's
  `DrawerBody`. The control that opens it is that `Drawer`'s own
  `<DrawerTrigger asChild>`, never a button outside it with an `onClick`:
  focus returns to the trigger on close, and without one it falls to the page.
  The second level shows a back control by itself; pass `onBack` to the header
  only to run your own code instead of closing.

```tsx
<DrawerBody>
  <Drawer open={inner} onOpenChange={setInner}>
    <DrawerTrigger asChild><Button>{t("Create an individual")}</Button></DrawerTrigger>
    <DrawerContent size="md">
      <DrawerHeader title={t("Create an individual")} />
      <DrawerBody>…</DrawerBody>
    </DrawerContent>
  </Drawer>
</DrawerBody>
```

- **Tabs.** `DrawerTabs` takes the same props as `Tabs` and keeps the panel's
  column intact: `<DrawerTabs><DrawerSubHeader><TabsList>…</TabsList>
  </DrawerSubHeader><DrawerBody><TabsContent>…</TabsContent></DrawerBody>
  </DrawerTabs>`.
- **Busy.** `busy` disables the close or back control and every `DrawerClose`,
  ignores Escape and the overlay click, and sets `aria-busy` on the panel.
  `DrawerClose` also holds through `asChild`: an anchor or a child passing
  `disabled={false}` cannot close a busy drawer, and the child's own `onClick`
  does not run either.
- **Initial focus** goes to the panel itself, announced with its title; the
  next Tab reaches the first control. To focus a field instead, handle
  `onOpenAutoFocus` on `DrawerContent` and call `event.preventDefault()`.

## Migration from MUI

| Source usage | FDS equivalent | Notes |
|---|---|---|
| OpenCTI `<Drawer title open onClose>` | `<Drawer open onOpenChange={(o) => !o && onClose()}><DrawerContent><DrawerHeader title={…} />…` | |
| OpenCTI `size="small" \| "medium" \| "large" \| "extraLarge"` | `size="sm" \| "md" \| "lg" \| "xl"` | `extraLarge` changes from 90vw to 1360 px |
| OpenCTI `controlledDial={Dial}` | `<DrawerTrigger asChild>{dialButton}</DrawerTrigger>` | the dial renders the button; keep its label |
| OpenCTI children `({ onClose }) => …` | `DrawerClose`, or the controlled `open` state | never clone children to inject `onClose` |
| OpenCTI `context={users}` | `avatars={<AvatarGroup items={users} aria-label={t("Users viewing this entity")} />}` | RULE-12 |
| OpenCTI `header={<…/>}` | `actions={…}` | respect the per-width limits (RULE-04) |
| OpenCTI `subHeader={{ left, right }}` | `DrawerSubHeader` with the search left and the buttons right | RULE-11 |
| OpenCTI `FormButtonContainer` at the end of the form | `DrawerFooter`, in place, inside the form; the form becomes `<DrawerBody asChild>` | RULE-05 |
| OpenAEV `<div style={{ float: 'right', marginTop: 20 }}>` buttons | `DrawerFooter`, in place | RULE-05 |
| XTM CRQ `DrawerForm` + `DrawerFormActions` / `DrawerFormFooter` | `<DrawerBody asChild><form>` + `DrawerFooter` | RULE-05 |
| OpenCTI / OpenAEV paper offset by the banner height | host CSS `--fds-drawer-inset-top` / `--fds-drawer-inset-bottom` set once at the app root | RULE-13 |
| OpenCTI loading `<Drawer><Loader /></Drawer>` | `<DrawerBody><Spinner label={…} /></DrawerBody>`, no footer | RULE-08 |
| OpenAEV `<Drawer open handleClose title>` | same as the OpenCTI row | |
| OpenAEV `variant="half"` (50 %) | `size="lg"` (default) | 756 px at a 1512 px viewport becomes 960 px; product review |
| OpenAEV `headerActions` | `actions` | |
| OpenAEV `additionalTitle` / `additionalChipLabel` | `badge={<Chip … />}` | a `Badge` or a `Chip` |
| OpenAEV `disableEnforceFocus` | none | hosted pickers must portal through a library surface, or stay on MUI and be recorded in `LIBRARY-FEEDBACK.md` |
| XTM CRQ `FormDrawer` / `DisplayDrawer` | `Drawer` + `<DrawerContent size="sm" \| "md">` | `w-[30vw] min-w-[420px]` lands between sm and md: product review |
| XTM CRQ `className="w-[55vw] max-w-[960px] min-w-[720px]"` | `size="lg"` | RULE-14 |
| XTM CRQ dirty guard | `onInteractOutside` / `onEscapeKeyDown` + `event.preventDefault()` + a `Dialog` | RULE-09 |
| XTM CRQ `category` | `overline` | |
| XTM CRQ / OpenCTI submit in progress | `busy` on `DrawerContent` + `loading` on the primary Button + disabled fields | RULE-07 |
| MUI `<Drawer variant="permanent \| persistent">` | none | out of scope |

## Accessibility notes

- The panel is `role="dialog"` with `aria-modal="true"`, named by the title
  `DrawerHeader` renders. The rest of the page is hidden from assistive
  technology while the drawer is open. `aria-modal` cannot be unset from the
  call site.
- Keyboard: Tab and Shift+Tab cycle inside the panel. Escape closes the topmost
  drawer only (on a second level, it returns to the first) and is ignored while
  `busy`. On close, focus returns to the trigger.
- The close and back controls are buttons named by `closeLabel` / `backLabel`;
  their icon is decorative.
- `DrawerBody` takes a Tab stop, with the standard focus ring, only while its
  content overflows, so keyboard users can scroll a body that holds nothing
  focusable.
- A cut title keeps its full text as its accessible name. While it is cut, it
  also takes a tab stop, and focus opens the tooltip that shows the full text;
  a title that fits takes no tab stop.
- With `busy`, the panel carries `aria-busy`; the primary button's own
  `loading` announces the state.

## Behavior

- **Responsive:** fixed width per size, capped at `100vw - 32px` on a narrow
  viewport. Full viewport height minus the two banner insets (0 by default).
  The header title gives ground before the close or back control does.
- **Motion:** slides in and out from the right with a fading scrim; under
  `prefers-reduced-motion` it fades without travel.
- **Dark / Light:** no mode-specific logic; tokens switch via `.dark` / `.light`
  and resolve inside layer 2.

## Out of scope — do not reach for Drawer here

| Need | Use instead |
|---|---|
| a left, top or bottom anchor | not in scope: the right edge only |
| a permanent or persistent docked panel that pushes the page (toolbars, knowledge bars, side menus) | not a drawer: a different component, not in the library yet |
| a non-modal drawer | not in scope |
| a full-screen drawer | not in scope |
| a third nesting level | a `Dialog` opened from the second level |
| a resizable side panel (chatbot) | `@filigran/chatbot`, not the library |
| a description line under the title | not in scope: no Figma slot |
| a dirty-form prop | the documented pattern (RULE-09) |
| a confirmation or a short question | `Dialog` |
