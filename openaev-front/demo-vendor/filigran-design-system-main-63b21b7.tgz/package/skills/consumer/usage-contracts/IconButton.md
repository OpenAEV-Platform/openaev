# IconButton — usage contract

- **Component:** `IconButton` · **Package:** `@filigran/design-system`
- **Source of truth:** `IconButton.rfc.md` + `IconButton.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** draft

> Status is draft — API may still change.

> Read this before using `IconButton`. It carries the rules the TypeScript types
> do not encode. For exact prop names/types and contrast pairs, also read
> `import { IconButtonMeta } from "@filigran/design-system/meta"`.

## Intent

A square button that renders a **single icon with no visible text label**. It
shares the variant × priority × size pattern with `Button` and is used for
toolbar actions, close/dismiss buttons, and any action where the icon alone
carries enough context. It **requires an accessible `aria-label`** and should
always be paired with a `Tooltip` for disambiguation.

## Composition

Standalone component, no sub-components. The `icon` prop accepts any
`ReactNode` — use `<Icon>` from the design system, with `gradient="ia"` for IA
variants.

For an icon-only control that is really a **link** (`<a>`, a router `<Link>`),
pass `asChild` and give the anchor as the child; keep passing the glyph through
`icon` exactly as on the button path. This is the supported replacement for
styling an anchor with the raw variants by hand — it preserves native
navigation while keeping the accessible name on the element and the glyph out of
the accessibility tree.

```tsx
<IconButton asChild aria-label="Docs" icon={<Icon name="book-open" />}>
  <a href="/docs" />
</IconButton>
```

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<IconButton><DeleteIcon /></IconButton>` | `<IconButton icon={<Icon name="trash-2" />} aria-label="Delete" />` | Icon via prop, `aria-label` required |
| `<IconButton color="primary">` | `<IconButton variant="default" priority="primary" />` | `color` → `variant` |
| `<IconButton color="error">` | `<IconButton variant="destructive" priority="secondary" />` | Destructive has no primary |
| `<IconButton size="small">` | `<IconButton size="sm" />` | `small` → `sm` |
| `<IconButton disabled>` | `<IconButton disabled />` | Same native prop; use `aria-disabled` instead when a Tooltip must explain why |

## Accessibility notes

- Renders a native `<button>`. `aria-label` is **mandatory** (no visible text)
  and is enforced by the TypeScript interface — it is the button's sole
  accessible name.
- The icon is always wrapped in `<span aria-hidden="true">` so screen readers do
  not announce SVG internals.
- Keyboard: native — `Tab` to focus, `Enter`/`Space` to activate. No deviation.
- **Two disabled states.** `disabled` is the native one: the button leaves the
  tab order and receives no pointer events. `aria-disabled` keeps the tab stop
  and the pointer events, so a `Tooltip` explaining *why* the action is
  unavailable stays reachable by hover and by keyboard focus. Assistive
  technology announces it as disabled in both cases.
- IA coercion: an `ia` variant with `priority="primary"` is silently coerced to
  `secondary` (IA has no primary). Full contrast pairs are in `IconButtonMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints; fixed square dimensions
  (36×36 for `md`, 24×24 for `sm`).
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic in the component.

## Disabled with an explanation — `aria-disabled`

Use `aria-disabled` when the user must be able to find out why the action is
unavailable (a limit reached, a missing permission); use `disabled` when no
explanation is needed.

- **What it keeps:** focus (the tab stop), hover and pointer events, so the
  Tooltip opens on hover and on focus.
- **What it ignores:** activation. A click, `Enter` or `Space` runs no `onClick`;
  on the `asChild` path the child's own `onClick` does not run either and a link
  does not navigate.
- **What still happens:** the click event propagates as usual, so a click-away
  listener on the document (closing a menu elsewhere) still sees it.
- **How it looks:** the disabled colours of its priority, with no hover fill and
  no IA gradient border.

**Keep the Tooltip open when the button is pressed.** `aria-disabled` alone does
not: Radix Tooltip closes on the trigger's `pointerdown`, and again on a
`pointerdown` outside its (portalled) content, which the trigger counts as. So
the explanation disappears at the very moment the user tries the action. Veto
both, for this button only, and announce the reason if the press should be
heard (CustomizePanel does both):

```tsx
const buttonRef = React.useRef<HTMLButtonElement>(null);

<Tooltip>
  <TooltipTrigger
    asChild
    // 1. Radix skips its own close when this handler prevents the event.
    onPointerDown={(event) => event.preventDefault()}
  >
    <IconButton
      ref={buttonRef}
      aria-label="Pin Status"
      aria-disabled
      priority="tertiary"
      size="sm"
      icon={<Icon name="pin-off" size={16} />}
    />
  </TooltipTrigger>
  <TooltipContent
    // 2. A press on the button itself is not a click outside the tooltip.
    onPointerDownOutside={(event) => {
      if (buttonRef.current?.contains(event.target as Node)) event.preventDefault();
    }}
  >
    Max 2 can be pinned. Unpin one first.
  </TooltipContent>
</Tooltip>
```

Only prevent the trigger's `pointerdown` while the button is `aria-disabled`; on
an enabled button the press should close the Tooltip as usual.

## Usage rules

- Always pair with a `<Tooltip>` to give sighted users text context — never use
  a standalone icon-only action without one; icon-only buttons are ambiguous.
- Use `active` for toggle states (bookmark, pin, star).
- IA icon buttons must use `<Icon gradient="ia">` for the gradient fill.
- Destructive has no primary variant — use `secondary` or `tertiary`.

## Out of scope — do not reach for IconButton here

| Need | Use instead |
|---|---|
| a button with a text label | `Button` |
| `loading` state | not supported |
| `edge` layout prop (MUI) | `className` |
| `highlight` gradient-text variant | not applicable — icon-only buttons don't use gradient text |
