# ProductSwitcher — usage contract

- **Component:** `ProductSwitcher` · **Package:** `@filigran/design-system`
- **Source of truth:** `ProductSwitcher.rfc.md` + `ProductSwitcher.meta.ts` (this
  file is a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-dropdown-menu` (indirectly — via the
  library's own `Menu` component)

> Read this before using `ProductSwitcher`. It carries the rules the TypeScript
> types do not encode. For exact prop names/types and contrast pairs, also read
> `import { ProductSwitcherMeta } from "@filigran/design-system/meta"`.

## Intent

`ProductSwitcher` is the `Navbar` header control exposing links to sibling
Filigran products. It is **not** a stateful "current product" selector — there is
no selected/active item to track. It is a static **menu of destination links** to
other Filigran tools (e.g. OpenAEV, XTM Hub), most of which are **external**
(`target="_blank"` + `rel="noopener noreferrer"` + a visible "opens in a new tab"
icon), though at least one real case is conditionally **internal** (an in-app
settings/connection page when the target product isn't connected yet).

The trigger is split in two: the **logo** navigates to the product's own home
page (optional `logoHref` / `logoTo`), while the **chevron** alone opens the
product popover.

## Usage rules

- Consuming products supply their own `options` (sibling-product list, connection
  URLs, per-item conditional external/internal destinations). `ProductSwitcher`
  carries no product-specific business logic (feature gating, connection-status
  detection, etc.).
- **Logo destination:** pass `logoHref` **or** `logoTo`, never both (`logoTo` for
  router navigation, `logoHref` for a plain URL). Point it at the product's OWN
  home page — sibling products belong in `options`.
- Whenever a logo destination is set, pass a **localized** `logoLabel` ("Home",
  "Accueil", …). The `label` fallback only keeps misuse from producing a nameless
  link; shipping on it is a defect and the component warns in development.
- Pass `logoCollapsed` (the mark-only asset) whenever the switcher can render
  inside a collapsible `Navbar` — the 126px wordmark does not fit the 48px rail.
- With a logo destination set, the product menu is intentionally **unreachable
  while the `Navbar` is collapsed** — if a product must switch product without
  expanding the rail, do not set a logo destination.

## Composition

Standalone component. It composes the library's own `Menu` wrappers, not raw
Radix primitives: `Menu` → `MenuTrigger` (logo + conditionally-visible chevron
`IconButton`) → `MenuContent side="bottom" align="end"` → one `MenuItem asChild`
per option, wrapping either an `<a target="_blank" rel="noopener noreferrer">`
(when `href` is set) or a router `Link` (when `to` is set), with `MenuSeparator`
between groups. (`Menu` is itself built on `@radix-ui/react-dropdown-menu`, so the
Radix primitive is present only indirectly — consumers reach for the FDS `Menu`
surface, never the Radix `DropdownMenu.*` parts directly.)

It reads `NavbarContext.collapsed` to decide whether to render the chevron next
to the logo. When `logoHref` / `logoTo` is set, the logo slot is a plain `<a>`
(never a `Menu` part, never `asChild`) so it carries no menu semantics and
no click handler. The forwarded `ref` is a `<button>` in every configuration
except collapsed-with-destination, where it is that `<a>` — so the component
forwards `HTMLElement`.

## Migration from MUI

| MUI usage (opencti `LeftBarHeader` / `PopoverListItem`) | FDS equivalent | Notes |
|---|---|---|
| `<Box component={Link}><img/><IconButton><ArrowDropDown/></IconButton></Box>` + `<Popover><List>{items}</List></Popover>` | `<ProductSwitcher logo={…} label={…} options={…}/>` | Logo-as-content and per-item external/internal polymorphism preserved |
| `<ListItemButton component={…} href/to target rel>…{external && <OpenInNew/>}</ListItemButton>` | `<MenuItem asChild>` wrapping `<a>` / `<Link>` per option | `external` inferred from `href` vs `to`, not a separate prop |
| `<Tooltip title={statusText}>` | `options[].tooltip` | Copy stays product-owned |
| `aria-label={open ? 'Collapse' : 'Expand'}` on chevron | Distinct accessible name (e.g. "More Filigran products") | Avoids clashing with `Navbar`'s own collapse/expand toggle |

## Accessibility notes

- `MenuTrigger` renders a native `<button>` with `aria-haspopup="menu"`
  / `aria-expanded` automatically; `MenuContent` renders `role="menu"`
  with `role="menuitem"` children — appropriate, since each item opens a link.
- When a logo destination is set, the logo slot is a native `<a href>` — a real
  link role, so AT announces it as a link and the browser keeps its native
  contract (Ctrl/Cmd/middle-click → new tab, "copy link address", status-bar
  preview). Nothing intercepts its click — it is deliberately not a Radix
  `asChild` trigger or an `onClick` prop.
- Keyboard is entirely inherited from the underlying Radix dropdown-menu (via
  `Menu`): Enter/Space/arrows open/navigate; Escape closes and returns focus to
  the trigger.
- **External links get an accessible-name suffix, not just an icon:** each
  external option's name becomes `${label} (opens in a new tab)` via a
  visually-hidden span, with the visible `OpenInNew` icon `aria-hidden="true"`.
  This corrects opencti's real icon-only gap rather than reproducing it.
- A logo destination creates exactly **two tab stops** in reading order (logo
  link, then chevron `IconButton`), each with its own accessible name
  (`logoLabel` vs `label`). Without a destination there is one tab stop.
- **No live region** (`aria-expanded` suffices) and **no `aria-current`** — there
  is no "current selection" concept here.

## Behavior

- **Responsive:** intrinsic, no breakpoints. Trigger content (logo-only vs
  logo+chevron) is driven by `NavbarContext.collapsed`, not viewport size.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`. Product
  logos are dual-mode: split by SVG fill into an icon-color group
  (`fill-highlight`) and a wordmark-color group (`fill-default`), both dual-mode
  tokens. This requires **inline SVG** rendering — an externally-referenced
  `<img src>` SVG cannot react to a light/dark toggle.

## Edge cases seen in products

- **Per-item external/internal polymorphism is real:** XTM Hub's entry
  conditionally becomes an internal settings link when the user has access but
  hasn't connected yet. The API supports this per option, not as a global mode.
- **opencti's `OpenInNew`-icon-only external indicator is a real WCAG gap** —
  flagged and improved on (accessible-name suffix), not reproduced.
- **openaev's `TenantSwitcher` is explicitly NOT this component's source of
  truth** — it is a different component with a different "selected" concept.

## Out of scope — do not reach for ProductSwitcher here

| Excluded feature | Reason / use instead |
|---|---|
| Stateful "current product" selection (`value` / `onValueChange`) | Not a switcher with a selected value — it is a static links menu |
| Loading / `switching` state | Link navigation is immediate; no async operation exists |
| Enterprise Edition / feature-gating logic | Product-specific commercial concern, not a design-system responsibility |
| Connection-status detection / tooltip copy generation | Product-owned business logic — the component only exposes a `tooltip` slot |
| Empty-state messaging (`emptyStateLabel`) | No real designed-for empty-options scenario |
| `logoOnClick` / any imperative logo handler | A destination, not a callback — a real `<a href>` keeps native new-tab behavior |
| Reaching the product menu while collapsed **and** a logo destination is set | Deliberate: expand the rail to switch product |
| A visible tooltip on the logo link | Accessible name only — the component stays visually identical to today |
