# ButtonGroup — usage contract

- **Component:** `ButtonGroup` · **Package:** `@filigran/design-system`
- **Source of truth:** `ButtonGroup.rfc.md` + `ButtonGroup.meta.ts` (this file is
  a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** none — hand-rolled roving tabindex

> Read this before using `ButtonGroup`. It carries the rules the TypeScript types
> do not encode. For exact prop names/types and contrast pairs, also read
> `import { ButtonGroupMeta } from "@filigran/design-system/meta"`.

## Intent

A segmented control: a horizontal run of icon-only buttons that share one
selected value, used as a **view / filter / period switch** (e.g. "cards vs lines
vs graph"). It replaces MUI `ToggleButtonGroup` + `ToggleButton`. It is single-
choice by construction.

## Usage rules

- Use for **mutually exclusive views of the same data**, never for actions. Two
  buttons that do two different things are two `Button`s.
- **2 to 5 items.** Beyond that, use a Select.
- Every item needs a Tooltip in practice: the icon carries the meaning visually,
  `aria-label` carries it to assistive tech, and the Tooltip is what a sighted
  mouse user gets.
- Never use it as a container to glue unrelated toolbar buttons together.

## Composition

Compound. `ButtonGroup` (container, owns selection + roving focus) and
`ButtonGroupItem` (the segment). The container reads its children to assign each
item its index, position and selected state through context — **items are never
positioned by hand**, so conditional children (`{cond && <ButtonGroupItem/>}`)
are fine. An item can still carry its own `onClick`; it fires independently of
the group's `onValueChange`.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<ToggleButtonGroup exclusive value={v} onChange={(e,x)=>set(x)}>` | `<ButtonGroup value={v} onValueChange={set}>` | `exclusive` is implicit; the event arg is dropped |
| `<ToggleButtonGroup size="small">` | `<ButtonGroup size="sm">` | |
| `<ToggleButton value="cards" aria-label="cards"><ViewModuleOutlined/></ToggleButton>` | `<ButtonGroupItem value="cards" aria-label="cards" icon={<Icon name="layout-grid" size={16}/>} />` | glyph moves from child to `icon` |
| `<ToggleButton selected={...}>` | *(drop)* | derived from the group value |
| Lone `<ToggleButton>` outside a group | `<IconButton active>` | **not this component** |
| `<ToggleButtonGroup value="fake">` (visual glue) | plain flex row | not a segmented control |

## Accessibility notes

- Semantics: the container is `role="radiogroup"`; each item is a `<button>` with
  `role="radio"` and `aria-checked`. A segmented control is a single-choice
  picker.
- `aria-label` is a **required** prop on each item — the item has no text node, so
  omitting it produces an unnameable control.
- Keyboard (roving tabindex, WAI-ARIA radiogroup): the group is **one** tab stop;
  `Tab` enters at the selected (or first) item; `←/→/↑/↓` move to and select the
  next/previous item, wrapping; `Home`/`End` jump to first/last; `Space`/`Enter`
  select the focused item. Disabled items are skipped and are never the entry
  point. Selection follows focus on arrow keys. Full contrast pairs are in
  `ButtonGroupMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints; an `inline-flex` run sized by its
  items.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic in the component.

## Out of scope — do not reach for ButtonGroup here

| Need | Use instead |
|---|---|
| text labels on items | not available (icon-only; stays on MUI until a labelled symbol exists) |
| multi-select | not applicable (single-choice only) |
| vertical orientation | not available |
| split button (group + dropdown) | a different pattern |
| a lone toggle button | `IconButton active` |
| gluing unrelated toolbar buttons | a plain flex row |
| tone / colour axis | one tone only |
