# Tabs — usage contract

- **Component:** `Tabs` · **Package:** `@filigran/design-system`
- **Source of truth:** `Tabs.rfc.md` + `Tabs.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-tabs`

> Read this before using `Tabs`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { TabsMeta } from "@filigran/design-system/meta"`.

## Intent

A compound navigation component that lets a user switch between mutually exclusive
views within the same context, exposing one panel at a time. It replaces the MUI
`Tabs`/`Tab` (and `@mui/lab` `TabContext`/`TabList`/`TabPanel`) surface, built on
`@radix-ui/react-tabs` for correct `tablist`/`tab`/`tabpanel` semantics and
roving-focus keyboard navigation.

## Edge cases seen in products

- **Panels are hand-rolled far more than `@mui/lab`.** OpenCTI overwhelmingly uses
  `currentTab === N && <View/>` conditional rendering. → `TabsContent` is optional
  in FDS; when panels are managed externally, omit it and declare `panels="external"`.
- **Routing-integrated tabs recur in all three products** (`<Tab component={Link}>`,
  `TabsTrigger asChild <Link>`). → first-class via `asChild`.
- **String tab values, not indices**, are common → native with Radix `value: string`.
- **A "tab" that opens a dropdown** (OpenCTI `TabWithDropDownMenu`) is semantically a
  menu, not a tab → use `TabsMenuTrigger`, never a real `role="tab"`.

## Composition

Compound. Exposed sub-components: `Tabs` (Root — context, activation mode, `panels`
strategy), `TabsList` (the `role="tablist"` bar + `actions` sibling + automatic
scroll overflow), `TabsTrigger` (`role="tab"`, with `icon`/`badge` slots or `asChild`),
`TabsContent` (`role="tabpanel"`, optional).

Panels may be omitted entirely when managed externally (conditional render / CSS /
a router outlet) — `aria-selected`, the roving tab order and keyboard navigation are
unaffected. But Radix emits `aria-controls` on every trigger regardless, so omitting
the panel without declaring `panels="external"` leaves the attribute dangling.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Tabs value={v} onChange={(_, val)=>set(val)}>` | `<Tabs value={v} onValueChange={set}>` | `onValueChange` gives the value directly (no event) |
| `<Tab label="Overview" value="ov" />` | `<TabsTrigger value="ov">Overview</TabsTrigger>` | label → children; must be inside `<TabsList>` |
| `<Tab component={Link} to="/x" value="x" label="X" />` | `<TabsTrigger value="x" asChild><Link to="/x">X</Link></TabsTrigger>` | routing tabs; declare `panels="external"` and mark the current anchor `aria-current="page"` |
| `<Tab disabled label="X" />` | `<TabsTrigger value="x" disabled>X</TabsTrigger>` | native disabled |
| `currentTab===0 && <View/>` | keep under `<Tabs panels="external">`, or `<TabsContent value="ov"><View/></TabsContent>` | `TabsContent` optional; the panel-less shape must declare `panels="external"` |
| `<TabContext><TabList><TabPanel keepMounted>` | `<Tabs><TabsList>…</TabsList><TabsContent forceMount>` | `forceMount` = `keepMounted` |
| `<Tabs variant="fullWidth">` | — | out of scope |
| `<Tab icon={…} />` | `<TabsTrigger icon={<Icon …/>}>…</TabsTrigger>` | decorative, aria-hidden |
| MUI Badge on a tab | `<TabsTrigger badge={n} badgeColor="brand\|error" badgeMax badgeLabel badgeInvisible>` | decorative; `badgeLabel` for i18n (else English `${badge} items`); clickable badge → `asChild` |

## Accessibility notes

- Radix provides `role="tablist"` / `role="tab"` / `role="tabpanel"` and manages
  `aria-selected`, `aria-controls`, `aria-labelledby` automatically. `actions`, the
  scroll arrows and fade overlays are DOM **siblings** of the tablist, never children
  (a tablist may contain only `role="tab"` children).
- **`aria-controls` and the panel-less tab set.** Radix computes `aria-controls`
  from the trigger's `value`; with no panel rendered it points at nothing (axe:
  critical `aria-valid-attr-value`). `panels="external"` drops the attribute for that
  tab set. An explicit `aria-controls` on a trigger overrides both.
- Keyboard: arrow keys move focus **without activating** (manual activation is the
  default); Enter/Space activates; Tab moves to the panel. With `actions`, order is
  active trigger → scroll-right arrow (while overflowing) → actions → panel. In
  `orientation="vertical"` the roving axis rotates to ↑/↓.
- `TabsMenuTrigger` is a **menu button** (`aria-haspopup="menu"`), not a `role="tab"`;
  Enter/Space/↓ open its dropdown, Escape closes it, and focus return is modality-aware.
- Active tab is differentiated by **shape + weight + colour** (indicator AND semibold
  AND brand colour) — never colour alone. Overflow is signalled by focusable scroll
  arrows, not the decorative fade alone.
- The badge is purely decorative in every combination (no click handler, role, or
  tabIndex); a clickable badge must be composed via `asChild`. Its accessible name
  is `badgeLabel`; with none, it defaults to the English `` `${badge} items` ``, so
  a translated product must pass `badgeLabel` to announce the count in the user's
  language.

## Behavior

- **Responsive:** intrinsic, no breakpoints. On horizontal overflow the tablist
  scrolls and mounts scroll-arrow buttons + a decorative edge fade automatically;
  `actions` stay fixed. Trigger widths are intrinsic (label + padding). No minimum
  width floor is imposed, so the component never forces horizontal page overflow on
  a small viewport.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic.

## Usage rules

- **RULE-01 — Same-context views only.** Alternate sub-views of a single resource,
  one panel visible at a time. Not for primary application navigation (that is
  `Navbar`), and not for content to compare side by side.
- **RULE-02 — Routing tabs are `asChild` with a real anchor.** Use
  `<TabsTrigger value="x" asChild><Link to="/x">X</Link></TabsTrigger>` and derive
  the active `value` from the URL — never `onValueChange={() => navigate(…)}`, which
  destroys `⌘`-click, middle-click and "open in a new tab". Also declare
  `panels="external"` and mark the current anchor `aria-current="page"`.
- **RULE-03 — Panels: one strategy, not both, and declare which.** Either wrap every
  panel in `TabsContent` (`panels="content"`, the default) or manage them all
  externally and omit it — never mix. The external strategy must say so:
  `<Tabs panels="external">`. Use `forceMount` (= MUI `keepMounted`) only when a
  panel must survive deactivation.
- **RULE-04 — `activationMode` stays `manual`.** Opt into `automatic` only when
  switching is instant and side-effect free; otherwise arrow-key browsing fires a
  request per tab.
- **RULE-05 — Labels are short; overflow scrolls, never wraps.** When the bar runs
  out of room it scrolls with arrows + an edge fade automatically — do not shrink or
  wrap labels to fit.
- **RULE-06 — Icons are decorative and leading; never icon-only.** Pass a 16×16
  `Icon` via `icon`; it is `aria-hidden`, so the label must carry the meaning.
- **RULE-07 — The badge is decorative, never an action.** A clickable badge/chip is
  composed with `TabsTrigger asChild`. Reserve `badgeColor="error"` for genuine
  error/attention counts; cap a numeric badge with `badgeMax` (`${badgeMax}+`);
  hide with `badgeInvisible`. **A translated product must pass `badgeLabel`** — its
  absence leaves the badge's accessible name as the hardcoded English
  `` `${badge} items` `` (the i18n defect PR #214 fixed). Pass
  `badgeLabel={t('…', { count })}`; the visible digits are unchanged.
- **RULE-08 — `actions` acts on the whole set.** Right-aligned controls tied to the
  entire view (Export, New, status) go in `TabsList.actions`, secondary first,
  primary last. Never place navigation there.
- **RULE-09 — Disable a tab sparingly, explain from the outside.** Prefer hiding an
  unavailable tab over disabling it. A disabled trigger is `pointer-events-none`, so
  wrap it in the `Tooltip`, not the reverse.
- **RULE-10 — Use `orientation="vertical"` for a rail, never fake one.** Vertical
  tabs are native; do not simulate a rail by restyling a horizontal `TabsList`.
- **RULE-11 — A tab is not a menu trigger.** If a "tab" opens a dropdown instead of
  revealing a panel, use the dedicated `TabsMenuTrigger` part (a menu button, not a
  `role="tab"`). `TabsTrigger asChild` is not a valid substitute — it still renders a
  `role="tab"`.

## Out of scope — do not reach for Tabs here

| Need | Use instead |
|---|---|
| `variant="fullWidth"` (equal-width tabs) | distribute widths with `className` if truly needed |
| Tab used as a dropdown-menu trigger | `TabsMenuTrigger` |
| `sx` prop | `className` (Tailwind) |
| Standalone multi-severity Badge/Chip | tracked separately; `TabsTrigger.badge` covers only the in-tab count |
