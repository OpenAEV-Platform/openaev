# Slider — usage contract

- **Component:** `Slider` · **Package:** `@filigran/design-system`
- **Source of truth:** `Slider.rfc.md` + `Slider.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-slider`

> Read this before using `Slider`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { SliderMeta } from "@filigran/design-system/meta"`.

## Intent

Slider lets the user pick a numeric value — or a range — along a track by dragging
a thumb or stepping with the keyboard. It maps to MUI `Slider` and is built on
`@radix-ui/react-slider` (`role="slider"`, `aria-valuemin/max/now`, arrow stepping).
The Figma "Slider Field" pairs the track with a label, an info affordance, and a
help line, matching the rest of the Inputs family. Use it when the user picks an
approximate value in a continuous, bounded range and the handle position aids the
choice — thresholds, scores, percentages.

## Edge cases seen in products

- **Single-value bounded numeric input** is the only observed pattern. No two-thumb
  MUI usage exists in any product.
- **Every site is wrapped** (Formik, react-hook-form, or redux-form). The wrapper
  owns value and change, so the FDS surface that matters is `value` / `onValueChange`
  / `onValueCommit`.
- A value label that shows a **word, not a number** is common (confidence-level
  names, opinion labels) — any future value bubble must accept a formatter.
- One site colours the thumb dynamically by comparing score to target — no token
  path exists for this; it is an explicit non-goal.

## Composition

Standalone component. `<Slider>` renders the Figma "Slider Field" from props. When
no `label` or `helperText` is given it returns the bare control with no wrapper, so
it can sit inside an existing field layout.

```tsx
<Slider
  label="Confidence"
  helperText="Between 0 and 100"
  min={0}
  max={100}
  step={5}
  value={[score]}
  onValueChange={([v]) => setScore(v)}
/>
```

One thumb is rendered per value entry, so a two-element value is a range at no
extra API cost. Single value remains the primary path.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Slider value={v} onChange={(e, val) => fn(val)} />` | `<Slider value={[v]} onValueChange={([val]) => fn(val)} />` | `number` → `number[]`; the handler loses its event argument |
| `<Slider onChangeCommitted={(e, v) => save(v)} />` | `<Slider onValueCommit={([v]) => save(v)} />` | Same signature change |
| `<Slider min={0} max={100} step={5} />` | identical | 1:1 |
| `<Slider disabled />` | identical | The control recolours (range + thumb → `--icon-disabled`), no opacity |
| `<Slider aria-labelledby="x" />` | identical, **or** `label="…"` | FDS label is associated automatically |
| `<Slider value={outOfRange} />` | **clamp before passing** | ⚠️ MUI clamps; Radix does not — it reports the value verbatim to assistive tech |
| `<Slider name="score" />` (range value) | field submitted as **`score[]`** | ⚠️ Radix suffixes `[]` once the value holds more than one entry; single-value sliders are unaffected |
| `<Slider marks />` | — | **No equivalent** (blocks migration) |
| `<Slider valueLabelDisplay="auto" valueLabelFormat={fn} />` | — | **No equivalent** (blocks migration) |
| `<Slider size="small" />` | — | No equivalent — single density |
| `<Slider sx={…} style={…} />` | `className` | Layout-only overrides port; a dynamic thumb colour does not |

## Accessibility notes

- Radix renders each thumb as a `span` with `role="slider"`, `aria-valuemin`,
  `aria-valuenow`, `aria-valuemax`, `aria-orientation` — the value is exposed to
  assistive tech, not carried by position alone.
- Because the `role="slider"` element is a `span`, the visible label is associated
  through `aria-labelledby` on every thumb; `helperText` is wired via
  `aria-describedby` (a consumer-supplied `aria-describedby` is merged, not replaced).
  When no visible label is given, `aria-label` / `aria-labelledby` are forwarded to
  every thumb.
- Keyboard (inherited from Radix): `Tab` focuses the thumb; arrow keys step by `step`;
  `Home`/`End` jump to `min`/`max`; `PageUp`/`PageDown` take a larger step; values
  never cross `min`/`max` or `minStepsBetweenThumbs`. Disabled removes thumbs from
  the tab order.
- Focus adds the repo's standard focus ring on top of the Figma halo (the halo alone
  cannot satisfy focus-visibility contrast and does not distinguish focus from hover).

## Behavior

- **Responsive:** the track fills its container (`w-full`); height is fixed at 4px.
  No breakpoints. The thumb deliberately overflows the rail by 6px each side and is
  not clipped.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic. Caveat: the rail token is not elevation-aware, so on an
  elevated surface its contrast drifts.

## Usage rules

- **RULE-01 — When to use.** Pick an approximate value in a continuous, bounded
  range where the handle position aids the choice.
- **RULE-02 — Precise values.** When a precise value is required, use
  `<Input type="number">` or pair a slider with a numeric input. Do not use Slider
  for unbounded ranges.
- **RULE-03 — Single vs range.** Single-value is the primary path; a range (two
  thumbs) comes free with the array contract but is secondary.
- **RULE-04 — No error state.** Slider has **no `error` prop** (nor do Checkbox and
  Radio). Validation is carried by the surrounding form field, which owns the
  message and error styling.
- **RULE-05 — Clamp before passing.** The component reports the value it is given;
  clamping to `[min, max]` is the caller's responsibility.

## Out of scope — do not reach for Slider here

| Need | Use instead |
|---|---|
| `marks` / tick labels | not drawn in Figma — deferred |
| `valueLabelDisplay` / `valueLabelFormat` (value bubble) | deferred (must accept a formatter when it lands) |
| Vertical orientation | not shipped |
| `size` variants | single density |
| `sx` / `style` | `className` only |
| Dynamic per-instance thumb colour | no token path — not applicable |
| `react-compound-slider` range slider | different primitive — a separate migration |
