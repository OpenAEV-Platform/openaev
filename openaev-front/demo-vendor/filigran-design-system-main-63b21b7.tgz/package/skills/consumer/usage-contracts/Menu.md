# Menu — usage contract

- **Component:** `Menu` · **Package:** `@filigran/design-system`
- **Source of truth:** `Menu.rfc.md` + `Menu.meta.ts` (this file is a published
  subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-dropdown-menu`

> Read this before using `Menu`. It carries the rules the TypeScript types do not
> encode. For exact prop names/types and contrast pairs, also read
> `import { MenuMeta } from "@filigran/design-system/meta"`.

## Intent

The library's **action-menu primitive**: a floating panel of commands opened by
a composable trigger. It replaces the products' hand-rolled MUI `Menu` /
`Popover` + `MenuList` menus and provides the hovered/selected row treatment
`Combobox multiple` needs. `Menu` is for **commands**, not for form values.

## Composition

**Compound.** Seven exported sub-components, each a real `forwardRef` wrapper
(never a raw Radix re-export):

`Menu` (Root), `MenuTrigger`, `MenuContent`, `MenuItem`, `MenuGroup`,
`MenuLabel`, `MenuSeparator`. Sub-menus add `MenuSub` / `MenuSubTrigger` /
`MenuSubContent`.

```tsx
<Menu>
  <MenuTrigger asChild>
    <IconButton aria-label="Actions" icon={<Icon name="ellipsis-vertical" size={16} />} />
  </MenuTrigger>
  <MenuContent align="end">
    <MenuGroup>
      <MenuLabel>Grouped options</MenuLabel>
      <MenuItem startIcon={<Icon name="pencil" size={16} />} onSelect={onEdit}>Update</MenuItem>
      <MenuItem asChild endIcon={<Icon name="external-link" size={16} />}>
        <a href="https://docs.filigran.io" target="_blank" rel="noopener noreferrer">Documentation</a>
      </MenuItem>
    </MenuGroup>
    <MenuSeparator />
    <MenuItem disabled>Delete</MenuItem>
  </MenuContent>
</Menu>
```

`MenuItem` supports `startIcon` / `endIcon` / `selected`. Under `asChild` the
row content is re-parented into the child (a real `<a>`), so the whole clickable
area stays inside the link and the icon/selected slots keep working.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `useState(anchorEl)` + `<IconButton onClick={setAnchorEl}>` | `<MenuTrigger asChild><IconButton …/></MenuTrigger>` | Anchor state disappears — the trigger is the anchor |
| `<Menu anchorEl open onClose>` | `<Menu><MenuTrigger/><MenuContent>` | `open`/`onOpenChange` only if the menu must be controlled |
| `anchorOrigin` / `transformOrigin` corner pairs | `<MenuContent side="bottom" align="end">` | Corners collapse into `side` + `align` |
| `<MenuItem onClick={fn}>` | `<MenuItem onSelect={fn}>` | Radix closes the menu itself; `event.preventDefault()` to keep it open |
| `<MenuItem disabled>` | `<MenuItem disabled>` | Real disabled tokens, not an opacity dim |
| Menu dismissed by pressing `Tab` | **`Tab` no longer dismisses** | ⚠️ Behaviour change — `Escape` is the only keyboard dismissal. See below |
| `<MenuItem component={Link} to="/x">` | `<MenuItem asChild><Link to="/x">…</Link></MenuItem>` | Keeps `⌘`-click / middle-click / open-in-new-tab |
| `<MenuItem component="a" href="…">` | `<MenuItem asChild><a href="…">…</a></MenuItem>` | Add `target`/`rel` yourself |
| `<MenuItem selected>` | `<MenuItem selected>` | Adds a `check` indicator + `aria-current="true"` |
| `<ListItemIcon>` inside a `MenuItem` | `<MenuItem startIcon={<Icon name="x" size={16} />}>` | Icons go through `Icon` + the registry |
| `<Divider />` between items | `<MenuSeparator />` | |
| `<ListSubheader>` / bare header | `<MenuLabel>` inside `<MenuGroup>` | |
| `<MenuItem value="x">` inside `<Select>` | `<SelectItem value="x">` | Not a menu — 66% of `MenuItem` sites |
| `<MenuList component="nav">` | `Navbar` / `NavbarItem` | Persistent navigation, not a menu |

> **Read the `Tab` row before migrating.** Every other line is a mechanical
> rename; that one changes behaviour and all 97 product menus inherit it. It is
> not configurable — Radix owns `Tab` inside an open panel — so any flow that
> relied on tabbing away to close must call `onOpenChange(false)` itself or
> accept `Escape`.

## Accessibility notes

- Radix supplies the whole pattern: trigger gets `aria-haspopup="menu"`,
  `aria-expanded`, `aria-controls`; panel gets `role="menu"`; rows get
  `role="menuitem"` (+ `data-disabled`). `MenuGroup` is `role="group"` and is
  wired to its `MenuLabel` via `aria-labelledby` by the library.
- Keyboard: `Enter`/`Space`/`↓` on the trigger opens and focuses the first item;
  `↓`/`↑` move (skipping disabled/labels/separators) and **wrap** (`loop`
  defaults to `true`); `Home`/`End`; typeahead; `Enter`/`Space` activates and
  closes; `Escape` closes and returns focus to the trigger. Two deliberate
  divergences from WAI-ARIA: `↑` on a closed trigger does nothing, and `Tab`
  does **not** close the menu.
- `selected` maps to `aria-current="true"` (not `aria-checked`/`aria-selected`);
  the `check` indicator is decorative. Sub-menu `Escape` closes exactly one
  level (a deliberate correction of Radix's root-close). Full contrast pairs are
  in `MenuMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints; the panel hugs content between
  `min-w-50` (200px) and `max-w-75` (300px); Radix collision detection flips
  `side`/`align`. Height is capped at the available viewport space with
  `overflow-y-auto`, so unbounded lists scroll instead of overflowing.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; also
  layer-agnostic (resolves through whichever `.layer-N` scope it is mounted in).
- **Wrap vs truncate:** `MenuItem` labels **wrap** and grow the row (the panel
  sizes to its content) — they are never truncated or tooltip-clipped.

## Usage rules

- **The trigger is always `asChild` with a real library component** — e.g.
  `<MenuTrigger asChild><IconButton …/></MenuTrigger>`; an icon-only trigger
  needs an `aria-label` on the `IconButton`.
- **`Menu` is for commands, `Select` is for values.** If the control writes into
  a form field, use `Select`.
- **A navigating row must be a real anchor** — `<MenuItem asChild><a …>` /
  `<Link …>`, never `onSelect={() => navigate(…)}` (which breaks `⌘`-click,
  middle-click, open-in-new-tab).
- **Explain a disabled row from the outside** — disabled rows are
  `pointer-events-none`, so wrap the `MenuItem` in the `Tooltip`, not the reverse.
- **36px is a floor** (`min-h-9`), not a fixed height — long labels grow the row.
- **Do not restyle the panel** — no `className` overriding background, radius,
  shadow or padding on `MenuContent`; use `side` / `align` / `sideOffset`.
- Icons go through `Icon` and the registry at `size={16}`.
- Leave `loop` alone unless you mean it (defaults to `true`).
- A sub-menu is the only supported nesting mechanism (`MenuSub`); keep depth to
  ~two levels.

## Out of scope — do not reach for Menu here

| Need | Use instead |
|---|---|
| select-style options (`value` prop) | `Select` (single) / `Combobox multiple` |
| checkbox items (`MenuCheckboxItem`) | not in v1 — stays on MUI for now |
| radio items (`MenuRadioGroup`) | not in v1 (zero product demand) |
| position-anchored context menus (`anchorReference="anchorPosition"`) | not supported (different primitive) |
| persistent navigation (`MenuList component="nav"`) | `Navbar` / `NavbarItem` |
| a `dense` density prop | single 36px row only |
| panel restyling (`sx`, `PaperProps`) | placement props (`side`/`align`) |
