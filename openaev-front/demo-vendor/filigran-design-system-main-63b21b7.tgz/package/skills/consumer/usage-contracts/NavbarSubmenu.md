# NavbarSubmenu — usage contract

- **Component:** `NavbarSubmenu` · **Package:** `@filigran/design-system`
- **Source of truth:** `NavbarSubmenu.rfc.md` + `NavbarSubmenu.meta.ts` (this
  file is a published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-accordion` (inline/expanded mode) +
  `@radix-ui/react-dropdown-menu` (flyout/collapsed mode)

> Read this before using `NavbarSubmenu`. It carries the rules the TypeScript
> types do not encode. For exact prop names/types and contrast pairs, also read
> `import { NavbarSubmenuMeta } from "@filigran/design-system/meta"`.

## Intent

`NavbarSubmenu` is the compound component for navbar items that expand to reveal
children (e.g. "Analyses" → "Reports" / "Notes" / "External References"). It
renders in one of two modes depending on `NavbarContext.collapsed` (from the
ancestor `Navbar`):

- an **inline accordion** (Radix `Accordion`) when the sidebar is expanded,
  pushing sibling content down; or
- a **flyout menu** (Radix `DropdownMenu`) when the sidebar is collapsed, since
  there is no room to expand inline.

`NavbarSubmenuItem` (the child row) is documented and shipped as part of this
same compound API — exactly as `TabsTrigger` belongs to `Tabs` — and is not a
standalone export.

## Behavior

- **Responsive:** intrinsic, no breakpoints. The accordion ↔ flyout mode switch
  is driven entirely by `NavbarContext.collapsed`, not viewport size.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`, no
  conditional logic.

## Usage rules

- `NavbarSubmenu` always renders `NavbarItem` (with `chevron`) as its trigger in
  both modes — consumers never compose the trigger manually.
- Accordion sections **do not auto-collapse siblings** (`type="multiple"`).
- **Optional collapsed-mode direct link:** setting `href` / `to` makes the
  trigger *also* directly navigable while the ancestor `Navbar` is collapsed
  (matching openaev's `MenuItemGroup`). This is purely additive and opt-in —
  omit both props and the trigger is a pure toggle in both modes. In expanded
  mode `href` / `to` are ignored; a group needing an expanded-mode link renders
  it as its first `NavbarSubmenuItem` child.

## Composition

**Compound component**, two internal render paths sharing one public API:

- **Expanded (`collapsed === false`):** `Accordion.Root type="multiple"` →
  `Accordion.Item` → `Accordion.Trigger` (renders `<NavbarItem chevron>` via
  `asChild`, so the trigger IS a `NavbarItem`) → `Accordion.Content` housing
  `NavbarSubmenuItem` rows.
- **Collapsed (`collapsed === true`):** `DropdownMenu.Root` →
  `DropdownMenu.Trigger` (same `<NavbarItem chevron>` via `asChild`) →
  `DropdownMenu.Content` (`side="right"`, anchored next to the 48px rail) housing
  `DropdownMenu.Item` wrapping each `NavbarSubmenuItem` (via `asChild`, so the
  item can itself be a `Link`).

`NavbarItem` is depended on directly (not duplicated) for the trigger row in
both modes.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Collapse in={open}><List>{children}</List></Collapse>` (expanded) | `<NavbarSubmenu open={open}>{children}</NavbarSubmenu>` | Mode auto-selected; consumer no longer branches on collapse state |
| `<Popover anchorEl={…} open={open}><MenuList>{children}</MenuList></Popover>` (collapsed) | Same `<NavbarSubmenu>`, same children | One component replaces both MUI branches |
| Manual `onClick` toggle, no keyboard/ARIA | `Accordion` / `DropdownMenu` built-ins | Conformance gained "for free" from Radix |
| openaev `<MenuItemGroup component={Link} to={item.path}>` (collapsed-only direct nav) | `<NavbarSubmenu to={item.path} linkComponent={Link}>` | **`linkComponent` is required to keep router semantics.** A bare `<a href>` is a full page reload; `href` is correct only for a real document load |
| `<MenuItem component={Link} to={sub.link}>` inside an open submenu (child rows) | `<NavbarSubmenuItem to={sub.link} linkComponent={Link}>` | Prefer the props (they keep the row body in the library) over `asChild`; `href` for a real document load |

## Accessibility notes

**Deliberate, disclosed trade-off:** the two modes expose *different* ARIA role
trees for structurally the same navigational content.

- **Expanded/accordion mode** — WAI-ARIA disclosure pattern:
  `<button aria-expanded aria-controls>` controlling a plain content region. No
  `role="menu"`. This is the semantically correct pattern for site navigation.
- **Collapsed/flyout mode** — Radix `DropdownMenu` imposes `role="menu"` /
  `role="menuitem"`. Not the purist "correct" role for navigation, but the
  accepted real-world compromise for a 48px icon-rail flyout. Disclosed rather
  than silently accepted.

Keyboard:

- **Flyout (native Radix):** `Enter` / `Space` / `ArrowDown` / `ArrowUp` opens
  the menu; `Escape` closes and returns focus to the trigger; arrows move
  between items; `Tab` closes and moves on.
- **Flyout (added):** hover-to-open for mouse users (short delay), keyboard
  opening unaffected. When `href` / `to` is set, `Enter` navigates instead of
  toggling, and a click only ever navigates (never also flips the flyout).
- **Accordion (native Radix):** arrows move between headers; `Enter` / `Space`
  toggles the focused trigger.
- **Accordion (added):** if the whole `Navbar` collapses while focus is inside
  an open submenu, the item closes and focus returns to its own trigger.
- **No live region** — `aria-expanded` on the trigger is sufficient.
  `aria-haspopup="menu"` applies only to the flyout trigger (set by Radix), never
  the accordion trigger.

## Edge cases seen in products

- **Hybrid accordion/flyout is real** and independently validated by both
  opencti and openaev — a genuine UX need, not invented for this RFC.
- **opencti** had zero custom keyboard handling — a plain `onClick`, no
  `aria-haspopup`/`aria-expanded`. Not reproduced.
- **openaev** set `aria-expanded`/`aria-haspopup`; this component aligns with
  that baseline and goes further (focus-openable flyout, verified Escape/focus
  return, no live region).
- **opengrc** already proved Radix `Accordion` for the inline case in production.
- **Tooltip asymmetry (opencti):** rows were wrapped in `Tooltip` in the
  accordion case but not the flyout. Not reproduced — `NavbarSubmenuItem` wraps
  in `Tooltip` uniformly, only when the row's own text could be truncated.

## Out of scope — do not reach for NavbarSubmenu here

| Excluded feature | Reason / use instead |
|---|---|
| Live region announcing collapsed/expanded changes | `aria-expanded` on the trigger is sufficient — no live region needed |
| `NavbarSubmenuItem` used on its own, outside a `NavbarSubmenu` | It is a real named export, but it has no separate component folder or contract — use it only as part of `NavbarSubmenu`'s compound API (the `Tabs`/`TabsTrigger` precedent) |
| `href` / `to` group-level link honored in expanded mode too | No product usage today; expanded mode already has a fully accessible per-item link via `NavbarSubmenuItem` |
