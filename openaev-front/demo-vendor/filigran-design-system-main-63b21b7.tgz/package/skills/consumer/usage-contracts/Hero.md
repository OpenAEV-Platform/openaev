# Hero — usage contract

- **Component:** `Hero` · **Package:** `@filigran/design-system`
- **Source of truth:** `Hero.rfc.md` + `Hero.meta.ts` (this file is a published
  subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** none (a Hero has no behaviour of its own; it composes on
  `Paper`)

> Read this before using `Hero`. It carries the rules the TypeScript types do not
> encode. For exact prop names/types and contrast pairs, also read
> `import { HeroMeta } from "@filigran/design-system/meta"`.

## Intent

Hero is the introduction surface at the top of a page or a section: a `Paper` on
elevation 1 with two blurred brand accents behind the content, a header row and a
body under a rule. It is a **container, not a layout**. The Figma frames show one
composition (thumbnail, title, subtitle, actions, two statistics); the component
renders that composition when asked to, and anything else when asked otherwise.

What the node pins is a token-backed **default**, and every default has a prop:

| Fixed by design (token, not negotiable) | Consumer's to decide (prop or content) |
|---|---|
| Surface, border and radius come from Paper (`bg-elevation-default`, `border-elevation-subtle-soft`, `radius-sm`) | `elevation` — which layer, default `1` |
| Padding scale `0 · 8 · 16 · 24 · 32` | `padding` — which step, default `24` |
| Gutter scale `0 · 8 · 16 · 24 · 32` | `gap` — which step, default `16` |
| The accents' colour (`brand-primary` at 10 %), blur and geometry — always drawn | nothing: a Hero without its accents is not a Hero |
| Header anatomy: leading slot · title column · trailing cluster, 16 / 8 px apart | Whether there is a header, and what each slot holds |
| Body anatomy: a rule, then a row 8 px apart | Whether there is a body, whether it has the rule (`separator`), what it holds, row or column (`className="flex-col"`) |

## Usage rules

- **RULE-01 — Hero composes on Paper.** A surface with no header/body anatomy is
  a `Paper`; a repeated tile in a grid is a `Card`. A Hero has two uses: the
  introduction at the top of a page or a section, and the spotlight on one
  piece of content (the featured block the Hub draws) — one Hero per page or
  section, above the content it introduces or promotes.
- **RULE-02 — Both parts are optional.** Header only is valid (no rule is drawn);
  body only is valid (pass `separator={false}` so no rule sits under nothing).
- **RULE-03 — The heading level is yours.** Hero and `HeroHeader` paint no text.
  Put a `Text` with `variant="title-md"` and the heading tag the page outline
  needs in the title column; no level is invented.
- **RULE-04 — Density moves through props, never through arbitrary classes.**
  `padding`, `gap` and `elevation` are the only ways to change the frame; every
  step is a literal class with an emission guarantee. `className` still merges
  onto the root for layout (margins, max-width).
- **RULE-05 — The accents are always there, and decorative.** They are
  `aria-hidden`, take no pointer events and paint below every child. There is
  no prop to remove them: a Hero without its accents is a Paper, not a Hero.
  Never rely on them to convey anything.
- **RULE-06 — Overlays portal.** The root clips its overflow (the node's clip
  content). Every library overlay portals to `body`, so a `Menu` or `Tooltip` in
  the actions slot is never cut — `Hero.test.tsx` opens a Tooltip inside a Hero
  and asserts its content renders outside the root; an inline overlay drawn by
  the host is cut at the edge.

## Composition

Compound. Parts — both optional, no fixed order:
`HeroHeader` (slots `icon`, `action`; children are the title column) ·
`HeroBody` (prop `separator`; children are the content row).

```tsx
<Hero>
  <HeroHeader
    icon={<Thumbnail elevation={2}><Icon name="server" size={24} /></Thumbnail>}
    action={<><IconButton icon={<Icon name="rocket" />} aria-label="Launch" /><Button>Action</Button></>}
  >
    <Text as="h1" variant="title-md" className="m-0">Title</Text>
    <Text as="p" variant="content-compact" className="m-0 text-default-secondary">Subtitle</Text>
  </HeroHeader>
  <HeroBody>
    <Paper padding={8}>12 assets</Paper>
  </HeroBody>
</Hero>
```

Root props: `elevation` (`0|1|2|3`, default 1), `padding` (`0|8|16|24|32`,
default 24) — both pass-through to Paper — plus `gap` (`0|8|16|24|32`, default
16). `HeroBody` reads `gap` from the root, so
its inset under the rule always matches the gutter above it.

## Migration from MUI

No MUI counterpart: new. OpenAEV draws the same shape by hand as `DetailHero`
(with its HeroStat and HeroStats helpers) on every entity detail page. Migrate it by
moving the overline, title and chips into `HeroHeader`'s title column, the icon
box into `icon`, the action cluster into `action`, and the stats row into
`HeroBody`; the diagonal wash is replaced by the accents.

| Product usage | FDS equivalent | Notes |
|---|---|---|
| `<DetailHero icon title overline chips action stats />` | `<Hero><HeroHeader icon action>…</HeroHeader><HeroBody>…</HeroBody></Hero>` | Overline, title and chips are the title column's children |
| the HeroStat pill | a `Paper` at `padding={8}` with no fill, a tinted `Icon`, a bold figure and a quiet label | The node's tile has no fill; the glyph is `--icon-alert` or `--icon-highlight` |
| `<Paper sx={{ p: 2 }}>` (16px) | `<Hero padding={16}>` | Same scale as Paper |

## Accessibility notes

- The root is a Paper `<div>` with no role — pass `role="region"` and
  `aria-labelledby` pointing at your title when the Hero is a landmark.
- Nothing in Hero is focusable; the only tab stops are the controls you pass to
  `action`, each with its own focus ring.
- The accents and the separator are decorative and non-gating; text contrast is
  measured on every elevation layer and over the accent wash (pairs in
  `HeroMeta`).

## Behavior

- **Responsive:** intrinsic — the Hero fills its track (`w-full`) and its height
  follows the content. The accents sit at fixed offsets from the top-left and are
  clipped by the root, so a narrow Hero shows less of the second one.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; the
  accent colour is a token in both modes.

## Edge cases seen in products

- A "disconnected" banner (icon, title, one line, one button, no body) — the
  header-only case, RULE-02.
- A header whose title column carries chips under the title — put the chips in
  the title column; the column is a flex column.
- A body holding running text rather than tiles — `HeroBody className="flex-col"`.

## Out of scope — do not reach for Hero here

| Excluded feature | Reason / use instead |
|---|---|
| A repeated tile | `Card` |
| A section title above a surface | `Paper`'s `title` |
| A page header bar | `Header` |
| A background image or media band | Not drawn on any node; a host places its own `<img>` in a `Hero` at `padding={0}` |
| Named size variants (`sm`/`md`/`lg`) | Density is the `padding` × `gap` scale, one API across Paper, Card and Hero |
