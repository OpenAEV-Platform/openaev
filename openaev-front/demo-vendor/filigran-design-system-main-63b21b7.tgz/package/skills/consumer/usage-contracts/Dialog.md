# Dialog — usage contract

- **Component:** `Dialog` · **Package:** `@filigran/design-system`
- **Source of truth:** `Dialog.rfc.md` + `Dialog.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-dialog`

> Read this before using `Dialog`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { DialogMeta } from "@filigran/design-system/meta"`.

## Intent

A **modal overlay** that interrupts the current context to request confirmation,
collect input, or surface focused content. It comes in three sizes (`sm` / `md`
/ `lg`) with toggleable title / content / actions / close slots. Always modal —
there is no non-modal mode.

## Composition

**Compound.** Named sub-component exports (not dot-notation):

```
Dialog, DialogTrigger, DialogContent, DialogTitle, DialogDescription,
DialogBody, DialogFooter, DialogClose
```

- `DialogBody` bounds the middle region so the header and footer stay fixed
  while the body scrolls (use it when content overflows).
- `DialogPortal` and `DialogOverlay` are **not** exported — they are baked into
  `DialogContent`.
- No `AlertDialog` in v1: compose confirm/cancel dialogs from these primitives.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Dialog open={open} onClose={handleClose}>` | `<Dialog open={open} onOpenChange={setOpen}>` | Single `onOpenChange(boolean)` replaces MUI's `onClose(event, reason)` |
| `<DialogTitle>{title}</DialogTitle>` | `<DialogTitle>{title}</DialogTitle>` | Same shape |
| `<DialogContent><DialogContentText>…</DialogContentText></DialogContent>` | `<DialogContent>…</DialogContent>` (free-form children) | No `DialogContentText` — use a plain `Text content-base` inside |
| `<DialogActions>{buttons}</DialogActions>` | `<DialogFooter>{buttons}</DialogFooter>` | Same role |
| `<Dialog maxWidth="md">` | `<DialogContent size="md">` | Rename + moves from Root to Content |
| `<Dialog fullScreen>` | *(excluded)* | No Figma spec |
| `<AlertDialog>…</AlertDialog>` | compose from `Dialog` primitives | Near 1:1 structural mapping |
| `<Modal open onClose>…</Modal>` | `<Dialog open onOpenChange><DialogContent>…</DialogContent></Dialog>` | Same underlying primitive |

## Accessibility notes

- `DialogContent` renders `role="dialog"`, labelled by `DialogTitle`
  (`aria-labelledby`) and optionally described by `DialogDescription`
  (`aria-describedby`). `aria-modal="true"` is set and cannot be overridden.
- Focus is trapped inside the content while open; background siblings are made
  inert (`aria-hidden` + `pointer-events: none`) automatically.
- Keyboard: `Tab` / `Shift+Tab` cycle within the dialog (focus trap); `Esc`
  closes and returns focus to `DialogTrigger`; `Enter` / `Space` on the trigger
  opens it. No deviation from Radix defaults.
- Rendering `DialogContent` without a `DialogTitle` emits a dev-only
  `console.warn` (never in production, never throws).
- Full contrast pairs are in `DialogMeta`.

## Behavior

- **Responsive:** intrinsic per size (fixed widths), centered in the viewport.
  No mobile/fullscreen collapse is specified — check small-viewport needs.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic in the component.

## Usage rules

- Use `Dialog` for confirmations, focused single-task forms, and any content
  that must interrupt the current context.
- Default size is `md` (640px); pick `sm` / `lg` only when content genuinely
  needs less/more width — do not use `lg` merely to fit more text; prefer
  internal scroll within `md`.
- For a destructive-confirmation-over-a-form-with-unsaved-changes, **stack a
  second `Dialog`** rather than disabling backdrop/Escape close. `Dialog` has no
  dirty-form-aware close-prevention prop by design.
- The close icon is always visible by default — only opt out via
  `hideCloseButton` when the footer already offers an unambiguous dismiss action.

## Out of scope — do not reach for Dialog here

| Need | Use instead |
|---|---|
| `AlertDialog` component | compose confirm/cancel from `Dialog` primitives (future wave) |
| `fullScreen` variant (MUI) | not supported |
| non-modal (`modal={false}`) usage | not supported — Dialog is always modal |
| deviating from Radix focus management | not supported |
| a dirty-form close-prevention prop | stack a second confirmation `Dialog` |
