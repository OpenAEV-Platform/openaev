# Chip — usage contract

- **Component:** `Chip` · **Package:** `@filigran/design-system`
- **Source of truth:** `Chip.rfc.md` + `Chip.meta.ts` (this file is a published
  subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** none (styled `<span>` / `<button>` + a composed FDS
  `<IconButton>` for delete)

> Read this before using `Chip`. It carries the rules the TypeScript types do not
> encode. For exact prop names/types and contrast pairs, also read
> `import { ChipMeta } from "@filigran/design-system/meta"`.

## Intent

The compact, single-line token used to display a status, a severity, a tag/label,
an active filter, a selected value in a multi-select, or an entity marker. It
replaces MUI `Chip` and absorbs read-only "badge/label" usages. **One versatile
component:** a single size (24px), a single filled style, a `severity` + entity
color axis, a brand `tone`, an optional leading icon, and an optional delete
affordance. Outlined style, extra sizes, avatars, dots and a persistent
`selected` state are deliberately dropped.

Five measured usage families all map to this one component: status/severity
(read-only, dominant), tag/label, active filter (clickable + deletable), selected
value in a multi-select (deletable), entity / EE marker.

## Usage rules

- **RULE-01 — When to use.** A compact, single-line token representing one piece
  of metadata (the five families above).
- **RULE-02 — Color carries no meaning alone.** `severity`
  (neutral/info/low/medium/high/critical), entity color and brand `tone` are
  redundant cues — the **label text always carries the meaning**. Default to
  `neutral`; use `severity` only when it mirrors a real status, entity color only
  when the value **is** an entity, `tone="tonic"` only for a brand marker.
- **RULE-03 — Read-only vs interactive semantics.** A Chip with neither `onClick`
  nor `onDelete` is a decorative `<span>`, not focusable — do not make static
  chips tabbable. Add `onClick` (→ `<button>`) for filters/navigation, `onDelete`
  (→ deletable ×) to remove a value. Both together → the `×` is a **sibling**
  button, never nested (two tab stops).
- **RULE-04 — Deletable is an IconButton, not a bespoke ×.** Provide a meaningful
  `deleteLabel` (e.g. "Remove {label}"); never ship a bare glyph without an
  accessible name.
- **RULE-05 — Do not reach for excluded variants.** Filled-only, single 24px size.
  No outlined style, no `xs`/`md` size, no `avatar`, no leading `dot`, no
  persistent `selected`/`active`. For a notification count, that is a separate
  future Badge component, not a Chip.
- **RULE-06 — Truncation.** Cap width and ellipsise; expose the **full** label
  through the library's `Tooltip` (opens only while the label is actually
  clipped). The complete label is always the element's own text content, so a
  screen reader never receives only the truncated text. This holds even when the
  chip is `disabled`.

## Composition

Standalone, with one composition. The chip body (label + optional `startIcon`) is
rendered internally. When `onDelete` is set, the trailing `×` is an **instance of
the FDS `<IconButton>`** — its hover/focus/keyboard/ARIA are inherited, not
redefined. When a chip is both clickable and deletable, the `×` `<IconButton>` is
a **sibling** of the clickable body (no button-in-button), producing two distinct
tab stops.

`deleteTabIndex?: number` is the composite-widget opt-out. Default omitted (the
delete button keeps its native Tab stop). Inside a composite like `Combobox`
(where a row of chips is one Tab stop navigated with arrows), pass
`deleteTabIndex={-1}` to remove the stop without making the control inert — it
stays programmatically focusable and still fires `onDelete` on Enter/Space.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Chip label="x" />` | `<Chip label="x" />` | default neutral, filled |
| `<Chip label="x" variant="outlined" />` | `<Chip label="x" />` | drop `outlined` — filled-only |
| `<Chip label="x" color="error" />` | `<Chip label="x" severity="critical" />` | map MUI color → `severity` |
| `<Chip label="x" size="small" />` | `<Chip label="x" />` | drop — single 24px size |
| `<Chip label="x" icon={<Icon/>} />` | `<Chip label="x" startIcon={<Icon/>} />` | leading icon |
| `<Chip label="x" onDelete={fn} />` | `<Chip label="x" onDelete={fn} deleteLabel="Remove x" />` | × = IconButton; provide aria-label |
| `<Chip label="x" onClick={fn} />` | `<Chip label="x" onClick={fn} />` | renders `<button>` |
| `<Chip label="x" onClick={fn} onDelete={fn2} />` | `<Chip label="x" onClick={fn} onDelete={fn2} />` | two tab stops (body + ×) |
| `<Chip style={{ backgroundColor: entityColor }} />` | `<Chip entity="arsenal" />` | entity color via `entity` prop |
| `<Chip avatar={<Avatar/>} />` | `<Chip startIcon={<Icon/>} />` or drop | no avatar slot |
| `@filigran/ui <Badge>` (read-only) | `<Chip severity="…" />` (no onClick/onDelete) | read-only chip = `<span>` |

## Accessibility notes

- **Adaptive semantics:** read-only chip (no `onClick`/`onDelete`) is a decorative
  `<span>`, not focusable, no role — the label carries the meaning. Clickable chip
  is a `<button>`. Deletable `×` is an FDS `<IconButton>` with an accessible
  `deleteLabel`. Button-in-button is forbidden — the two are siblings.
- Keyboard: read-only chips are not in the tab order; a clickable body activates
  on `Enter`/`Space`; the delete `×` inherits IconButton keyboard behaviour.
- The leading icon is purely decorative (`aria-hidden`) — severity/entity meaning
  is always in the label text, never the icon alone.
- Hover/focus/active styling applies **only** to the interactive `<button>`
  rendering; a decorative `<span>` never looks interactive.
- Disabled chips are strictly non-actionable but a truncated disabled chip still
  exposes its full label on hover (via an always-hoverable wrapper). Full contrast
  pairs are in `ChipMeta`.

## Behavior

- **Responsive:** intrinsic width, single 24px height, no breakpoints. In
  wrap-lists (filter bars, multi-select value rows) chips wrap to new lines. Long
  labels truncate (~`max-w-[250px]`) with ellipsis.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic.

## Out of scope — do not reach for Chip here

| Need | Use instead |
|---|---|
| `variant="outlined"` | not applicable (filled-only) |
| additional sizes (`xs`/`md`/`small`/`medium`) | not applicable (single 24px size) |
| `avatar` slot | `startIcon`, or drop |
| leading `dot` indicator | not available |
| persistent `selected`/`active` prop | not available |
| custom `deleteIcon` override | the fixed FDS `<IconButton>` × |
| notification-counter badge (`badgeContent`/dot) | a separate future Badge component |
