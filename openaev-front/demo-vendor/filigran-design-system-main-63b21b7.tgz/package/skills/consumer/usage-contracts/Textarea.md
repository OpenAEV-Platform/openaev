# Textarea — usage contract

- **Component:** `Textarea` · **Package:** `@filigran/design-system`
- **Source of truth:** `Textarea.rfc.md` + `Textarea.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved

> Read this before using `Textarea`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { TextareaMeta } from "@filigran/design-system/meta"`.

## Intent

Multi-line text entry field. OpenCTI and OpenAEV express every multi-line field as
`<TextField multiline>` (measured at 112 authored sites); this is the dedicated
component that replaces them. It is deliberately **smaller than Input**: five states
instead of six (no Success), no character counter, no end-icon slot, no leading icon.
The one piece of anatomy Input does not have is a resize grabber (the native handle).

## Edge cases seen in products

- **No product authors `TextareaAutosize`.** Every multi-line field goes through
  `TextField multiline`, so the migration surface is a prop on another component,
  not a distinct import to swap.
- **`maxRows` is rare** (3 sites, all OpenAEV). Autosize is not a load-bearing
  pattern; `rows` outnumbers it 30 to 1.
- **Error wiring is not uniform.** The library takes `error` as a **string** — both
  Formik and RHF adapters must forward the message, not the boolean.
- **`onBeforePaste` stays in the adapter** — it is a Formik-adapter behaviour, not a
  field-component behaviour.
- **Rich text is a different component.** OpenCTI's `MarkdownField` and `RichTextField`
  are editors, not textareas.

## Composition

Standalone component. No sub-components. Native `<textarea>`, no Radix primitive:
Radix ships no textarea, and every behaviour needed here (label association,
`aria-invalid`, `aria-describedby`, disabled) is native.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<TextField multiline rows={3} />` | `<Textarea rows={3} />` | `multiline` disappears — the component *is* the multi-line case |
| `<TextField multiline minRows={2} maxRows={8} />` | `<Textarea minRows={2} maxRows={8} />` | — |
| `<TextField multiline label="X" required />` | `<Textarea label="X" required />` | marker renders only with a label |
| `<TextField multiline error helperText={msg} />` | `<Textarea error={msg} />` | boolean + message collapse into one string prop |
| `<TextField multiline helperText="hint" />` | `<Textarea helperText="hint" />` | — |
| `<TextField multiline variant="outlined" fullWidth />` | `<Textarea />` | both props dropped, no visual change |
| `<Field component={TextField} multiline rows={4} … />` (Formik) | adapter forwards to `<Textarea rows={4} …>` | the adapter must pass the error **message**, not the boolean |
| `<TextFieldController multiline rows={4} … />` (RHF) | adapter forwards to `<Textarea rows={4} …>` | same |

## Accessibility notes

- Native `<textarea>`. `label` renders a real `<label for>`; with no `label` the
  consumer must supply `aria-label` / `aria-labelledby` (dev-time check). `error`
  sets `aria-invalid="true"` and links the message through `aria-describedby`;
  `helperText` links the same way when there is no error. `required` sets
  `aria-required` whether or not a label is present.
- Keyboard: native, no deviation. One real divergence from Input: **Enter inserts a
  newline and must not submit the form**, and Tab moves focus out rather than
  indenting.
- Focus follows the repo standard focus ring. Disabled is rendered by colour
  substitution, never by an opacity tint.
- `resize` configures the native handle only; its default is the UA default (`both`),
  so anything that omits it is unchanged. Full contrast pairs are in `TextareaMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints. Width comes from the container; height
  comes from `rows`.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic. Every value was resolved in both Figma modes.
