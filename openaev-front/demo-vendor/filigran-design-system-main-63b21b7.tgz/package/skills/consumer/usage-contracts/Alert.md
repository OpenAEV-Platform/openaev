# Alert — usage contract

- **Component:** `Alert` · **Package:** `@filigran/design-system`
- **Source of truth:** `Alert.rfc.md` + `Alert.meta.ts` (this file is a
  published subset; on conflict, those win)
- **RFC status:** review

> Read this before using `Alert`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { AlertMeta } from "@filigran/design-system/meta"`.

## Intent

The inline feedback banner: an elevation surface with a severity-coloured left
rule, a severity glyph, the message and a trailing action slot. It replaces
`@mui/material` `Alert` and `AlertTitle` — 286 render sites across 193 files, the
largest single conversion in the feedback family.

Alert stays in the document flow and is read by the page around it. The transient
counterpart that floats over the page and can be dismissed is `Snackbar`.

## THE SURFACE RULE — read this before anything else

An Alert paints an elevation surface, so it is only legible on a **different**
layer from the surface behind it. Pick `elevation` from what you are placing it on:

| Host surface | Alert `elevation` |
|---|---|
| default gradient (`bg-gradient-default`) | **2** — the default, pass nothing |
| bg elevation layer 0 | **2** — the default, pass nothing |
| bg elevation layer 1 | **2** — the default, pass nothing |
| bg elevation layer 2 | **1** — the one case that passes a value |

```tsx
// Three hosts out of four need nothing:
<Alert severity="info" title="Indicators are refreshed every 15 minutes." />

// A layer-2 host is the exception:
<Paper elevation={2}>
  <Alert severity="warning" title="This feature needs an active licence." elevation={1} />
</Paper>
```

Getting it wrong does not throw and does not fail a gate. It paints the Alert the
same colour as the surface behind it: the text is still readable, but the banner
stops being a banner. If you are unsure what layer your host is on, look for the
nearest `layer-N` class or `<Paper elevation={N}>` above you.

**In LIGHT mode the rule does not apply**, and you have nothing to do: the light
elevation ramp cannot separate the banner from the page (every light layer sits
between `#e4e5e7` and `#ffffff`), so in light the Alert paints a **20 % severity
wash** instead — it separates by hue. `elevation` still governs dark. This is a
`light:` Tailwind variant inside the component, not a branch you configure.

## Edge cases seen in products

- **Most sites are one line.** 286 bodies against 40 `AlertTitle`s. That single
  line is the **message**, so it goes in `title` — see the migration table. A
  one-line Alert is a title, never a lone description.
- **The AI message is a severity, not a custom icon.** OpenCTI's `Message.tsx` has
  an `nlq` branch that passes a custom logo and hand-sets `theme.palette.ai.*`.
  That is `severity="ia"`, which is why there is no `icon` prop.
- **`severity` is effectively always passed already**, and where it is computed it
  comes from data. That is why it is required rather than defaulted.
- **The message content is arbitrary React**, not a string.
- **OpenCTI keeps a thin local wrapper** at `components/Alert.tsx` (14 importers)
  that forwards to MUI. Retire it first: one edit converts 14 call sites.
- `variant="filled" | "outlined"` has **zero** product usage and no Figma frame.

## Composition

Standalone component. No sub-components — the two text slots and the action arrive
as props. `children` is not part of the type: with two text slots it would let the
message land in the slot the design treats as secondary.

## Migration from MUI

The body becomes the **title**. This is the one thing to get right, and it is the
opposite of the intuitive mapping.

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Alert severity="info">Body</Alert>` | `<Alert severity="info" title="Body" />` | the single line is the title |
| `<Alert severity="error"><AlertTitle>T</AlertTitle>Body</Alert>` | `<Alert severity="error" title="T" description="Body" />` | both slots, in order |
| `<Alert>Body</Alert>` (no severity) | `<Alert severity="success" title="Body" />` | MUI's implicit default, made explicit |
| `<Alert icon={<AiLogo/>} style={{aiPalette}}>` | `<Alert severity="ia" title={…} />` | the OpenCTI `nlq` case |
| `<Alert action={<Button/>}>` | `<Alert action={<Button priority="secondary" size="sm"/>} …/>` | |
| an Alert on a layer-2 surface | `<Alert elevation={1} …/>` | the surface rule above |
| `<Alert onClose={fn}>` | `<Snackbar severity={…} onClose={fn} …/>` | a dismissible message is a Snackbar |
| `<Alert variant="outlined">` | `<Alert severity={…} …/>` | drop it — one appearance |
| `<Alert sx={{ mt: 2 }}>` | `<Alert className="mt-4" …/>` | the spacing scale, not `sx` |

## Accessibility notes

- The root is a **live region**. `role="alert"` (assertive) for `error` and
  `warning`, `role="status"` (polite) for `info`, `success` and `ia`. Pass `role`
  to override.
- A live region only announces content that arrives **after** it is in the DOM. An
  Alert rendered with the page is read in document order instead — which is the
  intended behaviour for an inline banner.
- The severity glyph is decorative (`aria-hidden`): the message already carries the
  meaning.
- Severity is never colour alone — each severity has its own glyph shape and the
  message states the condition.
- The banner is **not focusable** and declares no focus ring of its own. The only
  focusable element is whatever you pass in `action`, which brings its own.
- Contrast is declared and computed on all three surfaces the component can
  present (layer 2, layer 1, and `--bg-elevation-default` itself); every pair
  clears its threshold in both modes.
- No disabled state exists.

## Behavior

- **Responsive:** intrinsic, no breakpoints. The component fills its container and
  the text column shrinks, so a long description wraps instead of pushing the
  action out of the card.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic.
- **Nested theme panels do not work on this component.** Every colour token it
  paints is declared once at `:root` as an alias, and a `var()` inside a
  custom-property declaration resolves where it is declared. A `.light` wrapper
  inside a dark page will render it with dark colours. Switch the whole page
  instead. `layer-N` is the opposite case and nests correctly — which is exactly
  what the surface rule relies on.

## Usage rules

- **RULE-01 — Match the surface.** Read the surface rule above and pass
  `elevation={1}` on a layer-2 host. Nothing else needs a value.
- **RULE-02 — The message goes in `title`.** `description` is a second line, never
  the only one.
- **RULE-03 — State the severity.** It is required, and it is the message's
  meaning. Never pick one to get a colour.
- **RULE-04 — The message is the information; the glyph is not.** Write a message
  that stands alone with the icon removed.
- **RULE-05 — If it can be dismissed, it is a Snackbar.** Alert has no close
  control by design.
- **RULE-06 — Put spacing on the Alert, not inside it.** `className` with the
  spacing scale; never `sx`, never a hardcoded value.

## Out of scope — do not reach for Alert here

| Need | Use instead |
|---|---|
| A transient, dismissible message | `Snackbar` |
| A modal that demands a decision | `Dialog` |
| A custom icon | `severity="ia"` if it is the AI mark; otherwise flag the gap |
| `filled` / `outlined` appearances | not applicable — zero product sites, no Figma frame |
| A per-instance palette | tokens only — a colour with no token is a design question |
