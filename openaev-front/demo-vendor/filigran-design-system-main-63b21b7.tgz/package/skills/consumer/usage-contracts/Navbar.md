# Navbar — usage contract

- **Component:** `Navbar` · **Package:** `@filigran/design-system`
- **Source of truth:** `Navbar.rfc.md` + `Navbar.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** none — plain compound composition (children coordinate
  through `NavbarContext`)

> Read this before using `Navbar`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { NavbarMeta } from "@filigran/design-system/meta"`.

## Intent

`Navbar` is the primary structural navigation container of every Filigran
product: a vertical, collapsible sidebar hosting the product switcher, the list
of navigation items/submenus, and a footer with the collapse toggle.

It is a **thin composition root**, not a monolith. It owns the
collapsed/expanded state, the `<nav>` landmark, the width transition, and the
footer collapse toggle. It shares state with `NavbarItem`, `NavbarSubmenu`, and
`ProductSwitcher` (each its own component/RFC) via `NavbarContext` — it does not
render menu items or the product switcher itself, only the layout shell and
slots for its children. It also exports two small internal helpers:
`NavbarSeparator` (a divider between item groups) and `NavbarTitle` (a section
label captioning a group of items).

## Usage rules

- `Navbar` is a composition root: it owns collapse state and layout, but never
  product-specific content (branding, active-route detection, persistence of
  the collapsed preference). Consuming products pass `header` / `footer` /
  `children` and read `aria-current` / router state themselves via `NavbarItem`.
- **`aria-label` is a required prop.** The exact wording ("Main navigation",
  "Product navigation", …) is product/locale-specific and cannot be safely
  defaulted; requiring it forces every integration to make a deliberate choice.
- `NavbarTitle` renders `<h2>` by default but is configurable via `as`. When the
  Navbar mounts as chrome ahead of the page's own `<h1>`, pass `as="p"` to opt
  the label out of the heading outline (avoids an out-of-order heading, WCAG
  1.3.1); heading hosts may pass `"h2".."h6"` to place it at the right depth.

## Composition

**Compound component.** `Navbar` is the root/provider; it shares collapsed state
and the `submenuShowIcons` global preference with its children via
`NavbarContext` (`{ collapsed: boolean; submenuShowIcons: boolean }`) so
children derive their icon-only/tooltip/flyout behavior without threading props.
Sub-components in this RFC's scope:

- `Navbar` (root/provider — renders `<nav>` + header slot + content slot +
  footer slot + built-in collapse toggle)
- `NavbarSeparator` (internal divider between item groups)
- `NavbarTitle` (internal section label; optional `icon` for the collapsed rail;
  configurable element via `as`, default `<h2>`; composes `Text` for typography)

`NavbarItem`, `NavbarSubmenu` (+`NavbarSubmenuItem`), and `ProductSwitcher` are
each a **separate top-level component** (own folder, own RFC). They consume
`NavbarContext` from whichever `Navbar` they render under, but do not otherwise
depend on `Navbar`'s internals.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Drawer variant="permanent" sx={{width: open ? 180 : 48}}>` | `<Navbar aria-label="Main navigation" collapsed={!open}>` | Width is intrinsic to the `collapsed` state, not manual `sx` (`aria-label` is required — see above) |
| Manual `navOpen` `useState` + `localStorage` read/write | `<Navbar defaultCollapsed={…} onCollapsedChange={persistToStorage}>` | Persistence stays product-side, in the `onCollapsedChange` callback |
| `theme.transitions.create('width', {…})` (225ms, no reduced-motion) | Built into `Navbar` (150ms + `motion-reduce:`) | Not configurable — a design-system-owned token |
| Bespoke "Made by Filigran" footer JSX | `footer` slot (optional) + built-in collapse toggle | Products may still add their own footer content above the toggle |

## Accessibility notes

- Root element is a native `<nav aria-label={ariaLabel}>` — the WAI-ARIA landmark
  pattern for site navigation. This is a real improvement over the current
  products, which render the sidebar as a generic MUI `Drawer` `<div>`.
- Keyboard: native landmark behavior — `Tab` reaches interactive children in DOM
  order (product switcher → items/submenus → footer collapse toggle). The
  collapse toggle is a native `<button>` (`Tab` / `Enter` / `Space`). No custom
  handling at the `Navbar` level.
- **Focus management on collapse:** if focus is inside an open submenu when the
  Navbar collapses, the submenu closes and focus returns to its parent
  `NavbarItem` trigger — never left on a hidden/detached element.
- `prefers-reduced-motion` is honored: the width transition is disabled entirely
  when reduced motion is requested (state still changes, just without animation).
- Collapsed vs. expanded is a purely visual/layout state — no live region.
  `aria-expanded` lives at the item/submenu level, not on the `Navbar` root
  (the root is a landmark, not a disclosure widget).

## Behavior

- **Responsive:** intrinsic, no breakpoints (the Figma frame is desktop-only). No
  mobile-collapse behavior is specified — product-level concern if needed (§7).
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light` with no
  conditional logic. `--gradient-default`'s two stops both have distinct
  light/dark values; the 90deg angle is mode-invariant.

## Edge cases seen in products

- **opencti** used a single monolithic `LeftBar.jsx` owning drawer width, a
  `navOpen` boolean persisted to `localStorage`, and the product-switcher
  `Popover`, with no keyboard handling and no `aria-haspopup`/`aria-expanded` on
  submenu triggers.
- **openaev** was more modular and more conformant — submenu triggers set
  `aria-expanded`/`aria-haspopup` (the pattern to align with).
- **opengrc** had already migrated off MUI, using Tailwind + a Radix-based
  `Accordion` for inline submenu expansion — the precedent for the "Accordion
  for inline mode" decision.
- **Hybrid submenu behavior** (both opencti & openaev): accordion (inline) when
  the sidebar is expanded; `Popover` flyout when collapsed. This dual-mode UX is
  real and kept, re-implemented with conformant keyboard support.

## Out of scope — do not reach for Navbar here

| Excluded feature | Reason / use instead |
|---|---|
| Persisting the collapsed preference (localStorage / user settings) | Product concern — `Navbar` only exposes `onCollapsedChange` for you to persist however you want |
| `submenuShowIcons`-style global preference **storage** | Only the storage/persistence of the value is a product concern; pass the stored boolean via `Navbar.submenuShowIcons` — `Navbar` never reads or writes that storage |
