# Spinner — usage contract

- **Component:** `Spinner` · **Package:** `@filigran/design-system`
- **Source of truth:** `Spinner.rfc.md` + `Spinner.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** implemented

> Read this before using `Spinner`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { SpinnerMeta } from "@filigran/design-system/meta"`.

## Intent

The busy indicator products draw everywhere while data is in flight. It replaces
`@mui/material` `CircularProgress` (which OpenCTI and OpenAEV render exclusively
in its indeterminate form) and becomes the single source for the two spinners the
library had hand-rolled inside `Button` and `Combobox`.

## Edge cases seen in products

- **Every render site is indeterminate** — there is no determinate circular
  progress anywhere in the products.
- **The large sizes are a different object.** OpenCTI's `Loader.tsx` renders a
  branded `FiligranLoader` at 40/80px and the 200px OpenAEV loaders are decorative
  full-panel animations — not a control-sized indicator. Sizes 40/60/80/200 are
  therefore out of scope here.
- Sizes cluster at 16 / 20 / 24 / 32 / 40 / 80, which is what the size scale names.
- No product site gives the SVG itself an accessible name.

## Composition

Standalone component. No sub-components.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<CircularProgress size={16} />` | `<Spinner size="sm" />` | |
| `<CircularProgress size={20} />` | `<Spinner />` | `md` is the default |
| `<CircularProgress size={24} />` | `<Spinner size="lg" />` | |
| `<CircularProgress size={16} color="inherit" />` | `<Spinner size="sm" tone="inherit" />` | inside a button or an adornment |
| `<CircularProgress thickness={2} />` | `<Spinner />` | drop `thickness` |
| `<CircularProgress size={32} />` | `<Spinner size="xl" />` | |
| `<CircularProgress size={40\|80} />` | *not migrated in v1* | keep the product loader |

## Accessibility notes

- Which shape renders is decided by `label`:
  - **Without `label`** — a decorative graphic: the glyph carries
    `aria-hidden="true"` and nothing else is emitted. The surrounding control owns
    `aria-busy`.
  - **With `label`** — the glyph stays `aria-hidden` and is wrapped in
    `<span role="status">` holding an `sr-only` copy of the label, so the text is
    announced when it appears.
- `role="progressbar"` is deliberately not used — that is what `ProgressBar` uses.
- Not focusable, no keyboard interaction.
- Rotation is `motion-safe:animate-spin`, so it stops under
  `prefers-reduced-motion: reduce`.
- `tone="inherit"` emits no colour class, so the glyph inherits the host's
  `currentColor` — the host is then responsible for keeping its own colour pair
  conformant.

## Behavior

- **Responsive:** intrinsic, no breakpoints.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`; no
  conditional logic.

## Usage rules

- **RULE-01 — Never the only signal.** A spinner is never the only thing on screen
  saying something is happening — either it sits beside real text, or it is given
  a `label`.
- **RULE-02 — The busy state belongs to the control.** Set `aria-busy` on the
  button, field, or region that is loading, not on the spinner.
- **RULE-03 — A known value is not a spinner.** A known percentage is a `ProgressBar`.

## Out of scope — do not reach for Spinner here

| Need | Use instead |
|---|---|
| Determinate circular (`value`) | not applicable — zero product sites |
| `thickness` | no token — omit it |
| Sizes 40 / 60 / 80 / 200 px | branded product loader (`FiligranLoader`) |
| Feedback-coloured spinners | not applicable — only `inherit` and the primary default |
| A rotating-message loader | product copy orchestration, not a DS concern |
| A known percentage | `ProgressBar` |
