# Paper — usage contract

- **Component:** `Paper` · **Package:** `@filigran/design-system`
- **Source of truth:** `Paper.rfc.md` + `Paper.meta.ts` (this file is a
  published subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** none — Paper is pure presentation (no interaction
  primitive models a styled, non-interactive surface)

> Read this before using `Paper`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { PaperMeta } from "@filigran/design-system/meta"`.

## Intent

Paper is a token-driven elevation/surface container — the FDS equivalent of
MUI's `Paper` — providing a neutral, non-interactive `<div>`-like box whose
background, border, and radius shift together as a single "layer" step (0–3) to
signal depth, with **no default ARIA role or semantics**. There is no shadow: the
design uses surface-lightening (dark mode) rather than dp-shadow. It is a
pure-CSS, zero-JS foundational primitive; `Card` is the shipped higher-level
component that composes it.

## Usage rules

- Use Paper for a generic, non-interactive elevated surface (settings panels,
  drawer content, dashboard widget backgrounds, table/list wrappers). Do **not**
  use it for anything requiring built-in header/content/actions structure — that
  is `Card`'s job (the shipped composition on top of Paper).
- Content placed directly on Paper should default to `--text-default-primary` /
  `--text-default-secondary` — both are safe at every layer, in both modes.
- **The border is decorative and non-gating.** Never rely on it alone to convey a
  boundary to low-vision users, and never make it the sole differentiator between
  two adjacent surfaces — combine it with an `elevation` step (background change)
  and/or layout spacing.
- **Nesting Paper inside Paper** to go up a layer (e.g. a layer-2 card inside a
  layer-1 panel) is the intended way to build compound surfaces.

### `padding` — the scale

```ts
/** Surface padding in PIXELS. 8px step. */
type PaperPadding = 0 | 8 | 16 | 24 | 32;   // default 24
```

Prefer the typed `padding` prop over `className="p-*"`. Only these five steps
carry an emission guarantee in the published stylesheet — a bare
`className="p-8"` historically compiled to nothing and silently rendered at
24px. `className` still wins over the prop via `tailwind-merge`, but an off-scale
value is the consumer's own risk.

### `title` / `action` — the header row

```ts
title?: React.ReactNode;
action?: React.ReactNode;
```

Optional, independent slots rendered in a header row **above the surface**
(outside its border and padding). With neither slot, Paper renders exactly one
element, byte-identical to previous releases. Notes:

- `as`, `ref`, `className` and rest props stay on the **surface**, not the header
  wrapper — so `<Paper as="a" href="…" title="…">` is a clickable card whose
  *surface* is the link.
- A string `title` renders in a plain `<div>` with the library's quiet caption
  typography (12px, regular, `--text-default-secondary`) — **no heading level is
  invented** (guessing it is a WCAG 1.3.1 regression). Pass an element if you
  need heading semantics.
- Size header-row controls at `size="sm"` (24px): the row is 24px, and a taller
  control overflows into the gap to the surface. The 8px action-cluster gap holds
  at any number of controls.

## Composition

Standalone component. No sub-components.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<Paper variant="outlined">…</Paper>` | `<Paper>…</Paper>` | The outlined look is implicit; the prop is dropped |
| `<Paper elevation={0}>…</Paper>` | `<Paper elevation={0}>…</Paper>` | Same prop name/value, reshaped semantics (layer, not dp-shadow) |
| `<Paper elevation={1}>…</Paper>` / bare `<Paper>` | `<Paper>…</Paper>` | `elevation` defaults to `1` |
| `<Paper component={Link} to="…">…</Paper>` | `<Paper as={Link} to="…">…</Paper>` | Clickable-card pattern |
| `<Paper component="a" href="…">…</Paper>` | `<Paper as="a" href="…">…</Paper>` | |
| `<Paper square>…</Paper>` | `<Paper className="rounded-none">…</Paper>` | No dedicated prop — documented escape hatch |
| `<TableContainer component={Paper}>` | Unaffected — keep MUI's `TableContainer`, pass the new `Paper` via its own `component` prop | `as` is unrelated here |

Note: MUI-`Paper` props this component does **not** accept (`sx`, `component`,
`variant`, `square`, `classes`) are rejected by the types and warned in dev.

## Accessibility notes

- Renders a plain `<div>` with **no default ARIA role** and no default
  `tabIndex` — a generic surface has no implicit semantics. Supply your own via
  `as` / native props (e.g. `as="section"` + `aria-label`, or `as={Link}` for a
  clickable card).
- Native keyboard behavior only; Paper is never focusable on its own. If rendered
  `as` a focusable element, that element's native behavior applies unmodified,
  and full a11y responsibility (focus ring, keyboard activation, accessible name)
  shifts to the consumer's chosen element.
- Text-on-surface contrast passes at every layer in both modes for both
  `--text-default-primary` and `--text-default-secondary` (full pairs in
  `PaperMeta`). The subtle border is decorative and intentionally **not** a
  gating 1.4.11 boundary claim.

## Behavior

- **Responsive:** intrinsic, no breakpoints — size is entirely content-driven.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light` with no
  conditional logic. Dark mode lightens successive layers (Material convention),
  which the `--bg-elevation-*-layer-N` tokens already encode.

### Host theming — the recipe

There is no colour prop and no Paper-private surface token. Paper paints
`bg-elevation-default`; a product recolours it by re-declaring the token the
alias resolves to. **Which token matters:**

| Declaration | Where | Reaches Paper? |
|---|---|---|
| `--bg-elevation-default-layer-N` | `:root` / `html` | ✅ repaints elevation N |
| `--bg-elevation-default-layer-N` | `<body>` or any ancestor | ✅ repaints (scoped) |
| `--bg-elevation-default` | anywhere | ❌ **never** — the `.layer-N` class re-declares the alias on the Paper element itself |

For DB-driven product themes, map fields per layer (the missing line is often
`theme_paper → --bg-elevation-default-layer-1`, Paper's default elevation):

```ts
const PRODUCT_THEME_TO_FDS = {
  theme_background: "--bg-elevation-default-layer-0", // page, Navbar, Header, Paper elevation 0
  theme_paper:      "--bg-elevation-default-layer-1", // Paper's DEFAULT elevation
};
```

A product that redeclares a surface token owns re-verifying text contrast against
its own value — the library's gate only checks the shipped `theme.css`.

## Edge cases seen in products

- **OpenCTI's homemade `Card.tsx` wrapper** (164 importers) confirms MUI `Paper`
  carries no built-in padding — every consumer re-invents it — and that `Card`
  is the natural next consumer of Paper.
- **`TableContainer component={Paper}`** is a recurring idiom; Paper must stay a
  plain, non-opinionated box for it to keep working.
- **Clickable dashboard/list cards** (`component={Link}` / `component="a"`) are a
  real, repeated polymorphism need — served by `as`.
- **XTM CRQ** has zero MUI `Paper` usage (already on a shadcn/Radix stack) — no
  migration action applies there.

## Out of scope — do not reach for Paper here

| Excluded feature | Reason / use instead |
|---|---|
| `Card` (header/content/actions composition) | Use the shipped `Card` — it is the higher-level composition of Paper |
| MUI `elevation` values 2–24 (dp-shadow scale) | 0 real usages; Figma has no shadow concept |
| `square` prop | 0 real usages; `className="rounded-none"` is the escape hatch |
| List / separator variants of the surface | Ruled out permanently — a list or separator becomes its own dedicated component, never a surface variant |
| Shadow-based elevation | No shadow at any Figma node; dark theme favors surface-lightening |
