# Radio — usage contract

- **Component:** `Radio` · **Package:** `@filigran/design-system`
- **Source of truth:** `Radio.rfc.md` + `Radio.meta.ts` (this file is a published
  subset; on conflict the shipped machine contract (`Meta`) wins; any `.rfc.md`, proposal or `.tsx` source named here is internal and **not shipped**, so a consumer never resolves a conflict through it)
- **RFC status:** approved
- **Radix primitive:** `@radix-ui/react-radio-group`

> Read this before using `Radio`. It carries the rules the TypeScript types do
> not encode. For exact prop names/types and contrast pairs, also read
> `import { RadioMeta } from "@filigran/design-system/meta"`.

## Intent

Radio is the single-choice control of the design system — one option selected
from a mutually-exclusive group. It maps to MUI `RadioGroup` + `Radio` (always
paired with `FormControlLabel`). Built on `@radix-ui/react-radio-group`, which is
inherently a **group**: the value lives on the group and each item's selected
state derives from it — matching the Figma note *"Checked / Unchecked is a
property within the design file only. Coded Radio Fields are grouped and the
value of the field indicates its state."* Each item is a 16×16 circle with an
optional inline label and description, sharing Checkbox's token family.

## Usage rules

- **RULE-01 — Selection model.** Radio expresses a mutually exclusive choice —
  exactly one option selected at a time. Always render inside a group; never a
  standalone `<Radio>`. Selection derives from the group value, not a per-item
  `checked`.
- **RULE-02 — Option count and component choice.** Use Radio for 2–~5 options
  shown all at once. Otherwise: `>5–7` options → `<Select>`; multiple selections
  → `<Checkbox>` (few, fixed) or `<Combobox multiple>` (many); single on/off toggle →
  `<Switch>`.
- **RULE-03 — Orientation.** The group stacks vertically. Horizontal layout is
  not in v1 (Figma spacing not yet readable); when it lands it will be
  `orientation="horizontal"`, reserved for short groups of 2–3 items.
- **RULE-04 — No error state on the control.** `RadioGroup` / `Radio` have no
  `error` prop and will not get one. Required-group validation is surfaced by the
  surrounding form field, not the circles.
- **RULE-05 — The circle has no background at rest** and must keep none — it is
  transparent and inherits its container's surface. Do not add a rest fill.
- **RULE-06 — Disabled by colour substitution**, never an opacity tint — each
  disabled colour is its own token binding.
- **RULE-07 — The dot token.** The selected dot always uses `--icon-highlight`
  (`--icon-disabled` when disabled). Do not hardcode or override it.
- **RULE-08 — Always name the group.** `RadioGroup` renders `role="radiogroup"`
  and must carry an accessible name via `aria-label` or `aria-labelledby`. v1 has
  no built-in title slot.

## Composition

**Compound component.** A `<RadioGroup>` root owns the value; `<Radio>` items
render the circle + Radix Indicator + optional label + description. Built on
`@radix-ui/react-radio-group` (`Root` + `Item` + `Indicator`). No
`FormControlLabel` needed.

```tsx
<RadioGroup value={value} onValueChange={setValue} name="visibility" aria-label="Visibility">
  <Radio value="public" label="Public" description="Anyone can view" />
  <Radio value="private" label="Private" description="Only you" />
</RadioGroup>
```

Radix provides roving tabindex + arrow-key navigation for free.

## Migration from MUI

| MUI usage | FDS equivalent | Notes |
|---|---|---|
| `<RadioGroup value={v} onChange={e => set(e.target.value)}>…</RadioGroup>` | `<RadioGroup value={v} onValueChange={set}>…</RadioGroup>` | Handler signature change — see below |
| `<FormControlLabel value="a" control={<Radio/>} label="A" />` | `<Radio value="a" label="A" />` | Label + value absorbed |
| `<RadioGroup row>` | ⏸ not yet — keep MUI | Horizontal variant not implemented in v1 |
| `<Radio disabled />` | `<Radio disabled />` | Per-item |
| `<Radio size="small" />` | `<Radio />` | Drop — single size |
| `<Radio color="primary" />` | `<Radio />` | Drop — single token set |
| `<FormLabel>` above the group | `aria-label` / `aria-labelledby` on `<RadioGroup>` | v1 has no built-in group title; the group **must** still be named |

**`event.target.value` → `(value: string)`:** the group handler changes shape the
same way Checkbox's does — Radix hands the new value directly instead of an
event, so `onValueChange={setV}` usually collapses to the setter. The value is
always a `string`, so no narrowing is required. `RadioGroup` renders no
`<input type="radio">` unless `name` is set; pass `name` for uncontrolled HTML
forms, as with MUI.

## Accessibility notes

- Radix renders `role="radiogroup"` on the root and `role="radio"` with
  `aria-checked` on each item (backed by hidden native inputs). Each `label` is
  associated via the generated item `id`; when omitted, an `aria-label` **must**
  be passed. `description` is linked via `aria-describedby`.
- Keyboard: Radix roving-tabindex — `Tab` enters the group at the selected (or
  first) item; `ArrowUp/Down` (and `Left/Right`) move and select; only one item
  is in the tab order. No custom keys.
- Focus uses the repo's standard ring (Figma's slightly different ring is a
  declared deviation).
- Selection is not conveyed by the dot colour alone — `aria-checked` + the filled
  dot carry meaning (WCAG 1.4.1).
- Disabled items/groups use Radix `disabled` (removed from tab order) and switch
  every colour to its disabled counterpart, never an opacity tint (low-contrast
  disabled tokens are exempt under WCAG 1.4.3 Note 1).
- **The group must be named** — a `role="radiogroup"` with no accessible name is
  a WCAG 1.3.1 / 4.1.2 failure. Full contrast pairs are in `RadioMeta`.

## Behavior

- **Responsive:** intrinsic, no breakpoints. Vertical stack; items wrap their own
  label and description. Horizontal layout is not part of v1.
- **Dark / Light:** same structure, tokens switch via `.dark` / `.light`, no
  conditional logic; contrast verified in both modes.

## Edge cases seen in products

- **78% of usage is grouped** (`<FormControlLabel control={<Radio/>}>` inside a
  `<RadioGroup>`) — the shape the compound API targets.
- **The remaining ~22% don't use `RadioGroup` at all** (opencti
  `StixCoreObjectAskAI`, `DataTableToolBar`; openaev `EngineTypeSelection`) —
  individually-managed selection with a per-item `checked`/`onChange`. **This is
  a real migration gap:** FDS `Radio` is built on `RadioGroupPrimitive.Item`,
  which requires a `RadioGroupPrimitive.Root` ancestor, so those 4 sites must be
  restructured to route through a `RadioGroup` (even a group of one) — not a
  mechanical prop swap.
- **`row` layout** in products is `orientation` on the group (once shipped).

## Out of scope — do not reach for Radio here

| Excluded feature | Reason / use instead |
|---|---|
| Standalone `<Radio>` without a group | Radio is inherently grouped (Figma note + Radix) |
| Per-item `checked` prop | Selection derives from group value |
| `size` (small/medium) | Single Figma size (16px) |
| `color` (MUI palette) | Single FDS token set |
| Group-level error/helper text | Error belongs to the surrounding form field (RULE-04) |
| Horizontal orientation | Deferred — the variant is not readable in Figma yet |
| Group title + info icon row | Deferred; use `aria-label` / `aria-labelledby` |
| `sx` / `style` | `className` / `wrapperClassName` only |
