# Consumer skill — proof of concept

> **Status: hand-written proof of concept.** The umbrella skill and the
> per-component usage-contracts are maintained by hand for a first test
> iteration. The target is that the usage-contracts become **generated** outputs
> (`generate:usage-contract`) built from the same sources the rest of the repo
> already generates from — see `process/SKILLS-DESIGN-PROPOSAL.md`. Do not treat
> the current hand-written state as the final architecture.

## What this is

Portable guidance a **product developer installs into their own agent** so the
agent uses `@filigran/design-system` correctly **without cloning this repo** — it
has only the published npm package.

It is deliberately **two layers**: the library's own generated context (shipped
inside the package, zero drift) for everything transverse, and a thin
per-component projection for the depth the generated context lacks.

## Wiring this into your agent

**`npm install` does not auto-load the skill.** After
`npm install @filigran/design-system` the files exist on disk at
`node_modules/@filigran/design-system/skills/consumer/**`, but no agent runtime
scans `node_modules` for skills — agents load them from project directories
(`.github/skills/`, `.claude/skills/`, …). So you wire it once, explicitly. A
package must never write into your project silently on install, so there is
**no `postinstall` hook**; you choose one of the two modes below.

### Option 2 — reference it from your `AGENTS.md` (recommended)

Zero copy, zero drift: your agent reads the shipped skill in place, always in
sync with the installed version. Add a line to your product's `AGENTS.md`:

```md
When using @filigran/design-system, follow
node_modules/@filigran/design-system/skills/consumer/design-system-usage/SKILL.md
```

Or let the CLI inject a managed block for you:

```bash
npx @filigran/design-system install-skills --pointer
```

### Option 3b — copy or symlink into your agent's skills directory

For agents that require the skill to live inside their own skills folder:

```bash
npx @filigran/design-system install-skills            # copy into the detected agent dir
npx @filigran/design-system install-skills --symlink  # symlink instead (tracks the version)
npx @filigran/design-system install-skills --target .github/skills   # force the location
```

The command auto-detects `.github` / `.claude` / `.cursor`, writes to
`<agent>/skills/filigran-design-system/`, refuses to overwrite without
`--force`, and only ever writes when you invoke it. `npx … install-skills
--help` lists everything.

> A copy can go stale against the installed package; the skill's "Staleness"
> section tells the agent to trust the shipped generated files on any conflict.
> Prefer Option 2 (or `--symlink`) to avoid the copy entirely.


### Layer 1 — canonical context (shipped in the package)

Not re-authored here: these are the library's own canonical artifacts, copied
into `dist/` at build time and exposed as package subpaths. Most are **generated**
(`llms.txt`, `llms-full.txt`, `meta.*`); `icon-mapping.json` is instead a
**committed source of truth** (the hand-curated `@mui/icons-material` → `<Icon>`
table that the icon registry is generated *from*) that is merely copied into
`dist/`. Either way, a consumer reads the version that shipped with the package.

| Shipped file | Subpath | Role |
|---|---|---|
| `dist/llms.txt` | `@filigran/design-system/llms.txt` | Component index: every component with maturity (`beta`/`stable`), `WCAG` status, intent, variants, sizes — plus the "Consumers" host-integration rules. |
| `dist/llms-full.txt` | `@filigran/design-system/llms-full.txt` | Full standalone context: token reference, consumer integration guide, overlay stacking. |
| `dist/icon-mapping.json` | `@filigran/design-system/icon-mapping.json` | The `@mui/icons-material` → `<Icon name>` migration table. |
| `dist/meta.*` | `@filigran/design-system/meta` | Per-component machine contract: exact props, examples, contrast pairs. |

### Layer 2 — per-component usage-contracts and cross-cutting rules (this PoC)

| File | Role |
|---|---|
| `design-system-usage/SKILL.md` | **Umbrella skill.** The non-negotiable invariants (tokens-only, never-fork, the priority rule, accessibility, the two entry points, icons-through-`<Icon>`, shell layout), host responsibilities, a workflow, and routing across both layers. Always applies. |
| `usage-contracts/<Component>.md` | **Per-component usage contract.** A subset of that component's `<Name>.rfc.md`: intent, usage rules, out-of-scope, MUI→FDS migration, composition and accessibility notes — the content that governs correct use and is *not* otherwise published. |
| `rules/<Rule>.md` | **Cross-cutting rule.** A normalization rule that is not tied to a single component. `rules/Layout.md` is the mandatory application-shell contract, a concise projection of the repo-root `LAYOUT.md`. Add other non-component rules here. |

## Why two layers

`meta`, `llms.txt` and `llms-full.txt` cover the *transverse* surface — what
exists, its maturity/WCAG, tokens, host integration, icon migration — cheaply and
with **zero drift**, because they are byte-identical to sources already under the
repo's anti-drift gates. But they are coarse: one line per component, no usage
rules (§6.3), no out-of-scope routing (§7), no MUI→FDS migration table (§4.4).
That per-component depth lives in each `<Name>.rfc.md`, which is **not published**
(it carries contributor noise: metrics, Figma analysis, arbitration logs,
`🤖/🧑` markers, branch references). The usage-contract publishes exactly the
normative subset and drops the noise.

The two deeper repo documents — each component's `*.rfc.md` and the product
implementation playbook — are **intentionally not shipped**: internal
deliberation, and, for the playbook, git-dependency-era steps that would mislead
a consumer on public npm. The playbook's consumer-relevant essence is already
distilled into `llms-full.txt`'s "Consumer Integration Guide".

Priority on conflict — resolvable with **shipped** artifacts only: **the shipped
machine contract (`<Component>Meta` from `@filigran/design-system/meta`) and the
generated canonical files (`llms.txt` / `llms-full.txt`) win → usage-contract
prose → umbrella skill.** The `*.rfc.md` deliberations named in each contract
header are internal and **never shipped**, so a consumer never resolves a
conflict through them — the shipped `Meta` is the authority the header points to.

## How Layer 1 is wired

- `package.json` `build` copies `llms.txt`, `llms-full.txt` and
  `icon-mapping.json` into `dist/` (alongside the existing `theme.css` copy), so
  they publish with the tarball.
- `exports` maps `./llms.txt`, `./llms-full.txt`, `./icon-mapping.json` to their
  `dist/` targets. `dist` and `skills/consumer` are both in the package `files`.

## Anti-drift

Layer 1 cannot drift — it is a copy of gated sources shipped inside the package
(generated for `llms.txt` / `llms-full.txt` / `meta.*`, a committed source of
truth for `icon-mapping.json`). Layer 2 is hand-written for now and is
**version-agnostic on purpose** — the contracts carry no hardcoded package
version, so they apply to whatever version the consumer installed and do not
drift on every release. Once mechanized, a `check:skills`-style gate would fail
CI if a committed usage-contract drifts from its RFC, or a cross-cutting rule
drifts from its canonical source (e.g. `rules/Layout.md` from the repo-root
`LAYOUT.md`) — the same "generated, do not edit by hand" model already used for
`llms.txt` / `llms-full.txt`.

## Layout

```
skills/consumer/
  README.md                       (this file)
  design-system-usage/SKILL.md    (umbrella — hand-written)
  usage-contracts/<Component>.md  (one per component — hand-written PoC)
  rules/<Rule>.md                 (cross-cutting non-component rules — e.g. Layout.md)
```
