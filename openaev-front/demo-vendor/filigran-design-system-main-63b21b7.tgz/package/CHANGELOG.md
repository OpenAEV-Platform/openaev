# @filigran/design-system

## 1.3.0

### Minor Changes

- 6ccba30: feat(avatar): add Avatar and AvatarGroup — a person as initials or a photo, with optional name and description, and a stacked group with a `+N` counter. RFC: `packages/filigran-design-system/src/components/avatar/Avatar.rfc.md`.

  New runtime dependency: `@radix-ui/react-avatar` (`^1.3.1`). It lands in every product lockfile at the bump.

- c9a56fe: feat(banner): add Banner, BannerAction and BannerStack, the application-level message strip

  New exports: `Banner`, `BannerAction`, `BannerStack`, `BANNER_VARIANTS` and the types `BannerVariant`, `BannerProps`, `BannerActionProps`, `BannerStackProps`. Four gradient variants (`default`, `warning`, `error`, `success`), optional icon, action, close control and polite live mode; `BannerStack` stacks banners in one landmark and reports its height.
  Ships as beta, WCAG 2.1 AA pass in both modes. Reasoning: `Banner.rfc.md`.

- dc79f55: feat(combobox): hold a multiple field to one line with `maxVisibleChips` and `minChipWidth`

  New optional `Combobox` props: `maxVisibleChips` (a count, or `"fit"` for as many chips as the width holds) folds the rest into a `+N` chip with a tooltip, and `minChipWidth` (default 96px, read from the rendered spacing scale; `0` to opt out) keeps a chip readable, which makes a numeric count an upper bound. `ChipWidthsProvider` shares chip measurements across fields. `ComboboxChips` gains `overflowLabel` (the `+N` chip's accessible name), and `useCombobox` gains `visibleChipCount` (how many chips the row draws, so the arrow keys walk only those). Additive: omitted, chips wrap as before. Arbitration: `Combobox.rfc.md` §9 Q14.

- 581148f: feat(drawer): add Drawer — a modal right-side panel (sm/md/lg/xl, default lg) with header extras, a fixed sub-header for tabs or list tools, a scrolling body that holds the footer, one second level and a `busy` state. RFC: `packages/filigran-design-system/src/components/drawer/Drawer.rfc.md`.
- c9a56fe: fix(tokens): end --gradient-focus on tonic-accent and start --gradient-warning on orange-500

  Light mode only, dark unchanged: Banner's default and warning gradients reach 4.5:1 at their ends, and the Button highlight border and the Icon `gradient="focus"` fill (e.g. the Enterprise Edition rocket) now end on #005744 instead of #009474. Visible on every `highlight` Button and `text-gradient-focus` label in light: the label turns from solid brand-primary #0015a8 into the #0015a8 → #005744 gradient (Button.rfc.md §9.3). Record: `src/tokens/PROVENANCE.md`, 2026-10-20 entry.

- e6b6414: feat(tokens): fields follow the elevation layer; input value and placeholder tokens split

  - **Fields follow `.layer-N`.** `--bg-input-default`, `--bg-input-disabled` and `--bg-input-hover` are now re-declared in every `.layer-0` … `.layer-3` block, so a field inside a layered surface (Paper, Dialog, Drawer…) takes that layer's colours instead of layer 0's. A field on layer 2 in dark mode no longer paints the panel's own `#13213e`. Product workarounds that re-point these variables per layer (`layerInputVars`) can be removed.
  - **`--text-input-placeholder` now means placeholder.** It resolves to `--text-default-secondary` in both modes. Text a user typed uses the new `--text-input-value` (`--text-default-primary`). Every library field already uses the right one. A product that styles typed text or labels with `--text-input-placeholder` / `text-input-placeholder` must move to `--text-input-value` / `text-input-value`, or that text turns secondary.
  - **Added:** `--gradient-success` and `--gradient-error`, with `bg-gradient-success`, `bg-gradient-error`, `text-gradient-success` and `text-gradient-error`, and the `border-bg-elevation-default` utility for a surface-coloured border that follows the layer.

- 65f98b5: feat(markdown-field): add MarkdownField component

  New `MarkdownField`: markdown textarea with a formatting toolbar, Write/Preview via the host's `renderPreview`, image paste/drop/pick via `onImageUpload`, an Ask AI menu and a soft character limit. Adds eight glyphs to `IconName`: `heading`, `bold`, `italic`, `strikethrough`, `quote`, `code-xml`, `list-ordered`, `images`. Additive. Arbitration: `MarkdownField.rfc.md`.

### Patch Changes

- dc79f55: fix(combobox): release the keyboard position when a chip loses focus

  Multiple Combobox: a chip that loses focus now releases the keyboard position, so a later change to the selection no longer moves focus back onto a chip.

- dc79f55: fix(combobox): keep focus in the field when the selection shrinks under a focused chip

  Multiple Combobox: when the application removes the focused chip's value, focus moves to the last chip left, or to the input when none is left, instead of falling to the page.

- 829e7f3: fix(markdown-field): wrap code blocks in the preview instead of scrolling them

  A long code line in Preview now wraps inside its block, as the Figma frame draws it, instead of adding a horizontal scrollbar. Arbitration: `MarkdownField.rfc.md`.

## 1.2.0

### Minor Changes

- 55d0b71: feat(button): add `color`, an exceptional fill override for a primary button

  A primitive colour token of theme.css (`"orange-700"`, `"turquoise-800"`…) decided outside the four types (the urgency band a banner button sits on) paints the button's opaque fill; the library keeps the ink, white or black by WCAG luminance from the token's value, never under 4.58:1 for any primitive. Ignored with a warning on secondary and tertiary priorities, on the ia and highlight types, while disabled or loading, and for anything that is not a primitive token. Ships `src/tokens/primitive-colors.generated.ts`, the drift-checked map of the opaque primitives. Additive: consumers passing nothing see no change. Arbitration: `Button.rfc.md` §9.1.

- b4e952c: fix(button): default `type="button"` on the button path

  A native `<button>` with no type submits its form, while MUI's `ButtonBase` resolved a missing type to `"button"` — so replacing MUI with this component turned every typeless button inside a form into a submit button, silently. `Button` now defaults to `"button"`, as `IconButton` already did; an explicit `type` is untouched, the `asChild` path stays free of the attribute (invalid on an anchor), and MUI's own exception is kept — a button carrying `formAction` keeps the native submit behaviour, since that attribute only means anything on a submit button. Behaviour change for a consumer that relied on the native submit default: such a button must now say `type="submit"`. Arbitration: `Button.rfc.md` §9.2.

- d299fa4: feat(button-group): add the integrated / isolated use case from Figma

  New optional `usecase` prop on `ButtonGroup`: `"integrated"` (the default, and
  what the component has always drawn) fills every segment; `"isolated"` draws
  the run as an outline with no fill, for a group standing on the page ground on
  its own. Additive — a consumer passing neither sees no change. The neutral veil the
  integrated run puts on a disabled chosen segment stays integrated-only: the
  isolated one takes the plain disabled fill. Arbitration: `ButtonGroup.rfc.md`
  § "Use case: integrated / isolated".

- 7f3997b: feat(skills): ship the consumer skill bundle and its canonical artifacts as package subpaths

  The package now exposes the material a product's coding agent needs to consume the library correctly, reachable straight from the installed package — no Figma and no repository access required:

  - **Canonical, generated context** as new export subpaths: `@filigran/design-system/llms.txt`, `@filigran/design-system/llms-full.txt` and `@filigran/design-system/icon-mapping.json`. They are generated by the library and copied into `dist/` at build, so they always match the version you installed.
  - **The consumer skill** under `@filigran/design-system/skills/*`: an umbrella `SKILL.md` that routes to those artifacts, plus per-component usage-contracts and a cross-cutting layout rule.
  - **An installer CLI**, the new `filigran-design-system` bin: `npx @filigran/design-system install-skills` copies, symlinks, or writes an `AGENTS.md` pointer that wires the skill into your agent's skills directory.

  Additive only: no existing export, token, style or component changes, so a consumer that ignores the new subpaths sees no difference.

- d94bb5d: feat(date-picker): add the DatePicker field, with `withTime` for date and time

  New component: an editable date field wearing the Input shell, a calendar button opening a WAI-ARIA date picker dialog (hand-built grid on Radix Popover, no date dependency), `withTime` for the hours/minutes/seconds row, locale-derived or explicit `format`, `minDate`/`maxDate`/`minDateTime`/`maxDateTime`/`disableFuture`/`disablePast`, `clearable`, and a MUI X shaped `onChange(value, { validationError })` plus `onAccept`. Additive — covers MUI X DatePicker and DateTimePicker. Arbitration: `DatePicker.rfc.md` §9.

- 8b01f03: refactor(meta): docs demos leave the documentation entry

  No `*Meta` sets `render` any more: the React tree a docs page renders now
  lives in `<Name>.demo.tsx` next to each meta, outside `@filigran/design-system/meta`
  and outside `dist`. `ComponentMeta.render` stays as a deprecated optional member,
  always undefined, until the next major, so the published type does not break.
  What agents read — `description`, `props`, `examples`, the usage contracts,
  `llms-full.txt` — is unchanged.

- 03d41a3: feat(feedback): add Alert and Snackbar, the two components of the feedback frame

  Two new components in five severities each (`error`, `info`, `success`, `warning`, `ia`). `Alert` is the inline banner replacing `@mui/material` `Alert` + `AlertTitle`; it carries the surface rule as an `elevation` prop (default 2, pass 1 on a layer-2 host) so it never paints its own background in dark. In light the elevation ramp cannot separate it from the page, so it paints a 20 % severity wash and separates by hue instead — which is why this release also brings four new `--color-feedback-*-secondary-transparency-20` alias tokens from Figma. `Snackbar` is the transient message, built on the new `@radix-ui/react-toast` dependency and shipped as three parts — `SnackbarProvider`, `SnackbarViewport` (24px from the top and right of the window, portalled out of the host's tree) and the card — which brings placement, stacking, a timer that pauses on hover and focus, swipe-to-dismiss, the F8 hotkey and the announcement, so a product deletes its MUI Snackbar wrapper rather than porting it. Both take a required `severity` and put the message in `title`, with `description` as an optional second line: a one-line message is a title, never a lone description. Messages slide in from the edge the viewport sits against and leave the same way, following MUI's Slide, collapsing to a fade under `prefers-reduced-motion`; the keyframes ship in a new `@filigran/design-system/styles/motion.css` sidecar. Also adds the `custom/logo` icon the IA severity needs. Additive: nothing existing changes. Arbitration: `Alert.rfc.md`, `Snackbar.rfc.md` §4.5.

- 0c44554: feat(hero): add the Hero compound container from Figma

  New `Hero`, `HeroHeader` and `HeroBody`: a page-level introduction surface built
  on Paper (elevation 1, two blurred brand accents) whose header and body are
  optional children holding any content. `elevation`, `padding` and `gap` move the
  frame on the shared scale; the accents are always drawn. Additive, no MUI counterpart.
  Decisions: `Hero.rfc.md` § 4 and § 9.

- 4b54adb: feat(input): add `endText`, a trailing unit or suffix read as the field's description

  A unit such as `/gm`, `ms` or `%` is drawn inside the field at its 8px right edge in the placeholder tone (Figma 7809:25012), linked through `aria-describedby` so it is announced after the value, and the value's padding yields to its measured width. Exclusive with `endIcon` and `isTypeNumber` (dev warning). The interactive `endIcon` also gains its own `disabled`, for an action gated next to an editable value. Additive: consumers passing nothing see no change. Arbitration: `Input.rfc.md` RULE-15.

- e742342: feat(tabs): the trigger's icon slot sizes its child to 16×16

  An Icon, a product SVG icon (20px at MUI's `fontSize="small"`, 24px by default) or a logo image passed to `TabsTrigger` / `TabsMenuTrigger`'s `icon` now reads at the design size without the consumer measuring it; an image keeps its aspect ratio. The sizing is `!important`: a CSS-in-JS icon carries its own `width/height: 1em` at the same specificity from a runtime-injected, unlayered stylesheet, which would otherwise win on source order and leave the glyph clipped (measured). Additive for consumers already passing a 16px glyph. Arbitration: `Tabs.rfc.md` §9 Q5.

- 8b01f03: feat(thumbnail): pass `elevation` through to Paper

  New optional `elevation` (0 | 1 | 2 | 3, default 1) on `Thumbnail`, forwarded
  to its Paper. The Hero symbol draws its thumbnail one layer above the surface
  it sits on; `<Thumbnail elevation={2}>` now writes that, where the Hero docs
  had to spell out a Paper by hand. Additive: a Thumbnail without the prop is
  unchanged.

- 2df82e9: feat(time-picker): add the TimePicker field; add `timezone` to DatePicker

  New component: the time-of-day field wearing the Input shell, a clock button opening the clock row DatePicker already ships (hours, minutes, seconds, AM/PM, OK), locale-derived or explicit `format`, `minTime`/`maxTime`, `minutesStep`, `clearable`, `onChange(value, { validationError })` plus `onAccept`; covers MUI X TimePicker and the native time input. DatePicker gains `timezone` ("default", "UTC" or an IANA name, MUI X's vocabulary) — additive, the browser zone stays the default. Arbitration: `TimePicker.rfc.md` §9, `DatePicker.rfc.md` §9 Q8.

### Patch Changes

- 55d0b71: fix(button): element children inside the label sit 8px from the text, on its centre line

  The label span is now a centred flex row, so an EE chip, an icon or a spinner passed as a child next to the text gets the button's 8px gap and vertical centring instead of hugging the text — the same geometry the `startIcon` / `endIcon` slots already had.

- 8b01f03: docs(card): the card anatomy formerly called "hero" is now "headline"

  Documentation only: `Hero` names the component shipped by the design system;
  the Card usage contract and RFC call the framed-icon-and-overline card anatomy
  "headline" so one word no longer means two things. No code changes.

- 3298705: fix(date-picker): one inset on every side, 24px between sections, a full-width clock row

  The DatePicker panel no longer lets its header overflow to the right: one 16px inset on every side, 24px between the calendar, the clock row and OK, the clock row across the whole width (shared with TimePicker), 38px square days in a 300px panel, and the month's weeks only. No API change. Arbitration: `DatePicker.rfc.md` §9 Q10.

## 1.1.0

### Minor Changes

- 020fdfc: Add the ColorPicker component

  A single, self-contained colour field plus popover panel that replaces three
  divergent product implementations built on MUI TextField + react-color
  SketchPicker (OpenCTI `ColorPickerField.jsx`, OpenAEV `ColorPickerField.tsx`
  and its deprecated twin, OpenGRC none). The colour maths and the area/slider
  interaction model are vendored from DiceUI's radix-base color-picker (RFC §4.3),
  but the public surface is deliberately NOT DiceUI's compound API: it is one
  `ColorPicker` whose chrome is FDS components (Paper, IconButton, Select, the
  shared Input classes) and whose value model is plain React state. Radix is used
  only for the popover and the two colour sliders.

  Output is a hex string by default (`#RRGGBB`), and `#RRGGBBAA` once the opt-in
  `alpha` slider makes the colour translucent. The panel offers hex / rgb / hsl /
  hsb entry, an optional preset grid defaulting to the official Filigran palette
  (`DEFAULT_PRESETS`), and an eyedropper that degrades to nothing where
  `window.EyeDropper` is unavailable. The saturation/brightness area is a custom
  `role="slider"` with arrow-key stepping (Shift = ×10), pinned by tests
  alongside Escape-to-dismiss.

  The three gradient families the panel paints — the hue rainbow, the
  saturation/brightness overlays and the alpha checkerboard — are intrinsic to a
  colour picker and have no representation in `theme.css` (RFC §3.4). They are
  expressed with CSS colour keywords, not tokens, so the token lint leaves them
  alone; the only raw hex in the tree lives in `ColorPicker.presets.ts`, where a
  frozen primitive hex is the actual persisted contract.

  This release introduces two icons to the vocabulary, `palette` and `pipette`,
  both mandated by the approved Figma design. It reuses the existing
  `@radix-ui/react-popover` dependency (already in the package via Combobox) for
  the popover and the two colour sliders — no new runtime dependency is added.

- 8df0757: feat(badge): tuck the badge toward the glyph on a bare (tertiary) anchor

  New optional `bareAnchor` (`"md" | "sm" | false`, default `false`) declares that
  the anchor paints no resting surface — a `tertiary` `IconButton`, or any control
  styled through `iconButtonVariants({ priority: "tertiary" })`. At `"md"` the
  badge tucks 8px in on both axes, which is what Figma node 7611:19982 draws and
  what the anchored samples (6944:18608 dark / 6944:18738 light) have drawn for the
  tertiary column since 2026-08-12. A filled or outlined anchor gets that visual
  attachment for free from its own painted box; a bare one paints nothing until
  hover, and the badge reads as floating free of the glyph.

  Additive, and nothing moves unless a call site asks: the default and
  `circularAnchor` branches are byte-identical, so all sixteen other drawn cells —
  every filled and outlined anchor at both sizes, and every bare anchor at `sm` —
  are untouched. Only `bareAnchor="md"` takes precedence over `circularAnchor` —
  the one combination where both ask for an inset, and the drawn 8px beats the
  undrawn 14% carry-over. `"sm"` leaves `circularAnchor` in effect: a round anchor
  still needs its tuck whether or not it paints a resting surface.

  `"sm"` resolves to the unchanged geometry, deliberately: Figma draws the bare
  column at `sm` exactly like the other treatments, and taking the size rather than
  a boolean means a later `sm` change lands in the library, not in every consumer.

  One declared divergence, in `Badge.figma.json`: Figma insets the 20×20 counter
  but leaves the 36×20 one corner-centred, and the implementation renders both as
  one intrinsically-sized element (the WCAG 1.4.4 divergence already declared on
  `Size=Large`), so there is no discrete state to key on. The inset therefore
  applies to every badge on a bare `md` anchor, and a 3-character counter sits 8px
  further in than drawn.

- bd57527: feat(button-group): let a ButtonGroupItem be a link (`asChild`)

  New optional `asChild` renders the child as the segment, so a run that
  navigates keeps real anchors — href, middle-click, open-in-new-tab — while the
  group still owns selection and roving focus. Additive; the announced role
  becomes `radio` rather than `link`. Arbitration: `ButtonGroup.rfc.md` §9 Q9.

- 7894eda: Checkbox gains an `error` tone, and SearchField's placeholder is aligned with Input's.

  `Checkbox` takes an `error` prop, recolouring the box border, both glyphs, the label
  and the description to `--color-feedback-error-primary`. Figma added `state=Error` to
  the component set (node 2682:8504, 12 symbols to 15), which supersedes the earlier
  decision that the component would never take one. No new token: the tone reuses
  `--border-input-error`, `--icon-error` and `--text-input-error`. Geometry is unchanged
  and `disabled` still wins, since disabled is a full colour substitution.

  `SearchField`'s `::placeholder` box moves from `--text-input-placeholder` — which
  resolves to the PRIMARY text colour, so an empty field read at the same weight as a
  filled one — to `--text-default-secondary`, and gains the `:disabled`-gated placeholder
  rule it was missing. This is the same fix `Input` received in #172; SearchField was the
  half left open and recorded as such in the guard test.

- 23e0826: feat(chip): add the small Enterprise Edition chip (`size="sm"`)

  New optional `size` prop, default `"md"` — `"sm"` renders the 16px EE marker
  Figma draws for use inside or beside a button, a nav item or a panel row.
  Additive: callers passing nothing see no change. Arbitration: `Chip.rfc.md` §9.6.

- 47baf69: Rename the Depth tokens to `--depth-*` and darken the light-mode elevation hover.

  **Breaking for consumers.** Figma's `Size` collection renamed the emitted prefix of
  its `Depth/*` group, so `--shadow-sm/md/lg/xl` are now `--depth-sm/md/lg/xl`. The
  values are unchanged (4 / 8 / 16 / 20px), but a product importing the old names
  loses them, and Tailwind's `shadow-sm/md/lg/xl` utilities revert to Tailwind's own
  defaults.

  Read that as a repair rather than a regression: those utilities were already
  broken. A scalar length sitting on Tailwind v4's reserved `--shadow-*` namespace
  makes `shadow-sm` emit an invalid `box-shadow`, voiding the whole declaration —
  focus ring included, since that is a box-shadow too. ColorPicker's Hue and Alpha
  thumbs and the Slider thumb each carry a comment recording that they omit
  `shadow-sm` for exactly this reason, and `Paper.rfc.md` records the family as
  declared but consumed by zero shipped components. The rename frees the namespace.
  `--shadow-global-shadow` is untouched — different token, different collection.

  Light `--bg-elevation-hover-layer-0/2/3` also move to `var(--gray-200)`
  (`#f4f4f6`/`#e4e5e7` → `#cacbce`); dark is unchanged, and `layer-1` deliberately
  stays `var(--gray-150)`. Two lock-ins were re-derived against the new values rather
  than relaxed: the ProductSwitcher dropdown palette (light `--bg-input-hover`
  16.02 → 10.84) and the navbar hover arbitration, whose separation net is now pinned
  per mode with each direction asserted positively.

- 2e384c8: FileSelect: keep the trigger beside the selection, and draw a single filename as text

  Re-read of Figma node 6460:25149 after a designer update. Two states disagreed
  with the shipped component, and one of the two corrections changes an observable
  contract rather than only the paint.

  **The trigger is now rendered in every state.** It was gated behind
  `!hasSelection`, and since it is `openDialog`'s only caller, hiding it meant a
  selected field could not open the picker at all: in single mode a replacement pick
  required clearing first, and in `multiple` mode no second file could ever be added
  without emptying the whole selection. Both `State=Select` (7304:12252) and
  `State=Multi select` (7304:12344) draw the trigger next to the selection — in the
  multi slot it is the first item of the wrapping row.

  **Minor, not patch:** with the trigger reachable, a later pick in `multiple` mode
  now **appends** to the selection where it previously **replaced** it. Consumers
  that call `onValueChange` and persist the array will observe the accumulated
  selection where they used to observe only the latest batch. Replacing was not a
  defensible option once the trigger is reachable — it would make the extra files
  unreachable. Single mode still replaces, unchanged.

  **The single filename is now in-field text, not a `<Chip>`.** A chip implies a
  per-file delete control, which single mode does not have: there the selection is
  emptied through the field-level clear. `multiple` keeps chips, which do carry a
  per-file delete. The text binds `--text-default-primary` rather than
  `--text-input-placeholder` — the two resolve to the same value today, but the
  filename is primary content and must not follow the placeholder token when that
  known-mis-named token is retuned. The full name stays reachable through a controlled
  `<Tooltip>` that opens only while the name is actually clipped and is reachable by
  hover and keyboard focus alike — not a native `title`, which fires whether or
  not the name is cut and is mouse-only.

  The trigger is also disabled while `loading`, so a second pick cannot overlap an
  upload in flight.

  The existing suite only exercised `multiple` mode with a pre-built `value` array,
  so it never performed a second pick and could not see either problem. Fifteen tests
  now pin the behaviour, including one that fails against the previous Chip
  rendering rather than passing against both.

- 8aaa846: Add the Header's integrated search; repaint the disabled field as an outline.

  Sandy edited the Input node on 2026-08-28. Six field components were re-read at
  ROOT from their own Figma nodes via the REST node tree — `boundVariables`, hidden
  layers skipped, both modes — and two changes came back.

  **Disabled is outlined, not filled — all six.** `Input`, `Textarea`,
  `SearchField`, `Combobox` (trigger), `FileSelect` and `Select` (trigger) each
  paint `fills: []` on the disabled field and carry a single 1px
  `--border-elevation-disabled` stroke instead of the `--bg-input-disabled` fill
  they used to. `Chip` made this exact transition on 2026-08-20; this is the same
  token and the same shape, applied to the field family.

  Losing the fill puts the disabled text on the page, which **raises** its
  contrast from 3.69:1 light / 4.35:1 dark — passing only under WCAG 1.4.3 Note 1's
  inactive-component exemption — to **5.34:1 light / 6.60:1 dark**, clearing 4.5:1
  outright. All six now DECLARE that pair instead of exempting it, plus the border
  that carries the state alone (3.72:1 light / 3.25:1 dark). `SearchField`'s
  existing `placeholder when disabled` pair was re-pointed: it named
  `--bg-input-default`, a surface the disabled field never painted.

  **Leading padding 16px → 12px, but only where the node says so.** `--spacing-3`
  on `Input` (all six variants), `Textarea` and the `Combobox` trigger. It does
  **not** apply to `Select` (still 16px), `SearchField` (8px) or `FileSelect`
  (8px), each re-read and confirmed unchanged — the reason every component was
  read from its own node rather than inheriting Input's. `Input`'s `hasStartIcon`
  inset follows from `pl-9` to `pl-8` so the icon-to-text gap stays the 4px
  `Gap/gap-xs` the node specifies, and `Textarea`'s `px-4` splits into `pl-3 pr-4`.

  Two capture errors are corrected in passing: `Input`'s Error and Success
  variants recorded a 16px right edge and a "symmetric px-4" rationale; the node
  binds `Padding/padding-xs` (8px) on the right of all six, so that reading is
  withdrawn.

  No API change. Every `.figma.json` grew rather than shrank (Input 85→88 checks,
  Combobox 158→159, SearchField 111→113, Select 77→78, Textarea 71→73, FileSelect
  85→86), and each spec change was proven red before the code change landed.

  ## The Header's integrated search — new API, opt-in

  `HeaderSearch` composes the library's `SearchField` with the library's `ButtonGroup`
  seated inside it, as the growing middle cluster Figma draws at node 2823:1330 →
  2863:3354 → 7447:31627 (re-read at ROOT 2026-08-28, after Sandy turned the
  `buttonGroup` layer on).

  This overrules `Header.rfc.md` §4.2, which made global search a slot — Sandy's
  ruling of 2026-08-28: that section predates SearchField, so the slot was a workaround
  for a missing component, not a doctrine. Only that one row flips; the account menu,
  notifications, workspace picker and assistant entry stay slots for §4.2's own reason.

  **Opt-in, in the strongest available sense: absent unless written.** A Header that
  does not use it renders identically to before, and that is measured rather than
  asserted (`Header.integrated-search.test.tsx`). Products enable it at their next pin
  bump. It is a part you place rather than a prop on `Header` because Figma puts the
  search BETWEEN the two other clusters, and `Header` distributes with
  `justify-between` — a prop would have to split `children` to land there.

  `disabled` disables the field and HIDES the toggles outright — node 7449:32648 keeps
  the group but sets its opacity to 0, and toggles that do nothing are better absent
  than painted inert; the field then takes back its normal trailing padding, since the
  flush edge exists only to seat a group. `modes` omitted gives a plain header search;
  `grow` forwards to `HeaderGroup`, so `"unbounded"` still escapes the 400px cap. The
  toggles are a radio group — one tab stop, arrow keys between segments.

  `minor`, not patch: this is new public API (`HeaderSearch`, `HeaderSearchProps`,
  `HeaderSearchMode`). The disabled/padding work above remains behaviour-only, but a
  release carrying both is a minor.

  The composition cannot be asserted by `check:figma-fidelity` — it is a choice of
  components, not a class — so `Header.figma.json`'s `header-search` entry declares
  only what the Header itself contributes (`h-9`, the cluster geometry) and the
  composition is locked by a named guard instead, the pattern AGENTS.md prescribes.

- 0ed2581: Publish the spacing scale in the delivered stylesheet, and budget that stylesheet.

  `dist/index.css` now carries margin and padding utilities across the sanctioned
  steps, every one derived from the single `--spacing` token. Until now the emitted
  set was a side effect of which steps the library's own components happened to use:
  `.mb-4` shipped, `.mt-4` did not. Consumers have no Tailwind of their own, so a
  product writing `className="mt-5"` got no margin, no error and no gate — measured on
  OpenCTI as 27 inert uses across 24 files, plus one of `mt-4`.

  Same mechanism as Paper's padding safelist, generalised from one component's public
  scale to the library's public spacing scale, and asserted against the real compiled
  output by `spacing-scale-emission.test.ts`.

  `check:bundle-size` now also measures `dist/index.css`, which was previously
  unbudgeted — the one artefact a safelist can grow without touching a JS byte.

- 1f7c64c: Add `Select`'s clear control and `Input`'s `isTypeNumber` stepper

  Two new API surfaces on two existing components, both extracted fresh from
  Sandy's Figma, both additive.

  **`Select` gains `clearable`** (plus `clearLabel`), the same prop name and the
  same self-hiding contract as `Combobox`'s: the × renders only when there is
  something to clear, and never while the field is disabled. Node `2686:4645`
  draws it as the first of two flush 24×24 boxes at the end of the field, on
  `--icon-highlight` — which is this library's `IconButton priority="tertiary"
size="sm"`, so that is what the component renders. The chevron gained the 24×24
  box the node has always drawn around it (its glyph previously sat 4px right of
  the node), and the pair is now flush, measured at 0px in a real browser.

  One arbitration, closed, and one standing rule. The node used to draw no × on
  the Error variant while the component kept one, because a field in error still
  holds a value the user must be able to empty; Sandy arbitrated in the
  component's favour and updated the node, which now draws the same pair there as
  in Default/Hover/Focus. And unlike `ComboboxClear`, this control IS a tab stop:
  a control leaves the tab sequence only when the focused element already offers a
  keyboard path to the same action, and a Select trigger has none.

  Radix reserves the empty string for "no value", and an uncontrolled Radix root
  exposes no way to write it, so `Select` now mirrors its value and drives the
  primitive controlled in both shapes. `defaultValue` seeds the mirror instead of
  reaching the primitive; no consumer-visible behaviour changes.

  **`Input` gains `isTypeNumber`** (plus `step`, `min`, `max`, `incrementLabel`,
  `decrementLabel`), the 16×32 increment/decrement column of node `7453:33917`,
  with the browser's own spinners suppressed by a new `appearance-textfield`
  utility so only one set renders. The accessibility is the platform's: the field
  becomes a native `type="number"`, which supplies the `spinbutton` role, the
  ArrowUp/ArrowDown stepping and the `aria-value*` attributes, and the pointer
  path calls the element's own `stepUp()`/`stepDown()` so rounding and clamping
  are the UA's too. The two arrows are outside the tab sequence for the reason
  above — the focused input already steps — and each disables itself once the
  value reaches its bound, on `--icon-disabled`: the node draws no per-arrow bound
  state, so reusing the one disabled treatment it does draw for these arrows was
  an arbitration, approved by Sandy. Unlike `endIcon`, the stepper is not masked by the
  error/success indicator: nodes `7453:34636` / `7453:34721` draw the two side by
  side, so the field's right inset goes from 28px to 44px when both are present.

  `SelectTrigger` now renders a wrapper element around the Radix trigger, because
  the clear is a real `<button>` and nesting it would be an axe
  `nested-interactive` failure. The wrapper is `w-full`, so a `w-full` on the
  trigger still resolves against the field's real container; the one layout this
  changes is a `Select` used as a direct flex-**row** item, where the wrapper
  claims the row instead of hugging its content — give that container a width
  class.

  Both features ship with their Figma specs (Select 89 checks, Input 107, both
  green from red), their contrast pairs computed by `check:contrast` in both
  modes, 36 component tests, and six browser proofs in
  `docs/e2e/input-number-stepper.spec.ts` for the keyboard behaviour jsdom cannot
  run. They unblock roughly 14 OpenCTI sites (3 clearable selects, 11 number
  fields); no product work is included here.

- b0715dc: Tabs: add `panels="external"` so a tab set that renders no panel stops
  emitting a dangling `aria-controls` (additive, no breaking change).

  Radix computes `aria-controls` on every trigger from that trigger's `value` —
  the id it _would_ give the matching `TabsContent` — and has no way to know
  whether that panel is ever rendered. The RFC has always allowed the panel-less
  strategy (RULE-03: panels managed externally, or a route-based bar whose
  "panel" is the router outlet), and in that shape the id resolved to no element.
  Measured with axe on the same tree, panel vs no panel: **0 violations** with a
  panel, **`aria-valid-attr-value`, impact critical**, without — on the selected
  trigger, which is the only one axe checks (it skips `aria-controls` on an
  element that is neither `aria-expanded="true"` nor `aria-selected="true"`).
  This blocked converting OpenCTI's navigation-style tab bars, the largest of
  which spans 41 screens.

  - `<Tabs panels="external">` drops `aria-controls` from that tab set's
    triggers. The default, `panels="content"`, is unchanged: panels are
    `TabsContent` children and every trigger keeps pointing at its own. The
    strategy is declared on the root rather than per trigger because RULE-03
    already makes it a property of the whole set — a 41-tab bar declares it once
    and no trigger can drift out of step with its siblings.
  - An explicit `aria-controls` on a `TabsTrigger` still wins in both strategies,
    which is the right call when the external panel is a real element whose id
    the caller owns.
  - Nothing else about the tab contract changes: `aria-selected`, roving
    arrow-key focus, activation mode and the `disabled` handling are identical in
    both strategies.
  - The root mirrors the strategy as `data-panels` — a stable hook alongside
    Radix's own `data-orientation`, so a test or a product stylesheet reads what
    the tab set _declared_ instead of inferring it from a missing attribute,
    which is also what the regression would look like.
  - A `TabsContent` rendered under `panels="external"` contradicts the
    declaration and warns in development (the panel still renders; its trigger no
    longer points at it). No gate could see that loss on its own — a _missing_
    optional attribute is not an axe violation.
  - The docs smoke helper (`openAllTabs`) asserted that every `role="tab"` on a
    showcase page carried a resolvable `aria-controls`. It now reads the tab
    set's declared strategy and asserts the attribute in both directions: present
    and resolvable under `panels="content"`, absent under `panels="external"`.

- 04bc154: Tabs: add vertical orientation and a `TabsMenuTrigger` part (both additive,
  no breaking change).

  - `orientation="vertical"` now lays `TabsList` out as a right rail: triggers
    stack into a left-aligned column, the active indicator moves from the bottom
    edge to the right edge (`rounded-l-sm`), a `TabsMenuTrigger` hugs the last tab
    and `actions` are pinned to the bottom of the rail (`mt-auto` — the column
    analogue of the horizontal `ml-auto`), and the automatic overflow affordance
    rotates to the cross axis (up/down chevrons with `aria-label="Scroll tabs
up"/"Scroll tabs down"`). Arrow-key navigation follows the vertical axis (↑/↓,
    Home/End) per the WAI-ARIA tabs pattern. Vertical labels truncate with an
    ellipsis when the caller bounds the rail width — the full string stays the
    accessible name and is mirrored into `title` — so a long/translated label
    never forces the rail wider than its container.

  - Scroll-arrow focus (horizontal and vertical): when the focused scroll arrow
    unmounts because its end was reached, focus now moves to the **opposite**
    arrow (which is guaranteed to be mounted) instead of bouncing to the active
    trigger. This keeps keyboard/AT users at the overflow control they were
    operating and prevents a silent jump to `<body>`.

  - `TabsMenuTrigger` is a new part for the OpenCTI "Custom view" pattern: a
    tab-looking control that opens a dropdown (the FDS `Menu`) instead of
    switching a panel. It is a menu button (`aria-haspopup="menu"`), **not** a
    `role="tab"` — authored among the `TabsList` children but lifted out of
    `role="tablist"` and rendered as a DOM sibling after the last tab, so
    `aria-required-children` stays satisfied. Focus return on close is
    modality-aware (WCAG 2.4.3): a keyboard dismissal returns focus to the
    trigger, a mouse pick does not. `TabsMenuTriggerProps` extends the native
    `button` props (arbitrary attributes and refs are forwarded; `type` is fixed
    to `button` and omitted); it deliberately does not support `asChild` — the
    part's whole value is composing the FDS `Menu` with the reserved-label +
    chevron affordance, and `asChild` would strip that internal wiring and leave
    the consumer to rebuild the menu by hand, at which point they should compose
    `Menu` + a plain button directly instead. A string label is width-reserved at
    its bold weight so the active-weight change never reflows the row; any other
    node renders as-is.

- 6e53dcd: Give `Textarea` a `resize` prop, defaulting to the browser's own default.

  `"none" | "horizontal" | "vertical" | "both"`, mapped to the matching Tailwind
  class on the `<textarea>` itself. It exists for the case opencti asked for: a
  bulk-search field that must not be resizable at all (`resize="none"`).

  **Purely additive.** The default is `"both"`, which is what a `<textarea>`
  already did: before this prop the component declared no `resize` at all and the
  field inherited the UA default. That default was verified in a browser rather
  than assumed — a bare `<textarea>` and one under Tailwind's preflight both
  compute `resize: both`, since preflight does not reset the property. So every
  call site that does not pass `resize` renders exactly as it did before; the ~31
  `Textarea` instances in opencti (26 of them through its `TextareaField` Formik
  wrapper), none of which passes the prop, are unaffected.

  A narrower default such as `"vertical"` would have silently removed horizontal
  resizing from all of them, which is why the default is pinned by its own test
  (`Textarea.test.tsx`, "defaults to `both`, the UA default") with the decision
  named in place — that assertion replaces the guard that used to hold the line
  before a `resize` prop existed.

  The GAP-T1 design exemption (Sandy, 2026-08-26) is untouched: the node's `Drag`
  vector is still not drawn, which is what the exemption rests on, and this prop
  drives the browser's own handle rather than a painted one. `Textarea.rfc.md`
  §3.6 / §4.2 / §9 Q3 said the prop was "not proposed" pending that ruling; the
  ruling has landed, so those rows now record the shipped API instead.

### Patch Changes

- 3b85bad: Restructure AGENTS.md so the complete operating contract — hard rules, the
  priority rule products follow, the production and independent-review session
  protocols, and the pre-PR filter — occupies the first 160 lines, ahead of the
  long-form reference. The previous layout put the contract behind 83 KB of
  detail, past the point where Codex truncates a merged AGENTS.md set (32 KiB).

  Add `generate:mui-regression-policy`, which emits the per-product data a
  product repository needs to refuse NEW MUI imports for components the library
  has already replaced there.

  Inject the migration's recurring traps into `process/LEARNINGS-ACTIVE.md`
  (L133-L137) and add a consistency check: a component a product already renders
  cannot still be `in-review`. `pnpm generate:adoption --check` now fails on that
  contradiction, and it runs before anything that needs a product clone so CI
  cannot skip it.

- 8b99c79: FileSelect: the in-field trigger is a primary Button

  The Figma was updated on 2026-09-02 to draw the trigger as a **primary** (filled
  brand-blue) Button instead of the secondary outline the component shipped. Read
  from the node's own variables rather than the render: `State=Default`
  (6460:25151) now binds `--color-filigran-brand-primary` and
  `--text-negative-primary` — the filled-primary signature — and
  `--color-filigran-brand-primary-transparency-55`, the secondary rest-state
  border, is absent from the state.

  A repaint, not a contract change: `priority` was never a FileSelect prop, so no
  API moves and no consumer has to do anything. The trigger's fill, label and hover
  tokens stay the composed Button's own, and FileSelect still declares no contrast
  pair for it — Button's meta already covers its fill and label in both modes,
  which is why this needs no re-audit here.

  It does supersede the premise of arbitration Q2 and of §3.6 GAP-F1, both of which
  existed to explain how the secondary _border_ was resolved by composition. A
  primary trigger draws no such border. That token remains live as the shared focus
  ring, which `State=Focus` still maps.

- 934dca6: Anchor the collapsed `Navbar`'s submenu flyout flush against the rail, as the frame binds.

  `NavbarSubmenu`'s collapsed-mode flyout is a Radix `DropdownMenu.Content` and it
  shipped `sideOffset={8}`, which Radix applies along `side="right"` as a translation
  away from the trigger. Figma says flush: in node 6668:12107 the collapsed rail
  instance is 48px wide and the trigger row's `Submenu` slot sits at x=48, y=0
  relative to that row, and the group enclosing rail plus open flyout measures
  227px = 48 + 179 — so any gap makes that group wider than the maquette. Measured on
  the docs site's own collapsed rail in Chromium: rail right edge 48.00px, panel left
  edge 56.00px, an 8.00px strip of page background between the two, identical in dark
  and light.

  `sideOffset` goes 8 → 0, and `alignOffset={0}` is stated alongside it. Both are
  written out although 0 is Radix's own default for each: they are measured design
  values, and an absent prop cannot be told apart from an unconsidered one — the same
  reason `ProductSwitcher` states `side="bottom"` explicitly. What does **not** change:
  the vertical anchor and the panel's 179px width were already correct and were
  re-measured as correct after the fix, the panel's fill and the rows'
  padding/height/tones are untouched, and there is no API change — the flyout exposes
  no positioning props to consumers.

  The two zeros are now recorded in `NavbarSubmenu.figma.json` as
  `flyout-side-offset` / `flyout-align-offset`, the same negative-fact treatment
  `item-gap` got in the 2026-08-03 density pass, and guarded in two layers because
  neither can see the other: `scripts/lib/navbar-flyout-anchor.test.ts` reads the props
  off the AST and checks them against that spec, while
  `docs/e2e/navbar-collapsed-flyout-anchor.spec.ts` measures the rendered gap in a real
  engine. The second layer is not redundant — Radix positions the panel against the
  _trigger's_ box, so a rail that grew horizontal padding would reopen the visible gap
  with `sideOffset={0}` still reading correct in the source; that premise ("the trigger
  row spans the full rail width") is asserted there as its own step.

- 52a7b51: Stop the collapsed `Navbar` rail from painting a keyboard focus border after a mouse hover, and make its flyout rows reachable by keyboard.

  **Stray focus indicator after a pure mouse gesture.** Hovering a collapsed rail row
  opens its flyout and moving the pointer away closes it — but Radix's
  `DropdownMenu.Content` returns focus to its trigger on EVERY close, and Chromium
  carries `:focus-visible` across a programmatic `focus()` (the mechanism
  `src/lib/pointer-nav.ts` documents). So the row was left focused, and painted its
  2px brand focus border, after a gesture that never involved the keyboard. Measured
  on the docs rail: after hover-then-leave, `document.activeElement` was the trigger
  with `:focus-visible` matching and `border-color` #42caff dark / #0015a8 light,
  while an otherwise identical row with no submenu left focus on `<body>`. That
  asymmetry is why it read as affecting only specific items — those were the only
  rows with a submenu.

  Focus now returns to the trigger only after a genuine keyboard DISMISSAL: Escape
  (and ArrowLeft, see the keyboard model below) arms a flag which `onCloseAutoFocus`
  consumes, and Radix's own unconditional return is cancelled in every other case.
  Escape still returns focus and still paints the indicator (WCAG 2.4.3) — what
  changed is the gate, never the return itself, since suppressing the return would
  trade a cosmetic defect for a lost-focus bug.

  Deliberately narrower than the general "last modality" flag `Tabs` keeps for its own
  menu, and this is the part worth reviewing: a modality flag defaulting to `keyboard`
  returns focus on any close it has not classified as pointer-driven, and one of those
  is a close caused by focus legitimately moving elsewhere — Tab out of an open panel
  and the handler snaps focus back onto the trigger, stealing it from the element the
  user just reached. That is not hypothetical: the first version of this fix did
  exactly that, and `docs/e2e/navbar-submenu-icon-tone.spec.ts` caught it on the demo
  page, whose flyout is open on load.

  Not fixed by suppressing the border: the trigger really was focused, so the
  indicator was telling the truth. What was wrong was the focus move.

  **Flyout rows that were not menu items.** The collapsed flyout wraps each child in
  `DropdownMenu.Item asChild`, which clones `role="menuitem"`, the tabindex, the
  collection registration and a ref onto that child. `asChild` only works on a child
  that forwards what it receives to a DOM node — and a consumer component accepting
  only its own props drops all of it, silently, with the row still rendering and
  still looking correct. Only the keyboard dies. The library's own usage was always
  fine (its demo exposes real menu items); this repo's **docs rail** was not, and is
  fixed here: its `ComponentLink` took `{ slug }` and forwarded nothing, so the panel
  opened with 14 plain `<a>` rows, zero menu items, nothing focusable and arrow keys
  inert — with every gate in the repository green.

  Because that failure is invisible, the library now warns in development when rows
  in an open collapsed flyout do not become menu items, naming the counts and the
  remedy. Warn, never throw — the same prop-contract precedent as the existing
  `href`/`to` diagnostic. The audit runs from the panel's own ref callback rather
  than an effect: Radix mounts the portalled content on a later commit than the one
  that flips the open state, so an effect keyed on it runs while the panel is still
  absent and never re-runs. Product rails that wrap their rows in a local component
  will now see this warning instead of silence.

  No API change. Guarded by
  `NavbarSubmenu.flyout-item-contract.test.tsx` (the row contract and the
  diagnostic) and `docs/e2e/navbar-collapsed-keyboard.spec.ts` (the rendered focus
  behaviour in both themes), the latter verified to fail on the unfixed build.

  **Collapsed-rail keyboard model (@sandy's spec, 2026-09-01).** Focus arriving on a
  submenu trigger now opens its flyout with no key press, and focus stays on the
  trigger; Tab onward closes the previous panel and opens the next; ArrowRight moves
  focus into the first row; ArrowLeft from any row returns focus to the trigger and
  closes it. Escape is unchanged.

  Three implementation facts worth knowing, each measured rather than assumed:

  - Radix focuses its own panel the instant it opens, which put focus INSIDE the
    panel on a plain Tab — ArrowRight then had nothing to act on, and Enter on a link
    trigger hit a menu row instead of navigating. A focus-driven open refuses that
    via `onOpenAutoFocus`. That prop is not in `DropdownMenuContentProps`, but
    `DropdownMenuContent` spreads its remaining props straight onto `Menu.Content`,
    which implements it, and intercepts only `onCloseAutoFocus`/`onInteractOutside`
    — read from the installed build rather than inferred, and the cast says only
    that.
  - Escape and ArrowLeft both end with focus on the trigger, and focus on the
    trigger opens the panel. Left alone they are no-ops: the panel closes, focus
    returns, the panel re-opens. Each deliberate close therefore arms a
    consume-once suppression, so a later Tab back onto the same trigger still opens.
  - Radix opens on ArrowDown/Space/Enter and focuses the first row as part of that
    OPEN transition. Once focus has already opened the panel there is no transition
    left, so those keys went inert (ArrowDown, Space) or toggled the panel shut
    (Enter) — five of this component's own keyboard tests caught the latter. They
    now enter the panel like ArrowRight, except Enter on a LINK trigger, which keeps
    navigating.

  `NavbarSubmenu.keyboard.test.tsx`'s "Enter on a link trigger does NOT open the
  flyout" case was updated rather than kept: under this spec the panel is already
  open when focus lands, so what is pinned now is that Enter navigates and that the
  opening was not Enter's doing.

- 5cfccef: Add `linkComponent` to `NavbarSubmenu` and `ProductSwitcher`, so an internal destination is a route instead of a full page reload.

  Both components rendered a bare `<a href>` when given `to`, so clicking a collapsed
  submenu trigger, an internal product option, or the ProductSwitcher logo performed
  a **full page reload** — confirmed at the network level in OpenCTI (a document
  request fires and the page mount id changes). There was no way for a consumer to
  inject its router's link component.

  The cause in both cases was the same one line shape: `href ?? to` (and
  `logoHref ?? logoTo`) collapsed two different intents into one string, after which
  the element could only ever be an anchor. `href` and `to` are now distinct:

  - `href` renders a plain `<a href>` — a real document load, which for
    `ProductSwitcher.href` also keeps `target="_blank"`. Routing it would be wrong,
    not merely slower, so it is deliberately left alone.
  - `to` is forwarded verbatim to `linkComponent`, exactly the contract
    `Breadcrumbs` already exposes (`linkComponent?: React.ElementType`, default
    `"a"`) and that OpenCTI already uses correctly there. Pass it once
    (`linkComponent={Link}`) and the component keeps ownership of the row body,
    icon, chevron, `aria-current` and the whole flyout.

  `ProductSwitcher` covers all three of its destination sites: an option's `to`, and
  the trigger logo's `logoTo` in both the collapsed-control and expanded-logo
  branches.

  Two behaviours a reviewer would reasonably worry about are preserved, and asserted:

  - **`Enter` still navigates** on a link trigger. It works by replaying a synthetic
    `click()` on the focused element, and a router link renders a real anchor, so the
    click goes through the router.
  - **Ctrl/Cmd-click and middle-click still open a new tab**, because the destination
    stays a real `href` in the DOM. This is precisely why the fix is a component swap
    and not an `onClick` that calls `navigate()` — that shape would have broken both
    silently.

  Without a `linkComponent`, a `to` still renders an anchor and warns in development
  rather than becoming inert: a product that has not opted in keeps working exactly as
  before and only loses the reload once it opts in. That is a deliberate divergence
  from `Breadcrumbs`, which falls back to plain text — an unreachable navbar entry or
  product-switcher row would be worse than a slow one.

  `NavbarSubmenu.rfc.md` §4.4's migration row is corrected in the same change. It
  claimed `href={item.path}` gave "the same collapsed-only semantics" as openaev's
  `component={Link} to={item.path}`, and that claim is what let this regression ship:
  dropping the router component is not a detail of the migration, it is the defect.

- b6eb035: NavbarSubmenu: a collapsed flyout opened by focus no longer dismisses itself

  Focus arriving on a collapsed trigger opened the flyout and then closed it a few
  frames later, so the panel flashed and keyboard users could never reach it.
  Measured in opencti: mounted at +10ms, unmounted at +58ms, with focus still on
  the trigger and no further input.

  Radix's `DismissableLayer` was firing `focusOutside` naming the trigger itself. A
  focus-driven open deliberately keeps focus on the trigger
  (`onOpenAutoFocus` is refused for that path), and Radix does not count a composed
  trigger as part of its layer — here `DropdownMenu.Trigger asChild` ->
  `NavbarItem asChild` -> `linkComponent`, where the injected component adds the
  Slot layer that loses the association. The panel therefore dismissed itself for
  focus that was, from the user's point of view, inside it.

  `onFocusOutside` is now refused when the focus target is the trigger or a
  descendant of it. Focus moving anywhere else still dismisses, so tabbing onward
  closes the flyout exactly as before.

  Only the collapsed flyout is affected; the expanded accordion has no dismissable
  layer. The docs navbar never showed this because its triggers are plain buttons
  and its one link trigger uses `href`, which Radix renders itself — the defect
  needs a `linkComponent`, which is why it surfaced in a product first.

  No automated test covers it: jsdom does not implement Radix's focus-outside
  semantics (a harness test passed either way), and the docs app has no
  `to` + `linkComponent` trigger fixture to drive in a real browser. Reproducing it
  under Playwright would mean adding that fixture, which is worth doing separately
  rather than shipping a test that passes regardless.

- 3a54472: Add `to` and `linkComponent` to `NavbarSubmenuItem`, so a submenu child row is a route instead of a full page reload — or a re-implemented row body.

  PR #207 gave `linkComponent` to `NavbarSubmenu`'s trigger and to `ProductSwitcher`,
  because a bare `<a href>` on an internal destination is a **full page reload** —
  confirmed at the network level in OpenCTI (a document request fires and the page
  mount id changes). It could not reach `NavbarSubmenuItem`, the row inside an open
  submenu, which exposed no destination prop of its own at all: only
  `{ asChild, showIcon, icon, children }`.

  So a routed row had exactly one route: `asChild`. That does navigate correctly, and
  it stays supported. What it costs is the row body. `asChild` hands the element over,
  and this row's element is what carries the icon `<span>`, the label `<span>` and
  their per-state tones (RFC §3.2/§3.4) — so every consumer using it re-implements
  those two spans, and nothing in this library can see them drift. OpenCTI ships that
  today as FDS-WORKAROUND #7.

  The row now takes the same three-way contract as its siblings:

  - `href` (already inherited from the anchor props this row extends) renders a plain
    `<a href>` — a real document load, deliberately untouched.
  - `to` is forwarded verbatim to `linkComponent`, the contract `Breadcrumbs` already
    exposes (`linkComponent?: React.ElementType`, default `"a"`). Pass it once
    (`linkComponent={Link}`) and the component keeps the icon, the label, the
    truncation, the overflow tooltip and `aria-current`.
  - Both set is a prop-contract violation: `href` wins, `to` is ignored, dev-only
    warning, never thrown.

  The behaviours a reviewer would worry about are preserved for the same reason as on
  the trigger, and asserted:

  - **`Enter` still navigates**, because activating the row replays a click on a real
    element and the injected component receives it.
  - **Ctrl/Cmd-click and middle-click still open a new tab**, because the destination
    stays a real `href` on a real `<a>` in the DOM. This is why the fix is a component
    swap and not an `onClick` calling `navigate()`, which would break both silently.
  - **The row is still a menu item in the collapsed flyout.** That one is specific to
    this level: `DropdownMenu.Item asChild` clones the menuitem role, tabindex and
    keyboard wiring onto the row, and those props now have to travel through the
    injected component to reach the anchor. A row that stopped being a menu item would
    kill the flyout's keyboard exactly the way the docs rail once did.

  Without a `linkComponent`, a `to` still renders an anchor and warns in development
  rather than becoming inert — the same deliberate divergence from `Breadcrumbs`'
  fall-back-to-text the trigger already makes, since an unreachable navbar row would be
  worse than a slow one.

  `asChild` combined with `to`/`linkComponent` takes priority and warns, naming what it
  ignores: the child element you pass already owns the destination.

  No visual change on any of the five states — the row body, its classes and its tokens
  are identical whichever element carries the destination, so the RFC's contrast pairs
  are untouched.

- d41b023: Document `ProgressBar` and `Spinner` on their own pages.

  Both metas declared `docsGroup: { id: "spinner", … }`, which collapsed them into
  a single Feedback rail entry named "Spinner" — `ProgressBar` had no entry of its
  own, because the site never reads `docsGroup.label` ("Progress"). Sandy's ruling
  (2026-09-03, `Spinner.rfc.md` §9 Q11) is one page each, so the field is removed
  from both metas. They are published through the `@filigran/design-system/meta`
  subpath, hence the bump; no component, token or runtime behaviour changes, and
  `/components/progress-bar` keeps resolving.

- 5109b5e: Take the `Select` trigger's leading edge to 12px, with the other field surfaces.

  `Input`, `Textarea` and the `Combobox` trigger moved from 16px to 12px in #189.
  `Select` did not, and that was correct at the time: #189 re-read this node and it
  still bound 16px. The frame has moved since — file `lastModified`
  2026-08-29T13:15:35Z, after that read.

  Re-read at ROOT via the REST node tree, all five variants of node 2684:4692
  (2686:4645 Default, 2686:4646 Hover, 2686:4650 Focus, 2686:4651 Error, 2686:4652
  Disabled): every one binds `paddingLeft` to `spacing/3` = 12px and `paddingRight`
  to `Padding/padding-xs` = 8px. The trigger goes `pl-4` → `pl-3`; the spec change
  was proven red first (`expected class "pl-3" ... is not among the classes actually
applied`, 90 checks / 1 failure) before the class landed.

  The dropdown **item** is unaffected and keeps `pl-4`: node 2684:5049 still draws
  its text at x=16. Sandy's ruling names the trigger, and the node agrees.

  No API change, and the clearable geometry is unmoved — the `×` and the chevron are
  measured back from the trigger's right edge (`-ml-14`, `pl-6`), which a change to
  the leading edge does not reach. Verified in a browser rather than assumed.

- 9a3992e: Stop the `Select` trigger wrapper from forcing `w-full`, so a flex-row `Select` hugs its content.

  The clear-control wrapper `<span>` added in #190 carried `flex w-full items-center`.
  `Select` renders no DOM node of its own (`SelectPrimitive.Root` is a context
  provider), so that wrapper is a direct child of the consumer's layout. As a
  block-level flex container it already fills a block or flex-column parent, so the
  `w-full` was redundant there — but as a direct flex-ROW item it claimed the whole
  row and shoved following siblings off. Measured on the ColorPicker format row: the
  wrapper took 336px and crushed the R/G/B channel inputs to ~2px each; with `w-full`
  removed the wrapper is 80px and each channel is 87px.

  The wrapper goes `flex w-full items-center` → `flex items-center`. What does **not**
  change: block and flex-column parents still fill (cross-axis stretch — before/after
  400px), so consumers using `className="w-full"` on the trigger for full width are
  unaffected; the clear control's geometry (`-ml-14`, `pr-2`) and the trigger's
  `w-fit` base are untouched; there is no API change. The one case that changes is a
  `Select` whose direct parent is a flex-row: its width now belongs on the row track,
  not on the trigger (a `w-full` on a shrink-to-fit wrapper resolves against content —
  52px instead of a 291px track). See `Select.rfc.md` §6.1 and
  `process/LEARNINGS-ACTIVE.md` L138.

- a7bdb04: Fix Tabs: route-based bars reflowed on selection, and the badge name could not be translated

  Both found while converting OpenCTI's tab bars.

  **A route-based bar shifted every time you changed tab.** The active trigger
  turns semibold, and `ReservedLabel` normally reserves that bold width so nothing
  moves — but the `asChild` branch returned the child untouched, skipping the
  reservation entirely. Every route-based bar makes ALL of its triggers `asChild`
  (each one wraps a router `<Link>`), so each selection resized the active tab and
  pushed its neighbours sideways. The child element is now cloned with its own
  children wrapped, which keeps Slot's single-child contract; a child carrying no
  children is returned untouched, since there is nothing to reserve.

  **The badge's accessible name was hardcoded English.** `aria-label` was always
  `` `${badge} items` ``, with no prop to override it and no i18n hook, so a
  French UI announced "5 items" on every counted tab — 13 of them in OpenCTI. The
  new `badgeLabel` prop takes the localised string; the default is unchanged.

  Also adds the first coverage for `TabsContent asChild`, which was untested and
  undocumented although it is the only way to place a panel where a `<div>` is
  invalid — a panel that must BE the `<tbody>` of a table.

  Scope limit worth knowing: the reservation needs the child's own children to be
  a plain string. An `asChild` child holding an element or an array — an icon
  sitting beside the label — is returned untouched and reflows as before. Pinned
  by a test so it stays a known boundary.

  No token, no DOM structure and no existing API changed.

- afd1198: Fix Tabs: a clipped focus indicator, and tabs out of line with `actions`

  Both surfaced while converting OpenCTI's tab bars — the entity bar alone is
  shared by 41 screens.

  **The focus indicator was cut off.** `TabsList` scrolls on the main axis, and a
  scroll container clips whatever its children paint outside their own box. Per
  CSS overflow, a used `overflow-x: auto` also promotes a `visible` overflow-y to
  `auto`, so the strip clipped on both axes. The trigger's focus treatment was
  `ring-2` + `ring-offset-2` — 4px of bleed outside the box — and came back sliced
  along the top and bottom edges of the strip. It is now an outline with a
  negative offset: same 2px, same brand colour, drawn inside the box, so no
  overflow can cut it (WCAG 2.4.7). Outlines take no space, so nothing moves.

  **Tabs sat above their `actions`.** The strip was `items-stretch`, but a flex
  item with a definite cross size does not stretch — it goes to the start of the
  line. The `h-11` triggers therefore pinned themselves to the TOP of any line
  that an `actions` slot made taller, while `actions` centred itself: two rows
  visibly out of line. Horizontal strips now centre, so tabs and `actions` share
  one centre line. The vertical rail keeps stretching — that is what holds its
  `actions` at the bottom of the column.

  No token, no API and no DOM structure changed; both fixes are layout classes on
  parts the caller does not address directly.

- 4deffa9: Tabs: the horizontal list rule is 1px, matching Figma

  The full-width rule under a horizontal `TabsList` was `border-b-2`. Figma
  specifies 1px, so the 2px was drift. Only that rule changes: the active
  indicator stays 2px, the vertical rail stays `border-r-2`, and no colour moves.

  No contrast ratio changes, since nothing is recoloured. The selected state is
  still carried by the indicator and by `font-semibold`, neither of which this
  touches.

## 1.0.0

### Major Changes

- ff74716: feat(tokens): add overlay width + blur scale tokens and remove --shadow-xs

  Adds width tokens for overlay components (drawers, modals) from the Figma
  Size collection, Width group: --width-overlay-sm (420px), -md (640px),
  -lg (960px), -xl (1360px). These are fixed-width tokens exposed as w-overlay-*
  utilities (the --width-* namespace is not native to Tailwind).

  Adds a blur scale from the Figma Size collection, Blur group: --blur-sm (4px),
  -md (8px), -lg (16px), -xl (24px). As a native Tailwind v4 namespace, --blur-*
  auto-generates blur-* and backdrop-blur-* utilities (used by overlay backdrops).

  Also included in this export batch (existing surface, visuals may shift):

  - Value changes (both modes): --bg-elevation-highlight-layer-0 (grayblue-800→700),
    --bg-elevation-highlight-layer-1 (grayblue-700→600), --border-elevation-subtle-layer-2
    (grayblue-300→400), --border-elevation-subtle-layer-3 (grayblue-200→400),
    --border-elevation-default-layer-2 (grayblue-100→200), --border-elevation-default-layer-3
    (white-1000→200).
  - New alias: --icon-subtle.

  BREAKING: removes --shadow-xs (intentional Figma deletion, acknowledged via
  the tokens:breaking-approved label / token-diff gate). Any consumer of
  --shadow-xs must migrate to another shadow token.

- 35a4768: feat(badge): make `error` (red) the default tone instead of `brand`

  VISUAL CHANGE, not additive: every `<Badge>` rendered without a `tone` now
  paints red instead of brand blue. Pass `tone="brand"` to keep the old
  appearance. No new tone, no new token. Ruling: `Badge.tsx` `tone` JSDoc.

- ab04390: BREAKING: Button component rework — variant/priority/size API replaces previous
  variant-only model. Removed: size="lg", variant="secondary"/"ghost"/"focus".
  New axes: variant (default, destructive, ia, highlight) × priority (primary,
  secondary, tertiary) × size (sm, md). Gradient text for ia/highlight variants,
  asChild composition via Radix Slot, loading state with visible label + live
  region, RULE-04 enforcement (ia/highlight coerce primary→secondary), keyboard
  prevention on disabled asChild elements.
  Token changes: feedback error (red-500→600, red-200→300), tonic highlight
  (turquoise-500→600, 700→800, 100→200).
- 990810f: feat(chip): make EE a severity value, remove the tone axis, move all chips to 14px

  BREAKING: `tone="tonic"` is removed — use `severity="ee"`, one word, no other change.
  All chip labels move from 12px/500 to 14px/400, EE to 14px/500. Reversal trail and
  the transitional light-mode hover note: `Chip.rfc.md` §9.

- 7afdb00: feat(tokens)!: add --border-elevation-disabled, rename brand transparency-50 to -55, move the disabled family to the gray ramp

  Breaking for consumers: `--color-filigran-brand-primary-transparency-50` is
  removed (use `-55`), so the `*-filigran-brand-primary-transparency-50` utility
  classes no longer exist. `--bg-elevation-disabled-*` and
  `--text-default-disabled` change value in both modes.

  Button and IconButton secondary now border on brand @55% (default) and
  `--color-feedback-error-primary` (destructive, was `-secondary` at 1.97:1 dark
  against a 3:1 minimum); their disabled border and Chip's, on every severity,
  use the new `--border-elevation-disabled`. Primary disabled keeps its label on
  `--text-default-primary`. A disabled Tabs badge is no longer repainted.

- f3d7017: feat(package): ship documentation behind `@filigran/design-system/meta`

  BREAKING: `*Meta` objects are no longer exported from the root entry — import
  them from `@filigran/design-system/meta`. Runtime bundle 650.3 → 397.7 KB
  minified. Rationale: AGENTS.md § "Two entries: runtime vs documentation".

- 2e77492: Align both navbar rail levels on their own Figma component sets, across all five
  states.

  **Breaking — read this if you override the navbar's focus.** The rail rows no
  longer paint a focus ring. `ring-2`, `ring-offset-2`, `ring-offset-focus`,
  `ring-focus` and `focus-visible:z-10` are gone from `NavbarItem` and
  `NavbarSubmenuItem`, replaced by Figma's own indicator: a 2px solid border on all
  four sides in `--color-filigran-brand-primary`, painted inside the row's own box
  (component set `navbar menu item`, `State=Focus`, node 2837:13158). Those
  utilities also disappear from the compiled CSS surface unless another component
  still uses them, so a product that restyled the rail's ring — `--tw-ring-color`,
  a `ring-offset` override, or a rule keyed on `.ring-focus` — silently stops
  having any effect. Nothing throws; the focus indicator simply stops looking the
  way you customised it. Re-target the border instead.

  This is a permanent, assumed per-component exception to the library-wide ring
  pattern, declared with its Figma provenance in `NavbarItem.meta.ts`. Every other
  component keeps the ring.

  **Also breaking in effect, same mechanism.** The rows now reserve a 2px border on
  all four sides in every state (`border-2 border-transparent`) instead of on the
  left only, and `border-0` is gone from their base. Host CSS that assumed a
  border-less row, or that set `border-*` on these rows, meets a real border now.
  Row geometry itself is unchanged and guaranteed: border-box, content-box and
  widths are identical across rest, hover, focus and selected — only colour
  toggles.

  **Fixes, no action needed.** The hover background returns to
  `--bg-elevation-highlight`, the Figma value, reverting a token swap that had made
  the hover state measurably invisible (1.02:1 against the rail at two of its four
  gradient stops). Per-state icon tones now follow each level's own set, and the
  two levels deliberately differ: level 1 brightens its icon on hover, focus and
  selected; level 2 keeps its resting tone on hover and focus and turns brand when
  selected. Level 2's selected row loses its background tint and gains a 2px brand
  left accent with a brand label and icon — the set's actual spec, the inverse of
  what an instance reading had recorded.

  Products pick all of this up at their next pin bump; nothing in a product repo
  needs editing.

- a22b188: Paper's decorative border drops from 40% to 15% opacity, and its light base darkens one step.

  Seen on real product screens rather than on the docs page, the border shipped
  earlier today at 40% read as too visible. Sandy readjusted the Figma variables
  and this is the re-export: `Elevation/Border/Subtle-soft` now dilutes at **15%
  in both modes**, and the LIGHT base moves one step darker — `--gray-300`
  (#afb0b6) → `--gray-400` (#95969d) — so that lowering the alpha does not simply
  erase the edge in light. Dark keeps `--grayblue-400`.

  **Expect every panel edge to get quieter, in both themes.** Measured in a real
  browser across all four elevations, with the previous figures in brackets:

  | Elevation   | Dark            | Light           |
  | ----------- | --------------- | --------------- |
  | 0           | 1.09 (was 1.31) | 1.13 (was 1.27) |
  | 1 (default) | 1.09 (was 1.31) | 1.15 (was 1.33) |
  | 2           | 1.09 (was 1.28) | 1.13 (was 1.28) |
  | 3           | 1.05 (was 1.15) | 1.12 (was 1.22) |

  The two modes no longer converge on one figure and are not meant to: matching
  the products' MUI `divider` at 1.32:1 was the previous pass's target, and it is
  retired in favour of "present but quiet", judged per mode on screen. Dark also
  flattens across elevations 0–2, because a 15% dilution of a single base over
  three close surfaces cannot separate them the way 40% did. The border is
  decorative and non-gating (WCAG 1.4.11 Note 1), so none of these is a threshold.

  **Breaking for anyone theming the border.** The naming convention embeds the
  percentage, so the per-layer variants are renamed with it:
  `--border-elevation-subtle-soft-layer-N-transparency-40` →
  `--border-elevation-subtle-soft-layer-N-transparency-15`. If you declared the
  old name to recolour a Paper's border, it now resolves to nothing and the border
  falls back to the library value — rename the declaration. The plain
  `--border-elevation-subtle-soft` alias and the per-layer bases are unchanged in
  name, so a theme that only declares those needs no edit. The rename is
  mechanical rather than a second decision, but it is a real break and is called
  out here for that reason.

- c86dd08: `Paper` gains a `padding` scale and a `title`/`action` header, and two props stop leaking to the DOM.

  **Read this first — two behaviour changes are NOT opt-in.** `title` and `action`
  become Paper's own props, so they are no longer forwarded to the rendered
  element. If you were relying on `<Paper title="…">` producing a native browser
  tooltip over the whole panel, that tooltip is gone: the string now renders as a
  heading row above the surface. `action` never worked at all — it reached the DOM
  as `action="[object Object]"` — but if any code depended on that attribute
  existing, it no longer does. Everything else below is additive, and a `<Paper>`
  that passes none of the new props renders the exact same single element, with
  the same classes, as before.

  **`padding={0 | 8 | 16 | 24 | 32}`** — pixels, on an 8px step, default `24`
  (the annotated Figma value, so omitting it changes nothing). This replaces the
  previous guidance of overriding `p-*` through `className`, which was measurably
  unsafe: Tailwind emits a utility only if a scanned source names it, so which
  padding classes existed in the published `dist/index.css` depended on which
  paddings _other_ components happened to use. `p-8` was absent — meaning
  `className="p-8"` compiled to nothing and rendered at 24px, silently, with no
  build or runtime error. All five classes are now safelisted in the package
  stylesheet, and a real Tailwind compile asserts they are present. `className`
  still wins over the prop, so an off-scale `p-3` keeps working; only these five
  carry the emission guarantee.

  **`title` / `action`** — an optional header row rendered _above_ the surface,
  outside its border and padding, which is where products already put it (a
  sibling heading before the panel, on 281 measured sites). Either slot works
  alone. The row is a quiet 12px/400 label in `--text-default-secondary`, in a
  fixed 24px row, read from Figma node `7045:38746`; a long title truncates rather
  than growing the row. `as`, `ref`, `className` and rest props stay on the surface, so
  `<Paper as="a" href="…" title="…">` is still a clickable card whose surface is
  the link. **No heading level is applied**: a string renders in a plain `<div>`
  with the library's title typography, because inventing an `<h2>` is a WCAG
  1.3.1 heading-order regression rather than a neutral default — pass the element
  (`title={<h2>…</h2>}`) when you need the semantics.

  If you are on a pre-release build from 2026-08-14, the row changed again: it
  first shipped at 14px in the primary text colour with **no declared weight**, so
  it inherited one from the host — a Paper inside anything bold rendered a bold
  header. Both are fixed by the node above and by using the composite
  `content-compact` utility, which is the only class form that declares a weight.

  **Unknown props now warn in development.** React forwards any unrecognised
  all-lowercase prop straight to the DOM instead of rejecting it, which is how
  `padding="16"`, a native `title` tooltip and `action="[object Object]"` all
  reached a real build. Paper now emits a `console.warn` (never throws, and
  silent in production — though not byte-stripped from it, see below) both for
  MUI-`Paper` props it does not accept — `sx`,
  `component`, `variant`, `square`, `classes` — and, structurally, for any prop
  whose value cannot render meaningfully as an attribute. Expect new warnings on
  a migration that was previously silent; each names the replacement.

  **Host theming is documented, not changed.** No new token, no colour prop:
  Paper paints the shared `--bg-elevation-default` alias, so a product recolours
  it exactly as it recolours the Navbar and the Header. What is new is the written
  contract, now measured in a real browser and executed in CI. Declaring
  `--bg-elevation-default-layer-N` on `:root` — or on any ancestor — repaints
  elevation N; declaring `--bg-elevation-default` itself never works, at any
  scope, because the `.layer-N` class re-declares that alias on the Paper element.
  For OpenCTI/OpenAEV-style themes that is one mapping line per elevation, and
  `theme_paper` belongs on layer 1: mapping only `theme_background` (layer 0)
  themes the page, Navbar and Header while leaving every default-elevation Paper
  on the Filigran colour — the exact mismatch the product pilot measured. Full
  recipe in `Paper.rfc.md` §6.5 and on the docs page's "Product theming" tab.

  **Also in this round, outside the package:** the product conformity template
  (`check-fds-conformity.mjs`) gains a `libComponentUsage` check that verifies
  component-adoption sites structurally rather than with a regex over multiline
  JSX — it catches a hardcoded padding on a library `Paper`, and an import that
  has fallen back to `@mui/material`. Products pick up the new check on their next
  `pnpm generate:fds-migration`; a product that declares nothing is unaffected.

  **The decorative border changes in both modes, and now comes from its own
  token.** It was a 10% dilution of the mode-aware `--border-elevation-subtle`,
  which resolved to 1.02:1 against its surface in light — effectively invisible —
  while dark was correct only by coincidence. The design gained a dedicated
  variable, `Elevation/Border/Subtle-soft`, exported as
  `--border-elevation-subtle-soft` with per-layer variants re-declared inside each
  `.layer-N` block, so the border is layer-aware. **A later change in the same
  release lowered these values** — see the border-opacity changeset; the figures
  that ship are dark 1.09 / 1.09 / 1.09 / 1.05 and light 1.13 / 1.15 / 1.13 / 1.12.

  Expect a **visible change in light mode** — panels that had no perceptible edge
  now have one — and a smaller one in dark. The border is decorative and
  non-gating (WCAG 1.4.11 Note 1), so these ratios are design intent rather than
  thresholds.

  **The border is themeable.** Declaring `--border-elevation-subtle-soft`, or its
  per-layer variants, recolours it. It does **not** derive from the surface:
  overriding `--bg-elevation-default-layer-N` moves the surface and leaves the
  border. If you theme surfaces, map the border token too — both behaviours are
  pinned by real-browser tests.

  **Token renames — 17 of them, and they are breaking.** Every alpha variant now
  states its own opacity: `…-transparency` becomes `…-transparency-{percent}`
  (brand-primary `-10`, ia-secondary `-10`, the five feedback secondaries and
  neutral-secondary `-30`, the nine entity colours `-20`). Values are unchanged —
  proven by computing each token's resolved colour before and after, 34/34
  identical across both modes — so **nothing should move visually**. If anything
  does, it is a missed call site, not a colour change. All 154 references in this
  library were updated in the same change; a product on an older bump will need the
  same pass (see the PR body's inventory).

  **Nine token values move on purpose**: the four `--bg-elevation-disabled-layer-*`
  steps in dark, and in light `--border-elevation-subtle-layer-1`,
  `--color-filigran-tonic-secondary`, `--color-feedback-alert-tertiary`,
  `--color-feedback-warning-primary` and `--color-feedback-warning-tertiary`. The
  tonic change makes the EE chip's hover LIVE in light mode, where it was
  previously identical to its resting state.

  **A documentation correction that affects every dev warning in the library, not
  just Paper's.** `AGENTS.md` and several component comments claimed these
  `NODE_ENV`-gated `console.warn` guards were stripped from production builds by
  the consuming bundler. Measured in both directions, that is half true: nothing
  warns in a production build, but the bundle is **byte-identical** with and without
  `define: {"process.env.NODE_ENV": "production"}`, because the deliberate leading
  `typeof process === "undefined"` test the guards need is not constant-foldable.
  The cost is small — 0.604 KB minified / 0.267 KB gzip across the whole library,
  0.14 % — and no code changed; the wording did, so the claim stops being wrong.

- d7826f4: Tabs: change the default `activationMode` from `"automatic"` to `"manual"`,
  aligning with this design system's actual shipped behavior in MUI and
  OpenCTI (process/TABS-BADGE-COLOR-API-PROPOSAL.md §10).

  Previously `Tabs` re-exported `@radix-ui/react-tabs`'s `Root` directly, so
  `activationMode` silently inherited Radix's own default (`"automatic"`):
  arrow-key focus alone immediately activated a tab. `Tabs` is now a thin
  wrapper that defaults `activationMode` to `"manual"` — arrow keys move
  focus between tabs without activating them; the focused tab activates on
  Enter/Space (or click), same as before for pointer users.

  **This is a breaking behavior change for any consumer that relies on the
  previous implicit automatic-activation default without passing
  `activationMode` explicitly.** No prop was removed or renamed — pass
  `activationMode="automatic"` to opt back into the previous behavior.

  Classified `major` per `process/PLAYBOOK.md`'s bump policy (a change to a
  component's default behavior), independently of the `theme.css` token-diff
  gate (no design token changed, so no `tokens:breaking-approved` label
  applies here — see the RFC addendum for the full rationale).

### Minor Changes

- 8798cbb: Add `Badge` — the notification marker that was missing from the library.

  A count, or a dot when the exact number does not matter, attached to another
  element. It replaces MUI `Badge`, which both products were compensating for by
  hand-styling `sx={{ '& .MuiBadge-badge': { … } }}` across 27 render sites, at
  three different sizes, once with a hardcoded `red`/`white` pair.

  The API is the one arbitrated in `process/BADGE-API-PROPOSAL.md` §8. Two things
  are worth knowing before adopting it. The dot is **derived** from an absent
  `content` and can also be **forced** while a count exists ("something is
  waiting, do not show how much") — in both cases the value is still announced,
  so the accessible name never degrades with the visual. And a dot with nothing
  to announce is a **type error**: the no-`content` form requires
  `accessibleText`, because a bare coloured dot would carry its meaning by colour
  alone. `accessibleText={false}` is the explicit opt-out for a consumer who has
  already named the anchor.

  `max` has **no default**, deliberately: an implicit cap would silently rewrite
  what an existing consumer already renders. Zero counts hide by default, with
  `showZero` as the veto — 11 of the 15 counter sites in the inventory already
  depend on that behaviour.

  Non-breaking: a new component and a new export, nothing existing changes.

  One divergence from the Figma grid is shipped on purpose and declared in
  `Badge.figma.json`: the `error` and `neutral` **dots** use the `-primary` step
  of their families rather than the `-secondary` one the grid binds. A counter's
  `-secondary` fill is chosen so its text is legible on it; a dot has no text, so
  the fill itself must be perceivable against the page, and `-secondary` is not —
  measured 1.97–2.81 for `error` and 2.63–3.25 for `neutral` against WCAG
  1.4.11's 3:1 floor, in both modes. `-primary` clears it everywhere and changes
  no hue.

- 150c7b2: feat(button-group): add the segmented control from Figma node 2785:16736

  A run of icon-only buttons sharing one selected value — the component behind
  every "cards / lines / graph" view switcher in the products. Compound:
  `ButtonGroup` owns the selection and the roving focus, `ButtonGroupItem` is one
  segment.

  Sourced from the node at the root: 30 symbols = Position (Start/Middle/End) ×
  State (Default/Hover/Active/Focus/Disabled) × Size (md 36px / sm 24px). Every
  symbol is square, so the component is icon-only and ships no label slot.

  Two non-obvious implementation decisions, both recorded in the RFC §9:

  - **Position is not a prop.** Figma models Start/Middle/End as a variant axis,
    but products render items conditionally, so a hand-authored position goes
    stale the moment a condition flips. The container applies the corner rounding
    through `:first-child`/`:last-child`. It uses child selectors rather than
    `overflow-hidden` on a rounded container because the focus ring is drawn
    outside the button, and a clipping ancestor would amputate it on the first and
    last items only.
  - **Roving focus reads the DOM, not `React.Children`.** Products wrap almost
    every item in a Tooltip, so `React.Children` sees the wrapper. The container
    queries its own subtree for `[role="radio"]` instead.

  Accessibility: `role="radiogroup"` + `role="radio"`/`aria-checked`, one tab stop
  entered at the selected item, arrow keys move and select with wrapping,
  Home/End jump to the ends, disabled items are skipped and are never the entry
  point. `aria-label` is required on the item, which renders no text. All four
  contrast pairs are glyph/UI-component pairs at 3:1 — the component has no text.

  Scope is deliberately narrow (RFC §7): single-select only (`exclusive` was true
  in 36 of 36 measured product usages), no labels, no vertical orientation, and
  not the split-button pattern MUI also calls ButtonGroup.

- 2e6a3bb: Add `Card` — the composed surface the two products have been rebuilding by hand.

  Card is built ON `Paper` and declares no surface, typography or spacing of its
  own: the Figma root is a Paper instance binding Paper's own base, and every
  text goes through `Text`. Parts are `CardHeader`, `CardTitle`, `CardSubtitle`,
  `CardContent`, `CardFooter` and `CardMetaBar` — all optional, all combinable, no
  order encoded — plus `Thumbnail`, the 48px leading frame the set draws, itself a
  `Paper` holding a 24px glyph and declaring no colour of its own. Appearance is
  root props: `elevation` and `padding` pass through to Paper, plus
  `href`/`onClick`, `selected`, `disabled`. A card has no intrinsic width: it
  takes the one its track gives it, narrow or wide.

  The part worth reading before adopting it is the clickable card. Give the root
  `href` and the anchor is rendered on the **title**, then stretched over the
  surface with a pseudo-element. The card is therefore ONE control whose
  accessible name is its title, and the buttons, chips and checkboxes inside it
  stay separate, reachable controls — one tab stop for the card plus one per real
  control, no nested interactive elements, and no `preventDefault()`
  compensation. It replaces MUI's `CardActionArea`, which renders a `<button>`
  around `<div>`s and is milestoned for removal upstream; both products currently
  work around it by hand at 14 sites. Hover is driven by `:has()` on that anchor
  rather than the root's own `:hover`, so pointing at an inner control drops the
  card highlight instead of promising a click that control will intercept.

  The documentation page is the deliverable, and it answers two questions in two
  sections: which type fits this site — one copy-paste example per variant of the
  definition set, under the set's own names (Simple, Entity, Sharing, Number,
  Media) — and, when none fits, how to compose your own. A test asserts both the
  names and the nodes they cite, so renaming a variant in the design file fails
  the build rather than quietly stranding the page.

  Divergences from the node ship declared, never absorbed. The **focus ring** is
  the library's standard pattern: the Click matrix draws Default, Hover and
  Disabled and no focus state, while 30 measured card-link sites need one. The
  **status dot** renders 8px where the node's Badge instance is 20: the library
  component is authoritative and nothing is resized, and the gap reaches only the
  title column beside it. And the **clamped content** renders 62px against the node's 56: reaching 56
  exactly requires trimming both text-box edges, which puts the bottom edge on
  the last line's baseline and lets `overflow: hidden` shave its descenders, so
  only the start is trimmed and the 6px is accepted. The node stays at 56. A
  Chromium test holds the descenders, since jsdom resolves no text-box-trim.

  The media card needs no per-side padding on Paper: the band bleeds to the
  Paper's edges at the node's fixed 150, and an inner content box carries the
  16/24 the node draws. It is a plain container, so Paper keeps its single
  uniform padding step.

  Non-breaking: a new component and a new export, nothing existing changes.

- 4e2b0bf: feat(checkbox,radio): add Checkbox, Radio and RadioGroup components

  New `Checkbox`, `Radio` and `RadioGroup` components, built on
  `@radix-ui/react-checkbox` and `@radix-ui/react-radio-group` (RFCs approved
  by Sandy, lead design; author @fimow). They are the two highest-volume
  form controls left un-migrated: a measured **113 MUI `Checkbox` usages
  across 76 files** and **18 `Radio` / 7 `RadioGroup` usages across 10 files**
  in OpenCTI, OpenAEV and OpenGRC (re-measured 2026-08-04, independent PR
  review — corrects a transcription error in the original openaev sub-count;
  see `Checkbox.rfc.md`/`Radio.rfc.md` gap tables D13/D20). Both expose
  `forwardRef` on the underlying
  `<button>`, and `RadioGroup` also forwards to its group element.

  Each control ships as a full form row: an optional `label` natively
  associated through `<label htmlFor>`, and an optional `description` wired via
  `aria-describedby` (a caller-supplied `aria-describedby` is merged, not
  replaced). `Checkbox` implements the three values Radix provides —
  unchecked, checked and `indeterminate`, exposed as `aria-checked="mixed"` —
  because the Figma documentation draws all three. `RadioGroup` is a single
  tab stop with roving tabindex, and arrow keys move focus and select
  together, per the ARIA APG radio group pattern.

  **Migration note (`Checkbox.rfc.md` §4.4.1/§4.4.2, `Radio.rfc.md` §4.4).**
  The change handler signature differs from MUI: `onChange(event, checked)`
  becomes `onCheckedChange(checked: boolean)`, so **65 call sites** reading
  `event.target.checked` need a one-line edit each; the RFCs carry the full
  before/after table. `onCheckedChange` is deliberately **optional** and
  clicks are allowed to bubble, which is what the **12 purely presentational
  checkboxes inside MUI `Autocomplete` options** rely on — they pass `checked`
  with no handler and let the surrounding row own the click. Both guarantees
  are pinned by tests rather than left implicit.

  Visual behaviour follows the Figma documentation as read, in both modes. The
  box and the circle are **transparent at rest** and inherit their container's
  background — an arbitrated design decision, not an omission: the
  `--bg-input-default` fill appears only on hover and focus, and at rest the
  1px `--border-elevation-default` border carries the perception. Disabled is
  rendered by **color substitution**, never by raw opacity, consistent with
  the rest of the library. The focus ring is the library's standard ring
  rather than the Figma-specific treatment — one ring across the whole
  library, tested once; the deviation is declared explicitly in
  `Checkbox.figma.json` / `Radio.figma.json` with its WCAG rationale.

  `wcagStatus: "pass"`, no allow-list entry. Every element that carries the
  component or its state clears its threshold in both modes: box and circle
  border at rest 3.14:1 / 3.72:1, check and dash glyph and selected dot
  10.30:1 / 11.22:1, focus ring 10.30:1 / 11.22:1, label 17.38:1 / 15.72:1,
  description 8.99:1 / 7.89:1. The hover fill and hover halo sit below 3:1 by
  construction and are declared as supplemental treatments per Understanding
  SC 1.4.11 "Hover states" — neither is needed to identify the control or its
  value. All pairs are declared against the library's standard reference
  surface and every number is machine-generated by `pnpm check:contrast`.

  Deliberately out of scope for this version, each with a measured-usage
  reason (`Checkbox.rfc.md` §7, `Radio.rfc.md` §7): `size` and `color` axes,
  `disableRipple` and `edge` (MUI layout artefacts with no equivalent here),
  custom `icon`/`checkedIcon` overrides, an `error` prop — errors are carried
  by the surrounding form field, never by the control itself — and the
  horizontal `RadioGroup` orientation, which design has drawn but which is not
  yet readable through the Figma API and so is not implemented rather than
  invented. Logged to `process/AI-BACKLOG.md`.

- 87f3cb2: feat(chip): add Chip component

  New `Chip` component: a compact, single-line data-display token for
  status/severity, tags, entity markers, active filters, and multi-select
  values (`Chip.rfc.md` §1/§2, RFC approved by Sandy, lead design; author
  @fimow). No Radix primitive and no new runtime dependency — renders a
  decorative `<span>` by default, or a `<button>` when `onClick` is set; the
  optional trailing delete control is always a **sibling** FDS `<IconButton>`
  instance (never nested inside the clickable body), giving a
  clickable+deletable chip two independent tab stops. `forwardRef` is exposed
  on the actual rendered element.

  Two color axes, mutually exclusive (`entity` takes precedence when both are
  set): `severity` (`neutral`/`info`/`low`/`medium`/`high`/`critical`) and
  `entity` (the 9 `--color-entities-*` tokens: `analyses`/`cases`/`events`/
  `observations`/`all-threats`/`arsenal`/`techniques`/`victimology`/`location`).
  Optional decorative `startIcon` (`aria-hidden`, the label always carries the
  meaning — WCAG 1.4.1). Hover/focus/active styling applies only to the
  interactive `<button>` rendering, never the decorative `<span>` — confirmed
  directly against the Figma usage sample. Hover is implemented as a literal
  second `before:bg-<same-token>` layer stacked over the rest fill (real
  Porter-Duff compositing), never a hardcoded alpha value. Focus ring reuses
  the established `ring-focus`/`ring-offset-focus` convention (same as
  Tabs/SearchField/Select). Truncated labels keep a native `title` and are
  wrapped in a `Tooltip`, exposed on hover for every chip and additionally on
  keyboard focus when the body is the interactive `<button>` rendering (a
  read-only `<span>` is never focusable).

  Ships as `status: "beta"` with `wcagStatus: "fail"` — 2 real non-text-contrast
  pairs (WCAG 1.4.11) fail against the current Figma color tokens, in light
  mode only, on the **decorative** `startIcon` (the label text carries 100% of
  the chip's meaning; all 15 label/fill pairs pass 4.5:1 in both modes and both
  rest and hover). A 3rd such failure (icon-low) was independently fixed as a
  side effect of PR #62's WCAG token remediation, merged after this changeset
  was first written; see `Chip.rfc.md` §5.4 and `scripts/wcag-allowlist.json`.
  Allow-listed in `scripts/wcag-allowlist.json` (approved by
  Sandy, lead design, expires 2026-08-31) pending the same global color-token
  remediation pass already tracked for Switch/Input/Button. `--icon-neutral`
  (Figma's binding for the neutral-severity icon) does not exist in
  `theme.css` — a confirmed design gap, not invented: ships with the
  `--text-default-secondary` token as a documented interim fallback, logged to
  `process/AI-BACKLOG.md`. See `Chip.meta.ts` accessibility notes and
  `Chip.rfc.md` §3.4/§3.5/§5.4 for the full analysis (47 declared
  `contrastPairs`, every number machine-generated via `pnpm check:contrast`).

  Deliberately out of scope (`Chip.rfc.md` §7, each with a measured-usage
  reason): the `outlined` variant, additional sizes, an `avatar` slot, a
  leading `dot` indicator, a persistent `selected`/`active` prop, and a custom
  `deleteIcon` override. A notification-counter `Badge` (`badgeContent`/dot
  overlay) is a conceptually different, separate future component — this also
  closes the `process/AI-BACKLOG.md` "Badge / Chip" item, whose remaining
  standalone-component scope is exactly what this Chip component ships.

- 48cf501: feat(combobox): add the Combobox component — one field, `multiple` as a prop

  Filterable selection: the user narrows the list by typing directly in the field,
  and `multiple` is a prop rather than a second component. It covers MUI
  `Autocomplete` and the `<Select multiple>` sites Radix Select structurally cannot
  serve — 93 authored Autocomplete elements and 12 enumerated multi-select sites
  across OpenCTI and OpenAEV, where `readOnly` is 0 of 93. That last number is why
  the planned separate `MultiSelect` was abandoned rather than built: typing is
  universal, so a closed non-editable multi list would have served 12 sites out of
  about 170.

  The accessibility engine is in-house (`useCombobox`), decided on a browser-driven
  cmdk prototype and not on taste: cmdk hardcodes `aria-expanded` to `true`, makes
  `aria-selected` track the highlight instead of the selection, and discards an
  explicit `aria-selected` prop — inverted multi-select semantics for screen
  readers. Three named non-regression tests lock exactly those three attributes.
  `@radix-ui/react-popover` supplies positioning, dismissal and portalling and
  nothing else, and its own `role="dialog"` is removed so the listbox alone carries
  the semantics. `aria-autocomplete="list"` is the default the APG "Editable
  Combobox With List Autocomplete" pattern specifies, and stays overridable.

  Composition over re-implementation: the field holds library `Chip` instances
  (24px, wrapping onto as many rows as needed) and the options carry the library
  `Checkbox`. Both neighbours gained the minimum that composition required —
  `Chip.deleteTabIndex` so the chip row is a single Tab stop navigated with arrows,
  and `Checkbox.presentational` because a real control nested in a `role="option"`
  is an axe `nested-interactive` failure that neither `aria-hidden` nor a negative
  tabindex clears. Filtering always belongs to the consumer: the default is a plain
  substring match, `filterOptions` replaces it wholesale, and the component owns no
  timer.

  Measured bundle impact, per this repo's measure-never-estimate policy: runtime
  398.7/125.1 KB → 413.8/129.0 KB (+15.1 minified / +3.9 gzip, essentially the
  Popover module arriving — its fifteen transitive dependencies were already in the
  tree via `react-select`), documentation entry 656.6/209.4 KB → 680.3/214.8 KB
  (meta prose, examples, contrast table, demo). Both ceilings re-set on those
  numbers.

  `Select` gains a fix found on the way: node 6899:15536 binds the placeholder and
  the value to different tokens, and `Select` had both on the same one, so an empty
  Select read exactly like a filled one.

- ab65f89: feat(dialog): add Dialog component wrapping @radix-ui/react-dialog

  Exports: Dialog, DialogTrigger, DialogContent, DialogTitle,
  DialogDescription, DialogBody, DialogFooter, DialogClose. Compound
  component pattern — consumers compose parts freely, using the library's
  own Button/Text/IconButton for footer actions and content. Sizes
  sm/md/lg (default md) via the w-overlay-sm/md/lg fixed-width utilities
  (viewport-clamped so content never overflows narrow screens). Built-in
  corner close icon (IconButton priority="tertiary", opt-out via
  hideCloseButton), internal scroll (DialogBody) with a fixed
  header/footer, 150ms opacity-only open/close animation with
  motion-reduce support. Accessible by default via Radix (role=dialog,
  aria-modal, aria-labelledby/aria-describedby, focus trap,
  Escape/backdrop dismiss, focus return to trigger) plus a dev-only
  console.warn when DialogContent is missing a DialogTitle.

- f14b361: Add `FileSelect` — the file-picker field both products were rebuilding by hand
  around a bare `<input type="file">` with an MUI `Button` and ad-hoc chips.

  It composes the existing `Button` trigger, `IconButton` clear, and `Chip` per
  file (removable only in `multiple` mode), keeps the native `<input type="file">`
  for accessibility (it stays the labelled, keyboard-reachable control that opens
  the file dialog), and surfaces `accept`/size limits through the same helper row
  that carries the error. Selection is read through `value`/`onValueChange`
  (form-library-agnostic), not native form submission. The API is the one
  arbitrated in `FileSelect.rfc.md` §9.

  Non-breaking: a new component and a new export, nothing existing changes.

- 486cec9: feat(header): add Header component

  New `Header` component: the horizontal bar at the top of an application
  screen, above the page content and beside the left navigation rail
  (`Header.rfc.md` §1, RFC authored and arbitrated in this circuit). No Radix
  primitive and no new runtime dependency — a top bar is a structure, not a
  behaviour, and the one adjacent Radix part (`Toolbar`) carries the roving
  tabindex a top bar must not have. Renders a real `<header>`, so the `banner`
  landmark every product depends on today is preserved. `forwardRef` on both
  parts.

  Two components, three props: `Header` (`as`) and `HeaderGroup` (`grow`).
  The bar pins Figma's geometry — 68px (`--spacing-17`, the same token the
  `Navbar` header band uses), 16px padding, a 1px `--border-elevation-subtle`
  hairline, and the shared `bg-gradient-default` surface at 94% opacity painted
  by a `::before` layer. It provides no search field, no account menu, no
  notification bell and no logo: the cross-product audit found nothing in that
  group shared in a way a fixed API could capture, and everything in the
  structural group duplicated identically three times over.

  No positioning, no colour prop, and both decisions are proven rather than
  asserted. Real-browser tests in the Playwright harness reproduce
  OpenCTI/OpenAEV's pinned bar with a left offset and normal flow; measure the
  94% layer and the 4px backdrop blur; establish the product-theming recipe; and prove
  the account-menu composition contract (`MenuTrigger asChild`, not a bare
  `IconButton`). That
  last measurement corrected the RFC's own first reading: `--gradient-default`
  is declared in the `:root` block, so per css-variables-1 §3 its stops resolve
  on the declaring element — overriding the stops on `<body>` or a wrapper does
  **not** repaint, overriding them at `:root` does, and a subtree override must
  re-declare `--gradient-default` itself. This is `bg-gradient-default`'s
  behaviour, identical on `Navbar`, and OpenCTI already themes at `:root`, so no
  use case is lost. Both recipes are documented in `Header.rfc.md` §6.3.

  Two adoption traps are documented normatively because both pilots hit them:
  the bar ships `w-full` and neither `ml-*` nor `inset-*` conflicts with it, so
  `fixed inset-x-0 top-0 ml-45` overflows by exactly the offset (measured 180px)
  — pin both edges with `left-45 right-0 w-auto` instead; and OpenCTI/OpenAEV
  both declare a collapsed rail of `55` while the library `Navbar` is `48`, a
  7px gap that will be blamed on the Header (`Header.rfc.md` §6.4).

  The `banner` landmark is a usage rule, not a note (`Header.rfc.md` §6.1): one
  per page, and a section/panel/card/dialog header must never become one. The
  library's own documentation page broke that rule first — `axe` returned
  `landmark-no-duplicate-banner` on the page documenting it — and it is fixed
  with the HTML5 mechanism (each demo wrapped in a labelled `<section>`), not a
  suppression.

  Figma `2823:1330` read at ROOT by two independent means in both modes, after
  the 2026-08-05 design edit; the background opacity is 94% and the backdrop
  blur is gone, confirmed on the rendered example where a bright chart bar
  passing under the bar is covered, not smeared. Five gaps are declared in
  `Header.figma.json` rather than invented around, including the unbound 159.51°
  gradient angle (closed by pixel measurement as a design-file artefact) and the
  unbound 94% opacity (no token created, per arbitration — a `color-mix()` stop
  would have been invisible to `check-contrast.ts`).

  Bundle budget raised 635 → 650 KB minified / 204 → 209 KB gzip, with the cause
  split by measurement and documented inline in `scripts/check-bundle-size.ts`:
  the component costs +0.7 KB minified, `Header.meta.ts` costs +14.3 KB, and the
  meta is not an outlier (26.1 KB of source against Chip's 25.2 and Slider's
  25.0). The raise is not imputable to this component — the margin left on `main`
  was 1.0 KB, so the next documented component would have hit the same wall. A
  new HIGH-PRIORITY `process/AI-BACKLOG.md` entry records this as the fourth
  occurrence and the first that blocks, with the proposal to give the metas their
  own entry point.

- bbc908f: Add IconButton component (Variant×Priority×Size API, IA gradient support, accessible)
- e03da7c: feat(input): add Input component

  New `Input` component: base single-line text field for forms. Supports the
  native `type` values used across the audited products (text, email,
  password, number, etc.), a `label` with optional `required` marker and
  `infoTooltip` slot, `helperText`, `error` (string, replaces helperText when
  set) and `success` states, a live character counter via `maxLength`, a
  decorative `startIcon`, and an `endIcon` slot accepting either a decorative
  icon or an interactive `IconButton` (e.g. show/hide password, copy — icon +
  `aria-label` only, no visible-text variant yet). State icons (error/success)
  take precedence over a custom `endIcon` (RULE-06: a field is never both at
  once visually). `forwardRef<HTMLInputElement>` for compatibility with
  Formik+MUI and react-hook-form alike; `error` is a plain string to keep the
  `onChange`/`ref` contract identical to a native `<input>`.

  Known limitation: the success-icon color (Figma's own literal
  `--color-feedback-success-primary`) fails WCAG 1.4.11 (2.42:1, needs 3:1)
  against the input background in light mode only — documented in
  `Input.meta.ts`'s accessibility notes and `process/AI-BACKLOG.md`, shipped
  under a time-boxed entry in `scripts/wcag-allowlist.json` (expires
  2026-08-31, same mechanism already used for Button's own known gap).

- 9cd4271: feat(menu): add Menu component wrapping @radix-ui/react-dropdown-menu

  Exports: Menu, MenuTrigger, MenuContent, MenuItem, MenuGroup, MenuLabel,
  MenuSeparator. Compound component pattern — every sub-part that renders a
  DOM node forwards a ref (`forwardRef<ElementRef, ComponentPropsWithoutRef>`),
  matching the Dialog/Tabs/Select convention; the root is the documented
  exception, since Radix's own Root renders no DOM node. Every exported part
  is a real wrapped component, never a raw re-export of the primitive (PR #70
  learning): a raw alias opts the part out of every component-level policy,
  including its own dev-time contract warnings.

  Closes the "the library has no action-menu primitive" product report. It
  unblocks the OpenAEV tenant switcher, the migration of the products' MUI
  menus, and the future MultiSelect.

  Covers the action-menu and single-selection patterns: 78 of the 97 menu
  sites measured across OpenCTI and OpenAEV (80%) are the kebab/action shape
  this component replaces. `MenuTrigger` is `asChild`-only, so the opener
  stays whatever library component the product already uses (IconButton in
  roughly 80% of those sites). `MenuItem` supports `asChild` around a real
  anchor, which preserves ⌘-click, middle-click and "open in a new tab" —
  the behaviour an `onSelect` + router call silently destroys, across the 20
  measured product call sites that navigate.

  `selected` renders a visible check indicator plus `aria-current="true"`.
  This is a deliberate, arbitrated deviation from the current Figma, which
  distinguishes the selected row from the hovered one by a per-row rule that
  the authoritative liaison nodes no longer draw — leaving the two states
  pixel-identical. The design owes a real Selected state; the indicator is
  what makes the state perceivable in the meantime (WCAG 1.4.1).

  Two behaviours worth knowing before migrating a MUI menu, both measured
  and covered by tests rather than discovered later: arrow-key navigation
  wraps (`loop` defaults to `true`, inverting Radix's own default, so the
  wrapping MUI users already have is preserved), and `Tab` does NOT close the
  menu — Radix traps it, so Escape is the only keyboard dismissal, whereas
  MUI's Menu closes on Tab.

  Not covered in v1, deliberately, with the affected sites staying on MUI:
  sub-menus (2 sites), checkbox items (8), radio items (0), position-anchored
  context menus (1) and a `dense` density. Select-style options (577 of the
  876 measured `MenuItem` sites — two thirds) are not menu items at all and
  belong to Select/MultiSelect. See Menu.rfc.md §7 for the full accounting.

  ProductSwitcher, which today embeds its own unexported menu, is NOT
  refactored here: it is a visible change to a shipped component and gets its
  own single-subject follow-up PR.

- 7ea6c51: feat(navbar): add Navbar, NavbarItem, NavbarSubmenu, ProductSwitcher

  Exports: Navbar, NavbarSeparator (navbar/), NavbarItem (navbar-item/),
  NavbarSubmenu, NavbarSubmenuItem (navbar-submenu/), ProductSwitcher
  (product-switcher/).

  - **Navbar**: collapsible sidebar container (controlled/uncontrolled
    `collapsed`/`onCollapsedChange`), header/content/footer slots, built-in
    footer collapse toggle, `prefers-reduced-motion`-aware width transition.
    No Radix primitive — plain composition root exposing `NavbarContext` to
    descendants.
  - **NavbarItem**: single interactive row (plain link, NavbarSubmenu
    trigger, or Navbar's own footer toggle) — `asChild`/Slot for
    router-agnostic navigation, `aria-current="page"` for the active state,
    `showIcon` prop mirroring opencti's submenu-icon-visibility preference
    (forced back on while collapsed so the row is never left empty).
  - **NavbarSubmenu**/**NavbarSubmenuItem**: hybrid disclosure — inline
    accordion (`@radix-ui/react-accordion`, `type="multiple"`) while the
    Navbar is expanded, `role="menu"` flyout (`@radix-ui/react-dropdown-menu`,
    opens on click/focus/hover) while collapsed. Escape closes the flyout and
    returns focus to the trigger; collapsing while a submenu has focus
    returns focus to the parent item.
  - **ProductSwitcher**: static links menu to sibling Filigran products
    (`@radix-ui/react-dropdown-menu`) — each option is independently external
    (`href`, opens in a new tab with a visible external-link icon and a
    visually-hidden "(opens in a new tab)" accessible-name suffix — a real
    WCAG gap fix vs. today's opencti, which has no such announcement) or
    internal (`to`, same-tab navigation, no icon/suffix); the two are
    mutually exclusive per option.

  New dependencies: `@radix-ui/react-accordion`, `@radix-ui/react-dropdown-menu`.
  Bundle-size budget raised 220→330 KB minified / 70→110 KB gzip on this
  branch alone for the two new Radix primitive families, then to the
  currently-enforced 340 KB minified / 112 KB gzip (`scripts/check-bundle-size.ts`)
  once this branch merged `origin/main`'s PR #44 (Text component + the unified
  `cn.ts` classGroup config), which had independently bumped the same shared
  budget — both increases are documented inline as deliberate, reviewed
  changes, not a tree-shaking regression (Lucide icon module count unaffected).

  **Post-review fixes (same PR, before merge):**
  - `NavbarContext.ts` now carries its own `"use client"` directive — the
    module calls `React.createContext()` at module scope, which crashes
    (`createContext only works in Client Components`) the instant any Server
    Component's import graph reaches it (e.g. a docs/consumer app reading
    component metadata next to a JSX-rendering import). Fixes a real
    build/runtime crash for any Next.js App Router (RSC) consumer of this
    package — not just this repo's own docs site.
  - `NavbarItem` gained a new optional `tooltipLabel` prop. The collapsed-mode
    Tooltip previously always duplicated `children` verbatim; with `asChild`,
    `children` is the slotted element itself (e.g. a whole `<Link>`), so that
    duplicated a focusable element inside the tooltip bubble — invalid per the
    WAI-ARIA tooltip pattern and visually broken. `tooltipLabel` supplies the
    plain-text accessible duplicate instead in that mode. No change for
    existing non-`asChild` usage.
  - `NavbarItem` with `asChild` on a collapsed, non-submenu row and no
    `tooltipLabel` used to still mount the Tooltip, producing a real,
    focus-visible bubble (`role="tooltip"`) with empty content (review
    comment, PR #43 — reproduced and confirmed: `textContent: ""` measured in
    a jsdom render before this fix). Now the Tooltip is skipped entirely in
    that case and a dev-only `console.warn` fires instead (never throws) —
    same "prop contract violation" precedent as `ProductSwitcher`'s `href`/`to`
    (`AGENTS.md`). No change when `tooltipLabel` is provided, or outside
    `asChild`/collapsed.

  **Figma fidelity re-pass (same PR, before merge):** re-extracted every
  component's Figma node (including a previously-unreachable `NavbarSubmenu`
  instance, node `6291:4003`) and corrected drift between the shipped code
  and the mockups:
  - `NavbarItem`/`ProductSwitcher`: removed an unsupported `rounded-sm` —
    no radius exists anywhere on these rows in Figma.
  - `NavbarItem`: line-height corrected 115%→150% (`leading-normal`).
  - `NavbarItem`/`NavbarSubmenuItem` selected state: left border corrected
    3px→2px; text/icon color no longer switches to brand-primary (stays
    default-colored, only the background tint and border change) — corrects
    an openaev-precedent-derived guess that Figma's real instance overrides.
  - `NavbarSubmenuItem`: typography corrected to the real spec (12px
    `--text-default-secondary`, deeper `pl-6` indent) — previously built by
    symmetry with `NavbarItem` (14px, primary color) in the absence of a
    reachable instance; now Figma-confirmed.
  - `NavbarItem` chevron now hidden whenever the ancestor `Navbar` is
    collapsed, even for rows with a submenu (`chevron && !collapsed`) —
    matches confirmed opencti behavior, previously rendered unconditionally.
  - Docs site's `DocsNavbar`/`NavbarBrand`: collapsed header now swaps to a
    dedicated picto-only asset instead of CSS-scaling the full logo down.
  - Found and fixed a real spec-drift bug while re-verifying: both
    `NavbarItem.meta.ts` and `NavbarSubmenu.meta.ts`'s `contrastPairs` and
    hand-written a11y notes still referenced the old (removed)
    selected-text-turns-brand-colored behavior/tokens — `check:contrast` was
    silently validating the wrong pair. Recomputed and corrected both.

  **Figma fidelity re-pass #2 (same PR, before merge):** a real-OpenCTI-
  integrated reference frame (node `5425:11518`) surfaced further drift the
  first pass's isolated-component frames couldn't show, plus a docs-site
  consolidation request:
  - Removed an invented border on the `NavbarSubmenuItem` selected state —
    node `5425:11518` confirms background tint only, no stroke, correcting an
    unverified symmetry-with-`NavbarItem` assumption from the previous pass.
  - Collapsed-mode header/icon alignment: `Navbar`'s header row and
    `ProductSwitcher`'s trigger now switch to `justify-center px-0` when
    collapsed (previously always left-anchored `pl-4 pr-2`/`pr-2`), fixing a
    ~6px rightward offset between the header logo and the item icons below
    it — re-extracting node `2843:5134` showed Figma's own collapsed
    `productLogo` uses a fully different centering strategy than the
    left-anchored expanded row, not the same padding scaled down.
  - `NavbarSubmenu`: added parent-selected propagation — a submenu's trigger
    row (in both accordion and flyout/collapsed mode) now also renders
    `aria-current="page"`'s selected treatment when any descendant item is
    the active page, so a collapsed user landing mid-navigation still sees
    which top-level section they're in (node `5425:11518`).
  - `NavbarItem`: the collapsed-mode Tooltip is now skipped for any row that
    is itself a submenu trigger (`chevron === true`) — it was rendering on
    top of that row's own hover/focus-opened flyout, hiding it. Rows without
    a submenu keep the tooltip unchanged.
  - `NavbarSubmenu`'s flyout panel (`DropdownMenu.Content`) re-extracted
    against node `6301:10728`: fixed width corrected to the measured 179px
    (was an invented `min-w-48`/192px), and confirmed/kept borderless,
    shadowless, radius-less, edge-to-edge — the previous pass's
    `border`/`shadow`/`rounded-sm`/`p-1` were all invented, not Figma-sourced.
    New `179px` value is a `token-lint-allow`'d layout constant (not a
    multiple of the 4px spacing scale).
  - `DocsNavbar`: added the missing separator between "Status" and
    "Components" (Figma's own grouping in this frame), and corrected the
    Filigran wordmark to exactly `125px` wide (node `5425:11518`, also
    `token-lint-allow`'d).
  - Re-verified typography (font/size/weight/line-height/tracking) and icon
    color for every text node across all four components against fresh Figma
    reads — all were already correct from re-pass #1 with one exception: the
    `tracking-*` tokens store their value as a raw px number where Figma's
    panel displays a percentage of the font size (a pre-existing, out-of-scope
    systemic naming/units mismatch, confirmed again here at a second font
    size — flagged, not fixed, per its original scope decision).
  - Removed a stray yellow status-dot artifact from the item rows.
  - **Docs site presentation only** (point 9 — no change to the components
    themselves): the 4 separate docs nav/homepage entries for
    Navbar/NavbarItem/NavbarSubmenu/ProductSwitcher now collapse into ONE
    "Navbar" entry, rendered as a `Tabs` page (the library's real `Tabs`
    component) with one tab per member. Driven by a new optional
    `ComponentMeta.docsGroup` field (`{ id, label, tabLabel }`) and a shared
    `docs/lib/grouped-registry.ts` helper consumed by both the sidebar nav
    and the homepage "Components" grid (the grid wasn't grouped in an
    earlier draft of this change — found and fixed before commit).
  - **ProductSwitcher**: added a real product-logo asset set
    (`docs/public/product-logos/`, extracted from node `2624:11345`) and a
    matching "Product Logos" reference table on the docs Tokens page; the
    component's own demo now renders these real logos instead of a
    placeholder, and a redundant visible text label next to the wordmark
    logo (causing visual overlap) was removed.
  - `Navbar.meta.ts` gained two `contrastPairs` entries (the footer
    collapse/expand toggle's label/icon, reusing `NavbarItem`'s
    already-verified default-state tokens) — the container itself has no
    other owned foreground content, but the conformity suite requires a
    non-empty declaration from every component with no "composes only"
    exemption.

- dd40ac4: Add `NavbarTitle` — a non-interactive section-label primitive for the `Navbar` (React port of Figma's `navbar title`, node 7192:39355), so consumers stop hand-rolling a group heading. New export.

  Also adds a required `category` field to the `ComponentMeta` type (exported for `import type` from the package root). This is a first-party docs-tooling contract: every component's `.meta.ts` now declares its category, enforced at compile time. Product code never constructs `ComponentMeta` literals (it only ever reads generated data), so there is no runtime or component-API break — hence a minor, not a major. Anyone who _does_ construct a `ComponentMeta` literal must add `category`.

- 52f36c4: feat(paper): add Paper component (elevation/surface container)

  New `Paper` component: a neutral, non-interactive surface container — the
  FDS equivalent of MUI's `Paper` — with no default ARIA role or semantics.
  Renders a plain `<div>` by default; `as` (matching `Text`'s established
  polymorphism convention, not MUI's `component`) renders it as any other
  element or component, e.g. `as={Link}` for the "clickable card" pattern
  found at 4/113 measured real usage sites.

  `elevation` (0–3, default 1) maps 1:1 onto `theme.css`'s pre-built
  `.layer-0`…`.layer-3` classes, shifting background + border together as a
  single step; no `variant`/`square` props (0/113 measured real usage) and
  no shadow at any level — Figma shows zero `box-shadow` on any of the 3
  given nodes, `--shadow-*` tokens are unused repo-wide, and Material
  Design's own dark-theme guidance favors surface-lightening over shadow,
  which is exactly how the existing `--bg-elevation-*-layer-N` dark values
  already behave. Only elevation 1 is directly Figma-observable (the given
  Figma component is a single symbol, not a component set); levels 0/2/3
  reuse the same pre-existing, Figma-sourced token family but are not yet
  independently Figma-verified as Paper variants — documented honestly in
  `Paper.rfc.md` §3.1/§3.6 and `Paper.figma.json`, pending a future Figma
  variant-set addition.

  The border is decorative and non-gating (consistent with Button's
  redundant border and Chip's decorative icon): a static, non-interactive
  container is not a WCAG 1.4.11 "UI component" until a consumer renders it
  interactive. It reproduces Figma's exact read appearance — the existing
  `--border-elevation-subtle-layer-N` token's own color, diluted to the
  observed 10% via the repo's established `color-mix()` technique — a read
  value, never an invented one; the 10%-dilution figure itself is not yet
  backed by its own Figma token (tracked in `process/AI-BACKLOG.md`). Usage
  rules state explicitly that the border is never the sole differentiator
  between two adjacent surfaces.

  Paper's gating `contrastPairs` cover text-on-surface only: default and
  secondary text against all 4 elevation layers, both modes (8 pairs, 16
  checks) — all pass at 4.5:1, tightest at 5.30:1. Ships as `status: "beta"`
  with `wcagStatus: "pass"` (no allow-list needed). No new dependency: pure
  `cva()` + native CSS, +6.6 KB minified / +1.9 KB gzip in isolation (see
  `scripts/check-bundle-size.ts`'s dated budget-bump comment).

  New ROADMAP entry (priority 10, tied with Chip, immediately behind
  MultiSelect's 9, owner `sandy`) — Paper ranked #15 in measured cross-product
  usage (83 files / 113 render sites across OpenCTI + OpenAEV) but had no
  ROADMAP entry at all before this component; see `Paper.rfc.md` §9 for the
  full arbitration record and `process/AI-BACKLOG.md` for the process-gap
  learning this surfaced.

- b0b12eb: feat(search-field): add SearchField component

  New `SearchField` component: specialized search input with leading search icon,
  optional trailing action slot (`searchOption`), Enter-to-submit behavior, and
  size variants (md/sm). Built from RFC (status: draft, pending human approval)
  with Figma MCP extraction.

- be6c85c: feat(select): add Select component wrapping @radix-ui/react-select

  Exports: Select, SelectGroup, SelectValue, SelectTrigger, SelectContent,
  SelectItem, SelectLabel, SelectHelperText, SelectSeparator. Compound
  component pattern — every sub-part forwards a ref
  (`forwardRef<ElementRef, ComponentPropsWithoutRef>`), matching the
  Dialog/Tabs convention (now codified as a library-wide rule in
  AGENTS.md's "Compound components — forwardRef on every sub-part" section). Single size
  (md, fixed h-9 trigger) matching Input's own height.

  Error state is centralized: `error` lives only on `Select` (Root) and
  propagates via context to `SelectTrigger` (error border) and
  `SelectHelperText` (error text color) — no `error` prop on any sub-part,
  one way to declare the field's error state. `SelectLabel` stays optional;
  a dev-only `console.warn` (stripped in production) fires only when
  `SelectTrigger` would otherwise have no accessible name at all (no
  `SelectLabel` sibling and neither `aria-label` nor `aria-labelledby` set).

  Accessible by default via Radix (role=combobox/listbox/option, full
  keyboard operability — Enter/Space/Arrow keys/typeahead/Escape — focus
  management, native form participation via a hidden native `<select>`).
  `SelectGroup` + `SelectSeparator` support categorized option lists.

  Single-selection only — Radix's Select primitive does not support
  multiple selection, and this component does not add custom multi-select
  behavior. A dedicated `MultiSelect` component is planned next (see
  ROADMAP.json); consumers who need multiple selection today keep their
  existing MUI implementation until it ships — this is a deliberate,
  tracked partial-coverage decision, not a regression introduced by this
  component.

- 56f7e59: Add the Slider component and its `@radix-ui/react-slider` dependency

  Numeric value selection along a track, built on `@radix-ui/react-slider` and on
  the values read from the Figma Slider Field in both modes. Renders an optional
  label with an info slot, a 4px rail with a filled range and a 16px thumb, and
  optional help text, so no separate field wrapper is needed. The value is an
  array, which is the primitive's own contract: one thumb is rendered per entry,
  so a two-element value gives a range at no extra API cost.

  The RFC is amended rather than replaced: the draft had concluded that the
  filled range and the thumb were flattened raster assets with no tokens, and
  built its colour, gap and accessibility sections on that premise. They are real
  vectors with real variable bindings. Every divergence is listed in the RFC's
  divergence table, including the corrected rail token and radius, the corrected
  label token, and the corrected product volumetry (7 occurrences over 6 files,
  not 9 over 4).

  This version replaces none of the seven existing MUI usages, and the RFC says
  so site by site: `marks` and the value bubble are deferred, and every call site
  depends on one of them or on an escape hatch the design does not expose.

  Two measured Radix behaviours are documented in the migration table and pinned
  by tests: an out-of-range controlled value is reported verbatim rather than
  clamped, and a multi-thumb value suffixes the submitted field name with `[]`.

  This release adds `@radix-ui/react-slider` to the package dependencies. It is a
  new runtime dependency for consumers, declared here rather than alongside the
  Checkbox and Radio release because this is the release that actually imports it.
  Measured cost: the primitive bundles to 26.3 KB minified / 9.5 KB gzipped on its
  own, but its marginal cost in this package is lower because its Radix internals
  are already shared with the Checkbox, Radio and Switch primitives -- the
  component and its dependency together add 20.1 KB minified and 6.4 KB gzipped to
  the built bundle. These are the figures `scripts/check-bundle-size.ts` records
  as the rationale for its budget, re-measured on the rebased tree.

- bdf535d: feat(switch): add Switch component

  New `Switch` component: boolean on/off toggle built on `@radix-ui/react-switch`,
  with an optional integrated label, native keyboard activation (Space/Enter),
  controlled/uncontrolled value, and `forwardRef` to the underlying `<button>`.
  Size and color are intentionally fixed to the single Figma-defined variant in
  this version (see `Switch.rfc.md` §4.1/§4.4/§7).

  Ships as `status: "beta"` with `wcagStatus: "fail"` — 4 real non-text-contrast
  pairs (WCAG 1.4.11) fail against the current Figma color tokens in at least
  one mode; the component remains identifiable because the thumb (which carries
  the checked/unchecked state) contrasts comfortably against the page background
  in every case. Allow-listed in `scripts/wcag-allowlist.json` (approved by
  Sandy, lead design, expires 2026-08-31) pending a global color-token
  remediation pass. See `Switch.meta.ts` accessibility notes and `Switch.rfc.md`
  §5.4 for the full analysis.

- 51e7202: feat(text): add Text component decoupling HTML semantics from typography style

  Exports: Text (+ TextProps, TextVariant, TEXT_DEFAULT_TAG). Two independent
  props: `as` picks the HTML tag (h1…h6, p, span, label, a, code…), `variant`
  picks the Named Style from theme.css (title-2xl…title-xs, content-base(-bold
  /-medium/-link), content-compact(-bold/-medium/-link), content-caption,
  content-highlight, content-button, content-code) — never fused, so
  `variant="title-lg"` never forces an `<h3>`. Each variant has a sensible
  default tag when `as` is omitted (see Text.rfc.md §4.1). v1 scope is
  intentionally minimal: `as`, `variant`, `className` passthrough, `children`
  — no MUI-style `color`/`align`/`noWrap`/`gutterBottom` props, additional
  styling goes through `className`. Doubles as the migration target for MUI
  `<Typography variant="X">` call sites (crosswalk table in Text.rfc.md §4.4).
  Ships with a Figma fidelity spec (18/19 variants — `content-code` has no
  Figma node) and 3 WCAG contrast pairs (body text @4.5:1, large headings
  @3:1, both themes).

- 9cb9efd: feat(textarea): add the multi-line text field from Figma node 2686:4896

  New `Textarea` component: native `<textarea>` with integrated label, required
  marker, info slot and helper/error text, sized in lines via `rows` (default 3)
  or autosized with `minRows`/`maxRows`. Replaces `<TextField multiline>`.
  Reasoning and the five arbitrations: `Textarea.rfc.md`.

- bbc908f: feat(tooltip): add Tooltip component wrapping @radix-ui/react-tooltip

  Exports: Tooltip, TooltipTrigger, TooltipContent, TooltipProvider.
  Styled with FDS tokens (bg-tooltip mapped to --border-elevation-subtle,
  text-default-primary, shadow-global-shadow, radius-sm). Compound component
  pattern — consumers compose parts freely. Accessible by default via Radix
  (role=tooltip, aria-describedby, Escape dismiss, keyboard focus trigger).

- 78f8993: feat(breadcrumbs): add an adornment slot, and stop the width mechanism reading its container

  New optional `adornment` renders host content after the current entry, outside
  the list so it is never announced as a path step. The current entry's
  percentage width cap is replaced by a shrink weight: it broke whenever a host
  placed the root in a flex row, which is what an adornment used to require.
  Details: `Breadcrumbs.rfc.md` §6.1 and §9 Q13.

- 60b7f5c: feat(breadcrumbs): add the Breadcrumbs component

  New component: a data-driven path (`items`) rendering the WAI-ARIA breadcrumb
  pattern, with `linkComponent` so a router keeps client-side navigation and the
  full label stays readable through `title` when an entry ellipsizes. A link is
  identified by a permanent underline, not by colour. Arbitrations:
  `Breadcrumbs.rfc.md` §9.

- dd3deb4: feat(chip, combobox): support data colours through a bounded wash

  `Chip` takes a new optional `color` — a free hex coming from the data (an
  OpenCTI label or marking definition) — and normalizes it into a bounded wash;
  the label, icon and border stay on system tokens, and an invalid hex changes
  nothing but warns in dev. `Combobox` gains `getChipColor(option)` (multiple
  mode) to feed it per selected value. A CLOSED product semantic (TLP included)
  still goes through `severity`/`entity` — two mechanisms, two uses. The neutral
  leading icon also moves off its interim fallback onto `--icon-neutral`, now that
  the token exists. Additive throughout: without the new props, rendering is
  unchanged. Bounds, computed contrast proof and arbitration: `Chip.rfc.md` §9.4
  and §9.5, `Combobox.rfc.md` §9 Q13.

- 6c71623: feat(chip): forward a tabIndex to the delete button, and add the Popover primitive

  Two Combobox foundations, both additive and both invisible to existing
  consumers.

  `Chip` gains `deleteTabIndex?: number`, forwarded verbatim to the delete
  `<IconButton>`. It is the only way a composite widget can reach that button's
  Tab stop: `Chip`'s own `...props` spread lands on the label body, never on the
  delete button, so no consumer prop could previously touch it (`IconButton`
  itself already accepted and forwarded `tabIndex` — the gap was strictly Chip's
  wiring). A `Combobox` field renders a _row_ of chips, and WAI-ARIA's
  composite-widget pattern — which is also MUI Autocomplete's behaviour, hence
  what the products already expect — makes that row a single Tab stop navigated
  with `ArrowLeft`/`ArrowRight`; N chips × 2 native stops each would otherwise sit
  between the user and the input. **The default is unchanged**: omitted, so the
  button keeps its own native Tab stop and the §4.3 "two distinct tab stops"
  guarantee still holds for a standalone chip. `-1` removes the stop without
  making the control inert — still programmatically focusable, still fires
  `onDelete` on Enter/Space, which is what lets a chip row focus a chip and
  delete it. Four tests cover the default, the opt-out, activation while out of
  the Tab order, and the untouched body stop; see `Chip.rfc.md` §4.3's amendment
  for the rejected alternatives (`deleteButtonProps`, a boolean flag).

  `@radix-ui/react-popover@^1.1.23` is added to both manifests (package manifest
  plus the install-proxy root, per `process/PLAYBOOK.md` § "Adding a runtime
  dependency") as the floating layer the upcoming `Combobox` panel needs. Its
  fifteen transitive dependencies all resolve to versions **already** in the tree
  via `@radix-ui/react-select` — `@radix-ui/primitive` 1.1.7, `react-popper`
  1.3.7, `react-portal` 1.1.17, `react-slot` 1.3.3, and so on — so the known
  three-coexisting-`primitive`-versions debt is not made worse: zero new distinct
  version enters the graph. Measured bundle impact of this commit: **none**
  (398.7 KB minified / 125.1 KB gzip before and after — an unimported dependency
  costs nothing), so no budget bump is claimed here. The real delta lands with the
  component that imports it, against a runtime budget whose current headroom is
  0.3 KB minified / 0.9 KB gzip.

- d7ea4f2: feat(chip): add the `tonic` brand tone, and synchronize the Figma tokens it ships with

  **Scope, honestly stated: this is a token synchronization _and_ a new Chip
  tone.** The two are inseparable — the tone is backed by two new Figma variables,
  and a Figma export is a snapshot of the whole file, so the same regeneration
  also carries the elevation-hover work Thibault Cazin (@fimow) landed in Figma.
  Splitting them would have meant hand-editing a generated artifact. Three change
  families, in full:

  **1. `Chip` gains a third color axis — `tone`, single value `"tonic"`.**
  Precedence is `tone ?? entity ?? severity`, a **flat** axis rather than a 7th
  `severity` (design arbitration, Sandy, 2026-08-02: the severity scale is an
  ordered feedback scale, and a brand marker is not a gravity level). It renders
  the 20% α turquoise brand fill (`--color-filigran-tonic-accent-transparency-20`)
  with a matching icon tint (`--color-filigran-tonic-accent`), and stacks a second
  identical layer on hover like every other Chip fill. 20% α is the entity-family
  alpha, chosen on measurement: 30% breaks two dark stacked-hover pairs, and an
  opaque fill was rejected both for failing contrast and for producing an **inert**
  hover (the hover mechanism stacks the same token — opaque over opaque changes
  nothing). First consumer: OpenAEV's tenant-switcher "Enterprise Edition" badge,
  shipped meanwhile with a provisional `severity="neutral"`. Its rendering
  deliberately diverges from the legacy 21×14 bordered span: `tone="tonic"` is the
  standard 24px filled FDS chip — DS normalization, documented in `Chip.rfc.md`
  §4.1 / RULE-05. `Chip.meta.ts` now declares **50 contrastPairs** (47 before),
  every one regenerated by `pnpm check:contrast`; tonic passes in both modes
  (label 11.18:1 dark / 11.32:1 light, true stacked hover 6.81:1 / 8.45:1, icon
  8.45:1 / 5.52:1).

  **2. New `--bg-elevation-hover-*` token family — one real visual change.**
  `--bg-elevation-hover-layer-0..3` are added in both modes, along with the
  per-elevation `--bg-elevation-hover` and its `@utility bg-elevation-hover`
  class (the family now matches its `default`/`heading`/`highlight` siblings),
  and **`--bg-input-hover` is re-pointed from `--bg-elevation-heading` to
  `--bg-elevation-hover`**: dark `#070d18 → #0d172b`, light
  `#f2f2f3 → #f4f4f6`. This is the one change in this release that alters existing
  rendering. Its consumers are `Select` (option row `data-[highlighted]` and
  `data-[state=checked]` background) and `ProductSwitcher` (menu row hover). Every
  affected pair was recomputed by the gate and passes: item label and icon on
  hover **15.98:1** dark / **16.02:1** light; `item-border-focus` and
  `item-border-selected` **9.47:1** dark / **4.45:1** light. `Select.figma.json`'s
  captured hover background and the hardcoded ratio lock-ins in
  `scripts/lib/product-switcher-dropdown-visuals.test.ts` were updated in the same
  change set.

  **3. Additive, currently unconsumed.** The three unused layers of the hover
  family, and the light `--bg-elevation-heading-layer-1/2/3` re-map
  (`gray-100 → gray-50`, `gray-150 → gray-200`, `gray-200 → gray-300`) — nothing
  reads `bg-elevation-heading` today, so these are visible only on the docs token
  page, where the hover family is now listed alongside its siblings.

  No API removal, no rename, no behavior change for existing `severity`/`entity`
  chips: `tone` is optional and additive.

- cd4b8ee: feat(combobox): add the controlled `open` prop and the two field-line slots

  New optional `open` on `Combobox` and `startIcon`/`adornment` on `ComboboxField`;
  omit them and behaviour is unchanged. `open={false}` with no `onOpenChange` is the
  chips-only field: no panel, native arrows. Arbitration: `Combobox.rfc.md` §4.6-4.7.

- e09a2d0: fix(combobox): derive the field's text from the selection, and keep focus in it

  Defect fix: single controlled mode showed an empty field, then desynchronised.
  By default now, the field shows its value's label and a pointer pick no longer
  moves focus out of it. New: `selectOnFocus` (on by default) and `openOnFocus`.

- f8d3781: feat(combobox): align the panel to its Figma node and complete the product behaviour set

  The single changeset for PR #150, which carries two waves on one component.

  **Figma fidelity (node `6899:15536`).** The group header is a full 32px row with
  its Content/caption text bottom-aligned, not a 23px caption line; a disabled
  option carries the node's own fill and has NO hover treatment at all, by never
  reaching the highlighted state rather than by suppressing its paint; the
  highlighted row's left border is 1px on `--border-input-hover`, not 2px on the
  brand token; the field and its content slot space their parts on `--spacing-1`;
  an option's label is inset a further 8px inside the row. Every surface moves to
  the COMPOSITE Named Style utility — the decomposed `font-content-*` family
  compiles to `font-family` alone, so the four-class idiom left `font-weight`
  inherited.

  Three of these were reported from a comparison bench; five more were found by
  re-reading the node, all of them rows the spec had inherited from
  `Select.figma.json` instead of reading here.

  **Chip.** The truncated value chip follows the long-label overflow doctrine
  (`NavbarItem.rfc.md` §3.7): the native `title` is gone and the library Tooltip
  opens only while the label is really clipped. The complete label remains the
  accessible name. `Chip` becomes a client component — it gained state with the
  measurement.

  **Select.** The same shared `Select Field Item` row, so the same two corrections:
  highlight border 1px on `--border-input-hover`, and the disabled row loses the
  fill it never had on any node. Trigger gap 8px to 4px.

  **Product behaviours.** Five additions, scoped by a census of every authored
  Autocomplete site in OpenAEV and OpenCTI (158 sites, wrappers resolved):

  - every callback that can fire from more than one thing now states its cause —
    `type`, `select`, `clear`, `reset` — and carries the DOM event when one exists.
    `onValueChange`, `onInputChange` and the new `onOpenChange` all take a second
    `meta` argument. Source-compatible: existing call sites ignore it. 28 authored
    sites need this, several of them expressing it as `if (!event) return`;
  - `closeOnSelect` closes the panel after each pick in multiple mode (default
    `false`, today's behaviour);
  - `keepInputOnBlur` leaves the typed text alone on blur (default `false`);
  - `allowCustomValue` + `createValueFromInput` accept a value the list does not
    contain, which retires this component's own "v2" deferral;
  - `onCreateOption` offers the create affordance, with the two triggers its two
    definition nodes draw: an actionable `Create ‘x’` row on click, and an
    informational `Entry to add ‘x’` hint for Enter.

  An inline lambda passed as `getOptionLabel` or `filterOptions` no longer re-runs
  the filter over the whole list on its identity alone — 36 authored sites write it
  that way.

  Consumers reading a painted value from a Combobox panel — a product theme test,
  a visual snapshot — should re-baseline: the group header, the highlight border,
  the field gap and the disabled row all move.

- 77274b8: feat(combobox): add the labelPosition axis and ComboboxLabel's required indicator

  New optional `labelPosition` (`"top"` default, `"left"`, `"none"`) and `required`
  on `ComboboxLabel`, whose asterisk is `aria-hidden` like `SelectLabel`'s. Omit
  both and nothing changes. Arbitration: `Combobox.rfc.md` §4.8, §9 Q13.

- bd076e8: `Combobox`: the option row's height floor is now declared rather than inferred.

  Node 6899:15536 draws two rows: `Select Field Item` at 32px and the two-line
  `Option Complex` at 48px. The component keyed the 48px floor on the mere
  presence of `renderOption`, which answers a different question — `renderOption`
  is how a caller draws a row, not how tall it is. Every caller drawing an
  ornament beside one line of text was paying the two-line floor; the node itself
  disagrees, since `Multi Select Field Item`, the row that carries a checkbox, is
  32px like the bare one.

  New `isOptionTwoLine?: (option: T) => boolean` declares the two-line row. Rows
  that do not declare it floor at 32px whatever they draw. Content growth was not
  used as the signal: it measures 41px in a real browser, which matches neither
  height the node draws.

  Callers passing `renderOption` for a one-line row need no change and gain the
  32px the node specifies. Callers drawing a genuinely two-line row must now
  declare it to keep 48px.

- c0d6f07: feat(header): finalise Header for product adoption without neutralisation

  The documentation site became the first real consumer of `Header` when its
  top banner adopted it. Getting there required the consumer to **undo** part of
  the component and to **restate** another part by hand. This release removes
  both, and corrects one visual property that was recorded wrongly.

  **Corrected before it ever shipped: the bar carries a 4px backdrop blur.** The
  Header's first pass recorded it as having no blur. That was a mistake, and
  the way it was made is worth stating: Figma's code output emits no
  `backdrop-filter` for the component node, and that silence was read as a design
  fact. It is a codegen gap — the same tool emits `backdrop-blur-[2px]` correctly
  for the Dialog overlay node. Measured against the render instead, content
  passing behind the bar has a maximum single-pixel luminance step of 2 (p99 = 1)
  against 210 for content drawn on top of it, with a smooth ~20px Gaussian
  profile. The component now applies `backdrop-blur-sm` = `blur(var(--blur-sm))`
  = 4px, an **existing** token — no new token, no `theme.css` edit, no literal.
  4px is also the radius OpenCTI and OpenAEV already ship in production, so for
  them this is convergence rather than change.

  The node carries **two** effects: this Background blur, and a native Figma
  Glass effect. Only the Background blur is a web binding. The Glass effect
  simulates _refraction_, which CSS cannot express — `backdrop-filter` filters
  the backdrop in place, it does not bend it — so its refraction and dispersion
  aspects are out of web scope **by nature** and are deliberately not faked. The
  Figma frame and the browser will differ at the bar's edges, permanently and by
  design. The Header has not been released yet, so no consumer inherits the
  earlier appearance; there is no flag to restore it either, because it was a
  defect rather than a variant.

  **The bar is always fixed to the top of the screen, and `sticky` is not a
  supported mode.** A design doctrine, so it constrains the recipes rather than
  the component: the top offset varies per product — OpenCTI recomputes it from
  stacked banner heights — so positioning is still supplied by the consumer, and
  the component still ships none. What changed is that the documentation no
  longer teaches `sticky`. OpenGRC uses it today and converges onto the pinned
  form at migration.

  **The blur needs content under the bar, and the shell decides that.**
  `backdrop-filter` samples what is painted behind an element, so it renders as a
  no-op wherever nothing passes under the bar — the case in any shell that
  offsets its main content below the header, as both products do today. That is
  expected and intended, not a partial implementation. A shell that instead spans
  the full height and reserves the bar's band as `padding-top` gets the effect
  live, which is what the Figma node depicts; this repository's own documentation
  site has moved to that pattern and is the first real consumer of the glass. Both
  patterns are written down, with the two-utility difference between them, in
  `Header.rfc.md` § 3.4. The documentation also ships one demo where realistic
  content scrolls under a genuinely pinned bar. Reading the effect in real use is
  what set its final balance: the veil is painted at **94%** opacity. The gradient
  token is shared with the `Navbar` but the alpha is not — it is a Tailwind
  utility on `Header`'s own `::before`, so the `Navbar` keeps its opaque surface
  and no Header-specific gradient token was needed.

  **`fullWidth?: boolean`, default `true`.** Purely additive; nothing changes for
  existing consumers. `Header` stretched to its containing block unconditionally,
  so any consumer positioning the bar itself had to pass `className="w-auto"` to
  get `cn()` to drop it — the consumer undoing the component. The reason it
  mattered is that a dynamic inline `left` offset is invisible to
  `tailwind-merge`, so `w-full` survived and the bar overflowed the viewport by
  exactly the offset, measured at 180px. `fullWidth={false}` stops the class being
  emitted at all. `w-auto` still works; it is simply no longer necessary.

  **`HeaderGroup`'s `grow` accepts `"unbounded"`.** `grow` is now
  `boolean | "unbounded"`. `true` behaves exactly as before, including Figma's
  400px cap, so existing call sites are untouched. `"unbounded"` emits `min-w-0
flex-1` and no maximum, for a product whose own minimum genuinely exceeds
  400px — OpenAEV pins 680px today. The escape is typed rather than left to a
  `max-w-*` override so that needing it stays visible in review.

  **The height is published as `--fds-header-height`.** A consumer in a `fixed`
  layout must offset its content by the bar's height, and until now it restated
  `68px` by hand next to a height it did not control — two values free to drift.
  The height is now emitted as `h-[var(--fds-header-height,--spacing(17))]`, so a
  host can retarget the bar and a consumer can offset against it with
  `top-(--fds-header-height,--spacing(17))`. The default lives in the `var()`
  fallback and nowhere else: this is a **technical hook, not a design decision**,
  so it is deliberately absent from the generated `tokens/theme.css`. Tailwind
  compiles `--spacing(17)` to `calc(var(--spacing) * 17)`, so the value stays
  token-derived and no literal pixel value exists in the source.

  **The tenant-theming contract is now pinned by proofs, not by prose.** OpenCTI
  lets a tenant restyle the product background at runtime. `docs/e2e/header-glass-theming.spec.ts`
  proves in a real browser that injecting `--gradient-default` on an ancestor
  repaints the bar, that injecting only the gradient's stops does **not**, and
  that the new blur and the tenant gradient cohabit. The proofs compare raw PNG
  buffers of the same region, so they need no image decoder and cannot be fooled
  by a tolerance.

  No change to padding, the bottom hairline or elevation. The products diverge
  from all three today (24px, no border, various shadows); those are resolved by
  convergence during each product's migration, documented in the pilot PRs, and
  are deliberately **not** turned into API surface. See `Header.rfc.md` § 7.

- c34a695: Make the package installable as a direct git dependency, pinned to a
  commit SHA — the interim consumption method decided by leadership while
  npm publishing (S5) isn't automated yet. Neither npm nor pnpm can target a
  subdirectory of a plain git dependency (both read the package.json at the
  cloned repo root), so the monorepo root manifest now acts as an install
  proxy: it mirrors `main`/`module`/`types`/`exports`/`files` into
  `packages/filigran-design-system/dist`, adds a `prepare` script that runs
  the real build (tsup + Tailwind CLI) at install time, and mirrors the
  `dependencies`/`peerDependencies`/`devDependencies` needed to build
  standalone. One uniform git reference now works for both package managers:

  ```
  npm install "@filigran/design-system@github:XTM-Foundation/filigran-design-system#<commit-sha>"
  pnpm add "@filigran/design-system@github:XTM-Foundation/filigran-design-system#<commit-sha>"
  ```

  No change to the published component API or import surface — this is
  purely an additional, non-breaking installation path. Filed as `minor`
  (new capability, no existing behavior removed or altered) rather than
  `patch`; flagged here in case reviewers judge it should stay `patch`.

- 311c2e6: feat(icon-button): accept `asChild`, for an icon-only control that is really a link

  `Button` has had `asChild` since it shipped; `IconButton` had not, so an
  icon-only link could not be built from the component at all. Products worked
  around it by applying `iconButtonVariants()` to an anchor by hand and
  re-declaring the glyph colour and the active background, because a bare variants
  call carries neither — OpenCTI and OpenAEV both ship a `TopBarIconLink` doing
  exactly that (LIBRARY-FEEDBACK #13). This retires that workaround.

  One detail worth knowing, because it is not the obvious implementation: the
  glyph is cloned INSIDE the consumer's element rather than handed to `Slot` as
  its child. Passing the glyph span to `Slot` directly makes the span the control
  and drops the anchor entirely — the element never renders and the accessible
  name goes missing with it. `type` is also applied on the button path only, since
  forwarding it would emit an invalid `type="button"` on an `<a>`.

- dec44f0: Add the Icon component and the Lucide integration: generated icon registry
  (Lucide glyphs as named tree-shakeable imports + Filigran custom glyphs in
  currentColor — full Figma set arbitrated by design, 2 custom glyphs pending
  drawing; current counts in reports/icon-registry.md), string-name AI-first
  API (`<Icon name="…" />`),
  decorative-by-default a11y with semantic `aria-label` mode, token-mapped
  sizes 16/20/24, decorative gradient accents (ia/focus), and a CI
  bundle-size gate proving the bundle never embarks the full icon library.
- 34244d0: feat(icons): add `loader-circle`, migrate the last hand-written icon call sites to the registry, and gate the pipeline

  - **Vocabulary**: `icon-mapping.json` gains a `loader-circle` entry
    (arbitrated match for Material's `progress_activity`, `confidence:
"arbitrated"`, `status: "mapped"`); the generated registry (`pnpm
generate:icons`) now exposes it as `<Icon name="loader-circle" />` — no
    hand-edit of `icon-registry.generated.tsx`.
  - **`Button`**: the loading spinner now renders through `<Icon
name="loader-circle" size={16} className="animate-spin" />` instead of a
    hand-written inline `<svg>`. Visual role fully preserved — same 16px size,
    `animate-spin` rotation, `currentColor` inheritance, decorative-by-default
    a11y (no accessible name, `aria-hidden`) — only the glyph's own internal
    geometry differs (Lucide's single stroked ring vs. the previous hand-drawn
    two-tone fill arc), which is an expected, cosmetic side effect of routing
    through the shared vocabulary instead of a one-off drawing. Covered by a
    new regression suite, `Button.spinner.test.tsx` (registry glyph used, no
    raw `<svg>`, spin/size/color/a11y all locked in).
  - **`TabsMeta`**: the documented `demoIcon` (exported as part of `TabsMeta`,
    `packages/filigran-design-system/src/components/tabs/index.ts`) now uses
    `<Icon name="clock" size={16} />` instead of a hand-rolled clock `<svg>` —
    matching its own "use `Icon`" prescription for consumers. No visible change
    (same 16×16 slot, same glyph).
  - **New CI gate**: `pnpm check:icons` (wired into `pnpm report:conformity`
    and `pnpm test:scripts`, exactly mirroring `pnpm check:language`'s
    architecture — pure detector + CLI walker + written report) blocks any
    hand-written `lucide-react` import or `<svg>` tag under
    `packages/filigran-design-system/src/**` or `docs/**` outside a short,
    justified, permanent exception list (`Icon.tsx`'s own internal
    gradient-mask `<svg>`, the generated registry itself, `Switch`'s thumb —
    the control's physical shape, not an icon — and brand logo `<img>` assets)
    plus a temporary, mandatory-expiry allowlist (starts empty). See
    `process/PLAYBOOK.md` "Adding or migrating an icon", now cross-referencing
    this gate.

  No public API change beyond the new `loader-circle` icon name; `Button` and
  `TabsMeta`'s existing visual/behavioral contract is unchanged.

  **Docs site only** (no `@filigran/design-system` change): the 4 remaining
  hand-written `↗` unicode arrows in `docs/app/page.tsx` and
  `docs/components/ComponentBody.tsx` (external-link affordances next to
  "Open in Figma" / "Machine contract" / homepage links) are replaced with a
  decorative `<Icon name="external-link" size={16} aria-hidden />` from the
  package, inline inside their existing anchors — every occurrence lives
  inside a link with its own visible text, so nesting an interactive
  `IconButton` there would create an invalid nested-interactive control; a
  non-interactive decorative icon keeps the existing anchor as the sole
  interactive element while still passing the new gate above.

- 5880796: Add sub-menus to `Menu`: `MenuSub`, `MenuSubTrigger` and `MenuSubContent`.

  A `MenuSubTrigger` is a menu row that opens a second panel sideways. It shares
  `MenuItem`'s geometry and typography exactly — same 36px minimum row, same
  `Content/base` label, same padding — and adds a trailing chevron. The child
  panel is the same surface as the panel it opens out of, offset 4px clear of it.

  Keyboard, verified in a real browser and not only in jsdom: `ArrowRight` opens
  the child panel and moves focus into it, `ArrowLeft` closes it and returns
  focus to the row that opened it, and `Escape` closes **one** level rather than
  the whole menu. That last one is a deliberate correction of the underlying
  primitive, which closes every open panel at once; the WAI-ARIA menu pattern
  says otherwise, and so did every product expectation.

  All three parts are library components wrapped with `forwardRef`, not
  re-exports, so they obey the same policies as the rest of the anatomy.

  Known limitation, recorded rather than hidden: there is no design token yet for
  "this row's sub-menu is open", so an open row currently renders the same fill
  as a hovered one. The state is still announced — the row carries
  `aria-expanded` and `aria-haspopup` — and a dedicated token is on the design
  backlog (`Menu.rfc.md` §3.6 G13).

- e7a8ab4: feat(navbar): gradient fix, ProductSwitcher redesign, collapsed-icon color, submenu icons

  Single PR, four arbitrated workstreams on the Navbar component family
  (Navbar, NavbarItem, NavbarSubmenu, ProductSwitcher — mono-subject at the
  component-family level).

  - **Gradient background (Navbar)**: @sandy reported the background
    illegible (frozen on dark values) in light mode on two products.
    Investigation found the library's own `Navbar` already resolves
    `--gradient-default` correctly per mode — Navbar.rfc.md §3.4/§5.4/§6.2
    still described a stale pre-gradient flat background/border and were
    never updated after fidelity re-pass #2/#3; corrected, no code/token
    change needed. The real symptom is each product's own legacy gradient
    code (LeftBar/TopBar) — filed to `process/AI-BACKLOG.md` so product-side
    sessions migrating to this `Navbar` don't chase a non-existent lib bug.
    New `scripts/lib/navbar-gradient-mode.test.ts` permanently guards both
    per-mode stop colors AND the angle (locked at exactly 90deg), the latter
    specifically because a recurring Figma-export defect (diagonal 135deg
    handles) has regressed this angle 3 times per `PROVENANCE.md`, most
    recently mid-flight in an unrelated external PR, with nothing previously
    catching a reintroduction.

  - **ProductSwitcher redesign**: full visual redesign of the popover/menu
    per @sandy's reference screenshot and Figma node `741:5065`
    (`DS_Design_System-old` — an old file whose own variables do not match
    current `theme.css`). Method: read the old node's structure/values, map
    each color to the closest CURRENT token, apply directly (no per-color
    validation stop — full mapping table in `ProductSwitcher.rfc.md`, final
    call is @sandy's visual checkpoint). Firm constraints: product logo
    always `w-[126px]`; the arrow beside the logo is now a real small/
    tertiary `IconButton` from the lib (opens the menu); listed product
    logos in the menu constrained to `w-[100px]` per the reference file
    (avoids width jumps between logos); submenu details follow the
    reference. `bg-elevation-highlight` chosen for the popover background
    for consistency with `Select`'s own popover pattern, not hex proximity —
    also @sandy's explicit call. All WCAG contrast pairs recomputed against
    the new background in both modes (no pair failed, no allowlist/
    alternate-token escalation needed). New
    `scripts/lib/product-switcher-dropdown-visuals.test.ts`.

  - **NavbarItem collapsed icon color**: while the ancestor `Navbar` is
    collapsed, the leading icon now uses `--text-default-primary` instead of
    the expanded state's `--text-default-secondary` — @sandy's explicit
    direct design specification, documented as a directed decision rather
    than a Figma extraction (`get_variable_defs` could not isolate the
    collapsed symbol's icon-span binding at this nesting depth;
    `NavbarItem.rfc.md` §3.4/§3.6 discloses this in full). Both tokens are
    pre-existing and already dual-mode-verified elsewhere in `theme.css` —
    nothing invented, only the assignment is directed. 2 new `contrastPairs`
    entries, verified via `pnpm check:contrast`. New
    `scripts/lib/navbaritem-icon-color.test.ts`.

  - **NavbarSubmenu icon support + global toggle**: `NavbarSubmenuItem` rows
    can already carry a leading icon (anatomy — size/color/spacing —
    independently re-confirmed this pass via Figma node `6608:18476`,
    the "with icons" variant, cross-checked against `6291:4003` "without";
    `NavbarSubmenu.figma.json` amended, no value changed, only its
    confirmation status). This PR's own contribution: a new
    `Navbar.submenuShowIcons` prop (default `true`), threaded via
    `NavbarContext` to every descendant `NavbarSubmenuItem`, ANDed with each
    row's own local `showIcon`. Mirrors opencti's real
    `me.submenu_show_icons` GraphQL user preference — the product
    reads/persists that value itself and passes it straight through;
    `Navbar` never reads storage itself. Deliberately does NOT affect
    `NavbarItem`'s own icon, including a `NavbarSubmenu` trigger row (itself
    a `NavbarItem`) — confirmed via precedent trace, matching the real
    opencti scope exactly. New `NavbarSubmenu.submenu-icons.test.tsx`
    (mutation-tested).

  **Docs/RFC**: `Navbar.rfc.md` amended (§2.3, §3.4, §3.6, §4.2, §4.3, §5.4,
  §6.2, §7, checklist); `NavbarSubmenu.rfc.md` amended (§3.2, §3.6, §4.2);
  `NavbarItem.rfc.md` unchanged (already accurately narrates opencti's real
  behavior). `Navbar.meta.ts`/`NavbarSubmenu.meta.ts`/`NavbarItem.meta.ts`/
  `ProductSwitcher.meta.ts` updated (props, examples, demos, contrastPairs,
  accessibility notes) — versions Navbar 0.1.0→0.2.0, ProductSwitcher
  0.1.0→0.2.0, NavbarItem 0.1.0→0.1.1, NavbarSubmenu 0.2.0→0.2.1.

  **Tests**: 4 new test files (`navbar-gradient-mode.test.ts`,
  `product-switcher-dropdown-visuals.test.ts`, `navbaritem-icon-color.test.ts`,
  `NavbarSubmenu.submenu-icons.test.tsx`) plus updates to existing keyboard
  test suites for the `NavbarContext` shape change — full component suite
  498/498, `pnpm test:scripts` 161/161, all gates green
  (`language`/`icons`/`contrast`/`tokens`/`wcag`/`docs`/`artifacts`).

  **Bundle-size budget**: measured 471.8/149.3 KB — still under the existing
  472/152 KB budget (no bump needed), but consumes nearly all of the prior
  ~4.5 KB minified headroom (documented inline in
  `scripts/check-bundle-size.ts` for the next PR).

  ***

  **Round 2 (@sandy re-checkpoint, 2026-07-30)**: her live visual checkpoint on
  the PR's own SHA found four deviations from her explicit directives, not
  visible from source review alone:

  - **Icon color audit**: re-verified the full rule (every `NavbarItem`/
    `NavbarSubmenu` icon is `--text-default-secondary`, with the ONE exception
    that a `NavbarItem`'s own leading icon switches to `--text-default-primary`
    while the ancestor `Navbar` is collapsed — sub-menu icons stay `secondary`
    everywhere, including inside the collapsed flyout) against every render
    path. `NavbarItem.tsx` and `NavbarSubmenuItem`'s own row were already
    correct. Found one real deviation: `NavbarSubmenu.tsx`'s collapsed-flyout
    link-trigger hand-duplicates `NavbarItem`'s icon/label markup (Slot/
    `asChild` cannot inject wrapper markup around an arbitrary child, so this
    branch cannot delegate to a real `NavbarItem` render the way the other
    branches do) — that duplicate had drifted to the expanded-state
    `--text-default-secondary` instead of mirroring a real collapsed
    `NavbarItem`'s `--text-default-primary`. Fixed; new
    `scripts/lib/navbarsubmenu-icon-color.test.ts` (11 tests) locks in the full
    rule AND proves true cross-component hex parity with `NavbarItem`'s own
    collapsed icon in both modes. Two new `contrastPairs` entries added to
    `NavbarSubmenu.meta.ts` (the fix introduced a `text-default-primary` class
    literal in that file for the first time, which `pnpm check:contrast`'s
    per-component coverage rule correctly flagged as uncovered).
  - **ProductSwitcher chevron color**: the chevron `IconButton` had an explicit
    className override neutralizing its own `tertiary`-variant brand-blue
    treatment, rendering it as a neutral gray button instead of the intended
    small/tertiary `IconButton` it already was semantically. Override removed;
    new `scripts/lib/product-switcher-chevron-color.test.ts` (14 tests) extracts
    both this component's chevron classes AND `IconButton.tsx`'s live
    `compoundVariants` entry via AST (not hand-copied), so the assertion can
    never silently drift from the variant it's supposed to match.
  - **ProductSwitcher dropdown row height**: re-measured live (Playwright,
    against the running docs server on the pre-round-2 SHA) — all four dropdown
    rows render at exactly 36px/`h-9`. No deviation found; no code change;
    confirmation only, now documented in `ProductSwitcher.rfc.md` §3.3.
  - **ProductSwitcher hover treatment**: replaced the dropdown item's opaque
    `hover:bg-elevation-default` token-swap with a translucent
    `hover:bg-elevation-default-transparency` (new token,
    `color-mix(in srgb, var(--bg-elevation-default) 20%, transparent)` — the
    repo's existing opacity convention, e.g. `from-fade-overlay`, never a bare
    Tailwind `/NN` modifier or a hardcoded hex). Trial value at @sandy's
    request, subject to her re-checkpoint adjusting the percentage.
    `check:contrast`'s own composited-backdrop simplification (always
    `--bg-elevation-default`, regardless of a component's real ambient
    background) makes its reported ratio for this token mathematically
    identical to the pre-fix opaque number (dark 17.38:1/light 15.72:1) by
    coincidence, not by omission — so `product-switcher-dropdown-visuals.test.ts`
    gained a new `describe` block computing the TRUE composited-over-highlight
    ratio directly (dark 14.98:1/light 14.30:1), both comfortably above the 3:1
    UI-component threshold. No WCAG pair failed; no allowlist/alternate-token
    escalation needed.

  RFC amendments this round (false-then-true corrections, not new proposals —
  the RFC text was already right, the code had drifted from it):
  `ProductSwitcher.rfc.md` §3.3/§3.4/§3.5/§3.6/§5.4; `NavbarSubmenu.rfc.md`
  §5.4 + validation checklist (both had independently claimed the collapsed
  link-trigger "needs no new contrastPairs row" — false once the drifted color
  was corrected); `NavbarItem.rfc.md` §3.6 gains a cross-reference confirming
  its own collapsed-icon rule needed no fix and pointing at where the real bug
  was found.

  **Bundle-size budget, round 2**: measured 472.7/149.6 KB — tips the existing
  472 KB minified budget by 0.7 KB (the new token/utility + class-string swaps,
  no new dependency). Gzip (149.6) stays under 152 KB, unchanged. Minified
  budget raised to 473 KB — a deliberately tight ~0.3 KB headroom, not the
  usual multi-KB style used for whole-new-component bumps — documented inline
  in `scripts/check-bundle-size.ts`, pre-authorized by @sandy conditioned on
  exactly this kind of measured, justified, non-silent raise.

  **Tests, round 2**: 2 new test files
  (`navbarsubmenu-icon-color.test.ts` 11 tests,
  `product-switcher-chevron-color.test.ts` 14 tests) plus updates to
  `product-switcher-dropdown-visuals.test.ts` (+3, now 17) —
  `pnpm test:scripts` 189/189, `pnpm check:contrast` clean (no blocking
  violations, verified via git-stash before/after comparison that the two new
  `NavbarSubmenu.meta.ts` contrastPairs entries are what closed a genuine
  coverage gap introduced by the color fix itself), all other gates re-verified
  green on the final round-2 SHA.

  ***

  **Round 3 (@sandy's 5th re-checkpoint point, 2026-07-31, same PR)**: product
  logos become light/dark theme-flexible. All 5 logos rendered by this PR's
  components (trigger logo + the listed-product logos in ProductSwitcher's
  open menu — opencti/openaev/xtmhub/xtmone/opengrc) previously rendered via
  `<img src="....svg">` against `docs/public/product-logos/*.svg`, files with
  hardcoded hex fills (`#0FBCFF`/`#A47AF0` icon, `#F2F2F3` wordmark). An
  externally-referenced SVG loads in an isolated document with no access to
  the host page's CSS custom properties/classes/`currentColor` — so it could
  never react to a light/dark toggle no matter how its own markup was
  colored; only real inline rendering solves this.

  - **New generator** (`scripts/generate-product-logos.ts`, wired into
    `pnpm generate:artifacts`/`pnpm check:artifacts` exactly like
    `generate-icon-registry.ts`): parses the 5 raw SVGs (asserting each has
    exactly 2 distinct fills — more or fewer fails loudly) and emits a
    committed, drift-checked
    `product-switcher/product-logos.generated.tsx` — one inline component per
    logo, split by the source's own fill into a `fill-highlight` group
    (`--icon-highlight`, aliasing `--color-filigran-brand-primary` — the same
    token the focus ring uses) and a `fill-default` group (`--icon-default`,
    aliasing `--text-default-primary`). Zero hardcoded fill remains in any
    converted asset. `ProductSwitcher.meta.ts`'s `productLogo()` now renders
    this generated `<ProductLogo>` instead of `<img>` — none of its 7 call
    sites needed changes. Raw `docs/public/product-logos/*.svg` sources and
    `docs/app/tokens/page.tsx`'s own raw-asset gallery are unchanged
    (out of scope — not rendered by Navbar/ProductSwitcher, per @sandy's own
    inventory instruction).
  - **RFC amendment**: `ProductSwitcher.rfc.md` §6.2 corrected — logo
    light/dark variants were previously documented as "out of scope for this
    design-system RFC"; now resolved via `fill-highlight`/`fill-default`.
    This was the only written record of the "opencti.svg out of scope" note
    @sandy asked to retire — no separate `process/AI-BACKLOG.md` entry existed
    under that description.
  - **Tests**: new `scripts/lib/product-logos.test.ts` (15 tests) — zero
    residual literal hex fill anywhere in the generated file; per-logo
    icon/wordmark path-count fidelity cross-checked against an independent,
    from-scratch parse of the raw source SVGs (not the generator's own
    logic); an AST-based regression guard (not string search, to avoid a
    false-positive on this file's own explanatory comments) proving
    `ProductSwitcher.meta.ts` never renders a real `<img>` JSX element again;
    and real token-resolution proof (`scripts/lib/theme.ts`, the same engine
    `check-contrast.ts` uses) that `fill-highlight`/`fill-default` resolve to
    exactly `--color-filigran-brand-primary`/`--text-default-primary` in both
    modes. `pnpm test:scripts` 204/204.
  - **Contrast**: no `contrastPairs` change needed — logos are `aria-hidden`
    (decorative) and none of `ProductSwitcher.meta.ts`'s 5 declared pairs
    reference logo colors. Re-verified via `pnpm check:contrast` (clean, no
    new warnings) per @sandy's standing guardrail.
  - **Bundle-size budget, round 3**: measured 510.6/166.7 KB — a much larger,
    DIFFERENT-in-kind jump than round 2's tiny code-level bump: ~40 KB of
    embedded two-tone vector path data across the 5 full wordmark logos, now
    reachable from `src/index.ts` via the pre-existing, systemic
    `<Name>.meta.ts` public re-export pattern shared by every component in
    this package (confirmed via `docs/lib/component-registry.ts` — not new to
    this PR, and not something this fix's scope could restructure). Real
    inline rendering is the only way to satisfy the light/dark requirement —
    `<img>` and external `<use href="...">` both hit the same cross-document
    CSS-isolation wall. Measured precisely (esbuild, isolated by reverting
    only the generated logo file's contents and re-measuring), documented
    inline in `scripts/check-bundle-size.ts` with the full cause and the
    alternatives considered and rejected (approximating the wordmarks as live
    text sacrifices brand/shape fidelity — not this agent's call; SVGO-style
    path-precision reduction has no precedent in this repo, would only have
    shrunk the jump rather than eliminated the need for one, and risks
    reading as "altering Figma-exported design data"). Minified budget raised
    473→511 KB, gzip 152→167 KB — a deliberately tight ~0.4/0.3 KB headroom
    over the measured numbers, same "measured, not banked" style as round 2;
    the 5 logos are a fixed, closed set, so this is not banked headroom for
    unrelated future work. Flagged prominently to @sandy in the PR report,
    per her standing rule to measure and document rather than silently raise.
  - **Gates**: `pnpm pr:ready` full pipeline green on the final round-3 SHA
    (typecheck, build, test:scripts 204/204, check:artifacts, check:docs,
    format:check, full conformity report — WCAG/contrast/tokens/figma-fidelity/
    bundle-size/axe/keyboard, all PASS), plus `pnpm check:lint` clean.

  ***

  **Round 3 addendum (self-discovered during pre-report verification, before any
  SHA was shown to @sandy)**: re-verifying round 3 with a headless-browser
  Playwright pass (not just source review) surfaced a genuine pre-existing bug
  that source review alone had missed: `NavbarSubmenuItem`'s icon and link text
  rendered `text-default-primary` instead of the required
  `text-default-secondary`, in BOTH the expanded accordion and the collapsed
  flyout — a real deviation from @sandy's round-2 icon-color directive.

  - **Root cause**: `NavbarItem`'s own icon sets its color explicitly (immune
    to this bug), but `NavbarSubmenuItem`'s icon span relies on inherited
    `currentColor` from its `<a>` root — and that inheritance was being
    defeated at the CSS-layer level, not the component level.
    `docs/app/globals.css` had `a { color: inherit; }` (plus the box-sizing/
    html/body resets) written as plain, unlayered CSS. Under CSS Cascade
    Layers rules, an unlayered declaration always wins over any `@layer`-scoped
    rule regardless of selector specificity — so it silently beat Tailwind's
    `.text-default-secondary` utility (declared inside `@layer utilities`) on
    every `<a>` in the docs app.
  - **Fix**: wrapped those resets in `@layer base { ... }`, restoring
    Tailwind's own declared `@layer theme, base, components, utilities;`
    precedence (utilities always wins over base). Also added an explicit
    `text-default-secondary` class directly on `NavbarSubmenuItem`'s icon span
    (belt-and-suspenders, mirroring `NavbarItem`'s own defensive
    explicit-color pattern), so the component no longer depends on a host
    app's cascade-layer hygiene to render correctly.
  - **Tests**: new `scripts/lib/docs-globals-anchor-layer.test.ts` (5 tests,
    structural + real-`@tailwindcss/cli`-compile) permanently guards the
    `@layer base` wrapping; `navbarsubmenu-icon-color.test.ts`'s assertion
    inverted (now requires the explicit class; previously asserted its
    absence) — `pnpm test:scripts` 209/209.
  - **RFC**: `NavbarSubmenu.rfc.md` §3.2/§5.4 corrected (had claimed the icon
    needed no explicit class, relying on inheritance alone).
  - **Tangential finding, NOT fixed in this PR** (flagged to @sandy for a
    separate follow-up ticket): `scripts/lib/icon-gate.ts`'s per-line
    handwritten-`<svg>` regex has a false-negative when a source line ends in
    a bare `<svg` token (Prettier wraps long attribute lists onto following
    lines) — `product-logos.generated.tsx` was passing `check:icons` by this
    accident, not by its documented exemption. Corrected
    `scripts/lib/icon-gate-exceptions.ts` to give it its own explicit, named
    exception entry (`rule: "handwritten-svg"`) instead of relying on the
    stale old exception #4 (which claimed all product logos render via
    `<img>`, no longer true since round 3's inline-SVG conversion). The
    regex robustness gap itself is a repo-wide gate-infrastructure concern
    broader than the Navbar mission's scope, left unfixed here by design.
  - **No bundle-size change** (still 510.6/166.7 KB — this addendum is
    class-string/CSS-layer only, no new markup or dependency). **No version
    bump** (bugfix within the same unreleased 0.2.1 `NavbarSubmenu`
    changeset).

  ***

  **Bundle-size correction after rebasing onto `main`'s Paper component
  (2026-07-31)**: rebasing this branch onto `origin/main` — which had landed
  `feat(paper): add Paper component` (#64, its own 477/154 KB budget) since
  this branch's last measurement — required reconciling the bundle-size
  budget history across both branches (`scripts/check-bundle-size.ts`'s own
  running commentary). The arithmetic estimate made while resolving that
  merge conflict (assuming Paper's isolated delta and this branch's isolated
  delta simply add, since the two touch entirely disjoint files) predicted
  the same 510.6/166.7 KB total either way — that prediction was wrong.
  `pnpm check:bundle-size` on the actual, fully rebased tree measures
  517.2/168.8 KB, +6.2/+1.8 KB over the 511/167 KB this branch had reached on
  its own: esbuild's minifier does not compose independently-measured deltas
  perfectly linearly (module-order-dependent identifier-renaming/scope-
  hoisting effects), so an arithmetic estimate is not a substitute for a real
  measurement on the final tree. Not a tree-shaking regression (Lucide icon
  module count unchanged at 188/300). Budget raised 511/167 → 518/169, a
  deliberately tight ~0.8/0.2 KB headroom over the measured number, same
  "measured, not banked" style as every prior bump — documented inline in
  `scripts/check-bundle-size.ts` rather than silently adjusted.

  ***

  **Round 4 (@sandy re-checkpoint, 2026-07-31, same PR)**: her second live
  visual checkpoint returned two remaining points before her green light.

  - **Collapsed icon rule incompletely applied in the real docs shell**: when
    collapsing the documentation site's own navbar (the dogfooding shell),
    only the "Components" item's icon turned `--text-default-primary`;
    Overview/Tokens/Status stayed `--text-default-secondary`. **Named root
    cause**: `docs/components/DocsNavbar.tsx`'s `TopNavLink` is a THIRD
    `asChild` consumer of `NavbarItem` — after `NavbarSubmenu.tsx`'s
    collapsed link-trigger (round 2) and `NavbarSubmenuItem`'s cascade-layer
    issue (round 3 addendum). Radix's `Slot` merges className/props onto a
    single arbitrary child but cannot inject wrapper markup, so every
    `asChild` consumer must hand-replicate ALL of `NavbarItem`'s internal
    conditional styling — and `TopNavLink`'s hand-authored icon `<span>`
    carried an unconditional, hardcoded `text-default-secondary` that was
    never revisited when workstream 3 introduced the collapsed→primary
    exception. "Components" appeared correct only because it renders through
    `NavbarSubmenu`'s already-fixed trigger path, not through `TopNavLink` —
    i.e. the two code paths differ by whether the item has a submenu, which
    is exactly the case the existing tests did not cover. Fixed by mirroring
    `NavbarItem`'s collapsed ternary; new
    `scripts/lib/docs-navbar-icon-color.test.ts` (9 tests: AST class-list
    extraction, real `@tailwindcss/cli` compile, per-mode token resolution,
    collapsed AND expanded) covers the previously-escaping no-submenu case
    and was verified genuine by git-stash (6 pass/3 fail against the pre-fix
    file). `NavbarItem.rfc.md` §6.4/§3.6 amended to document this as the
    third occurrence of the same `asChild`-replication gap, cross-referencing
    the other two so future consumers audit all three call sites together.
  - **ProductSwitcher menu colors, explicit final directive superseding
    round 2's trial**: menu background stays `bg-elevation-highlight`; the
    dropdown item hover background becomes the literal `bg-input-hover`
    token, abandoning round 2's 20%-opacity
    `bg-elevation-default-transparency` experiment. `--bg-input-hover` is
    pre-existing and is already what `Select.tsx` uses for its own popover's
    `data-[highlighted]` row — the same cross-component-consistency rationale
    @sandy applied to the menu background itself. Verified to resolve in both
    modes (dark `#070d18`, light `#f2f2f3`) via `scripts/lib/theme.ts`, the
    real engine `check-contrast.ts` uses. The now-orphaned
    `--bg-elevation-default-transparency` custom property and its `@utility`
    block were removed from `theme.css` entirely rather than left dead:
    `git diff origin/main` confirms both were introduced by this PR's own
    round 2 and had zero consumers outside ProductSwitcher's files.
    **WCAG recomputed** on the new hover background in both modes, per
    @sandy's standing STOP guardrail: `--text-default-primary` and
    `--icon-default` against `--bg-input-hover` give 17.38:1 (dark) /
    15.72:1 (light) — comfortably above both the 4.5:1 text and 3:1
    UI-component thresholds. No pair failed; no allowlist entry or
    alternate-token escalation needed. A new "external-link icon, hover"
    `contrastPairs` entry was added alongside the updated "dropdown item,
    hover" one. Note that these two numbers coincide exactly with round 2's
    reported figures: `--bg-input-hover` (→ `--bg-elevation-heading` →
    `--bg-elevation-heading-layer-0`) and `--bg-elevation-default` (→
    `--bg-elevation-default-layer-0`) resolve to the identical hex per mode
    through different alias chains — a genuine coincidence, and the round-2
    composited-ratio `describe` block is simplified away since the new token
    is fully opaque. `ProductSwitcher.rfc.md` §3.4/§3.5/§3.6/§5.4 and
    `ProductSwitcher.figma.json` (`expectedClasses`, `_dropdownNote`) updated
    to document the round-3 directive as superseding round 2's trial.
  - **Bundle-size, round 4**: 518.4/169.2 KB measured, budget raised
    518/169 → 519/170. Round 4's own changes are bundle-neutral (class-string
    swaps, a docs-app file outside the package entry, tests, RFC prose — and
    they REMOVE a theme.css custom property plus its `@utility`). The +1.2/
    +0.4 KB overshoot is entirely upstream's: this branch was rebased a second
    time onto `origin/main`, which had meanwhile landed `fix(tokens): WCAG 2.1
AA contrast remediation for interactive components (button, icon-button)`
    (#62). Attribution was measured, not assumed — `pnpm check:bundle-size` in
    a throwaway worktree reads 473.8/150.1 KB at #62's parent and 475.0/150.5
    KB at #62 itself, an isolated +1.2/+0.4 KB that matches this branch's own
    movement across the same rebase (517.2/168.8 → 518.4/169.2) exactly. Not a
    tree-shaking regression (Lucide module count unchanged at 188/300).
    Deliberately tight ~0.6/0.8 KB headroom, documented inline in
    `scripts/check-bundle-size.ts`, pre-authorized by @sandy for exactly this
    kind of measured, non-silent raise.
  - **Second rebase onto `origin/main` (#62), round 4**: that upstream
    remediation retargets `--color-filigran-brand-primary` from `--blue-500`
    to `--blue-400`, changing the dark-mode brand blue from `#0fbcff` to
    `#42caff`. `product-switcher-chevron-color.test.ts` pinned the old hex and
    correctly went red — the expected value was updated (light mode was
    unaffected at `#0015a8`) with the reason recorded inline; the assertion
    keeps its purpose, since an accidental swap back to a neutral token still
    fails it. All contrast pairs were recomputed on the new value per the
    standing guardrail: ProductSwitcher's trigger focus ring reads 10.30:1 /
    9.65:1 (dark) and 11.22:1 / 12.55:1 (light), NavbarItem's selected border
    and focus ring likewise — every pair still passes, no STOP triggered. The
    rebase also brought main's own new `scripts/lib/gradient-default-angle.test.ts`,
    which `package.json`'s `test:scripts` now runs alongside this branch's
    `navbar-gradient-mode.test.ts`; the two overlap on the 90deg angle
    assertion by design (independent guards from independent PRs), so both are
    kept. `pnpm test:scripts` 223/223.
  - **Tests, round 4**: `product-switcher-dropdown-visuals.test.ts` rewritten
    for the literal-token approach (19 tests, verified genuine by git-stash:
    16 pass/3 fail pre-fix) plus the new `docs-navbar-icon-color.test.ts` —
    `pnpm test:scripts` 220/220, all other gates re-verified green on the
    final round-4 SHA.

  ### Round 5 — @sandy re-checkpoint (2026-07-30), three ProductSwitcher findings
  - **Product logos rendered nothing in the `Navbar` docs demo (tab 1).** Named cause: `Navbar.meta.ts`
    hosts a second, separately-authored `ProductSwitcher` demo that the round-3 logo conversion never
    migrated — that round changed only `ProductSwitcher.meta.ts`'s call sites, and its AST guard only
    asserted that _that_ file never renders `<img>`. `Navbar.meta.ts` still passed 24×24 `custom/*`
    registry glyphs into 126px logo slots. Verified against `origin/main` that this predates the
    mission: **not a regression introduced by the round-4 logo work**, but a gap the conversion should
    have closed, made conspicuous now that the two tabs of the same page disagree. Fixed by rendering
    real `ProductLogo` wordmarks, and guarded by three new AST tests in `product-logos.test.ts` so the
    two demos cannot drift apart again.
  - **The XTM Hub logo drew nothing in the option list.** Named cause: `scripts/generate-product-logos.ts`
    read SVG attributes with an unanchored `` `${name}="([^"]*)"` `` pattern. For the single-letter `d`
    attribute this also matches the `d="` that ends `id="`, so Figma's exported layer names were
    captured as path geometry (`<path d="Symbol">`, `<path d="vector">`). Only `xtmhub.svg` carried
    such ids; exactly 2 paths were affected. The output was well-formed, correctly-tokenised markup
    that simply drew nothing — which is precisely why every existing gate stayed green, including
    round 3's "no residual literal hex fill" guard (a bogus `d` carries no fill) and the per-fill
    path-**count** fidelity check (the counts were right; only the values were wrong). Fixed by
    anchoring the pattern with `(?:^|\s)` and adding a hard validation that rejects any `d` value not
    beginning with a moveto command, so this class of silent capture now fails the generator loudly.
    Guarded by new value-level tests: every generated `d` must be real path data, must appear verbatim
    in the raw source, and both the icon and wordmark groups of every logo must carry at least one
    real path.
  - **The trigger chevron was not vertically centred.** Answered with proof first, as asked: it **is**
    the real library `IconButton` (`ProductSwitcher.tsx` imports it from `../icon-button` and renders
    `<IconButton size="sm" priority="tertiary">`), not a styled imitation. Measured on the running docs
    site: a plain `IconButton` leaves exactly 4.00px above and below its icon; the ProductSwitcher
    chevron measured 5.88 above / 2.13 below — 1.88px low — with horizontal spacing correct at 4/4.
    Named cause: `IconButton` renders its icon slot as `<span class="inline-flex shrink-0">`, and
    ProductSwitcher passes its own rotation wrapper `<span>` with no display class; as a flex item that
    wrapper blockifies to `display:block`, re-introducing baseline layout for the `display:inline-block`
    `<Icon>` inside a 24px line box. **Scope: local usage, not the shared component** — `IconButton`'s
    own rendering is exactly centred, so no out-of-scope STOP was warranted. Fixed with the
    `inline-flex items-center justify-center` idiom already documented in `Tabs.tsx` for the identical
    PR #61 finding. Re-measured after the fix: 4.00/4.00 in both modes.
  - Verified empirically in both modes on the running docs site: three 126×28 wordmarks on the `Navbar`
    Variants tab, the 126px trigger plus both 100px option logos on the `ProductSwitcher` tab with XTM
    Hub's icon and wordmark both present, and light-mode fills resolving to the brand blue
    `rgb(0, 21, 168)` for the icon and `rgb(24, 25, 27)` for the wordmark.
  - No token changed in this round, so no contrast pair moved; `check:contrast` re-run regardless.
  - **Bundle budget raised 519 → 523 KB minified / 170 → 172 KB gzip**, measured and justified inline
    in `scripts/check-bundle-size.ts` (@sandy pre-authorised, on condition it is never silent). Fully
    attributed: XTM Hub's two real path-data strings are 1043 + 2345 characters against the 6 + 6
    (`"Symbol"` / `"vector"`) they replace — exactly 3376 raw bytes, 3.30 KB, matching the observed
    minified delta to the tenth of a kilobyte. Path data is an opaque string literal that minification
    cannot shrink. This is simply the weight of a logo that renders instead of one that does not.

- dd40ac4: `NavbarSubmenu`: add an additive `active` prop to make the group's
  section-active state (the trigger's `aria-current="page"`) explicit.

  The trigger already derives that state by inspecting its `NavbarSubmenuItem`
  children for `aria-current="page"` — but that inspection only reaches a direct
  child or one `asChild`/router-`Link` level deep. A consumer that wraps each row
  in its own component sets `aria-current` _inside_ that wrapper, invisible to the
  inspection, so the collapsed rail lost the section-active accent showing which
  top-level section the current page belongs to. `active` lets such consumers
  declare it directly; when provided it takes precedence over the derived value.
  Additive, optional, non-breaking: omit it and the existing derivation is
  unchanged.

- 2200155: feat(navbar-submenu): add collapsed-mode href/to for a directly navigable trigger

  New optional `href`/`to` props on `NavbarSubmenu` (mutually exclusive,
  `href` wins with a dev-only `console.warn` if both are set — same
  precedent as `ProductSwitcher`'s `href`/`to`). Additive, non-breaking:
  existing consumers who never pass either prop see zero behavior change.

  Grounded in a real product pattern, re-verified before implementation:
  openaev's `MenuItemGroup.tsx` (`component={Link} to={item.path}` only
  while collapsed) and opencti's own equivalent
  (`LeftBarItem.tsx`/`LeftBar.jsx`, imperative `navigate()` variant).

  - **Collapsed mode**: when `href`/`to` is set, the trigger becomes a real,
    directly navigable `<a>` (hand-composed inside `NavbarItem asChild`, same
    constraint as `NavbarSubmenuItem`'s own `asChild` branch — Slot can't
    inject wrapper markup around an arbitrary child) IN ADDITION to still
    working as the flyout trigger: hover/focus opens the flyout exactly as
    before, `ArrowDown` still opens it for keyboard browsing, `Escape` still
    closes it and returns focus to the trigger. Clicking or pressing `Enter`
    navigates without also toggling the flyout open/closed — verified against
    the compiled Radix source (not assumed): a `pointerdown`-armed suppression
    ref swallows the toggle side effect from `@radix-ui/react-slot`'s
    unconditional child-then-slot handler merge, and a keydown handler on
    `DropdownMenuPrimitive.Trigger` itself `preventDefault()`s `Enter` (which
    Radix's own `composeEventHandlers` DOES respect at that level) then
    replays navigation via a synthetic `.click()`.
  - **Expanded mode**: entirely unaffected — `href`/`to` are ignored there,
    the trigger stays a pure accordion toggle exactly as before this change.
  - No new visual state: the link reuses the exact same `NavbarItem`
    icon/label/focus-ring markup as the existing collapsed trigger, so no new
    `contrastPairs` entry is needed.

  **Docs/RFC**: `NavbarSubmenu.rfc.md` amended (§4.1 interface, §4.2
  justification, §4.3 composition, §5.2 keyboard, §5.4 contrast, §6.3 usage,
  §7 out-of-scope, §8 checklist); `NavbarSubmenu.meta.ts` updated (`props`,
  a new collapsed-mode-with-`href` demo section, a new example, accessibility
  notes) — version bumped 0.1.0→0.2.0.

  **Tests**: 11 new tests in `NavbarSubmenu.keyboard.test.tsx` covering both
  the collapsed-with-link and expanded-with-link-ignored matrices (link
  role/href/aria-haspopup/aria-expanded, `to` alias, href/to priority + dev
  warning, `aria-current` preservation, icon rendering, Enter-navigates-
  without-opening, ArrowDown-still-opens, Escape-still-closes, hover-opens,
  click-never-closes-across-separate-clicks, expanded-mode-href-ignored).

  **Bundle-size budget**: this feature's own real cost, measured before/after
  on the actual tree (clean `origin/main` vs. this branch, `pnpm
check:bundle-size`, at the time this PR was first opened), was +3.0 KB
  minified / +0.7 KB gzip (368.5→371.5 KB / 116.8→117.5 KB) — no new
  dependency, pure added logic + one new JSX branch. On its own, this
  feature's budget was bumped 370→375 KB minified (gzip unchanged at 119 KB).

  **Update after rebasing onto `main`**: `main` had independently merged the
  Tabs badge/activationMode work in the meantime (its own budget bump to
  377/121 KB). Rebasing combines both deltas in the same tree — re-measured
  directly on the rebased tree rather than summed from the two isolated
  deltas: 377.5 KB minified / 119.4 KB gzip, above both branches' prior
  budgets in at least one dimension. The reconciled budget is now **378/120
  KB** (`scripts/check-bundle-size.ts`), documented inline with both
  features' rationale plus this rebase re-measurement — same
  "tight-not-generous" margin style as prior bumps.

- dd40ac4: `NavbarTitle`: add an additive `as` prop to make the section label's semantic
  element configurable, and compose `Text` for its typography.

  The default is unchanged — `NavbarTitle` still renders an `<h2>`, so the shipped
  contract and its tests are preserved (no breaking change). Consumers that mount
  the `Navbar` as page chrome _ahead of_ the main content's own `<h1>` (a docs or
  app shell) can now pass `as="p"` (or `"div"`/`"span"`) so the rail's label does
  not inject an out-of-order heading before that `<h1>` (WCAG 1.3.1 heading
  order); heading hosts may pass `"h2".."h6"` to slot the title into their outline
  at the right depth. The prop is purely semantic: the visual style (Content/
  caption typography, `--text-default-disabled`) and its contrast pairs are
  identical whatever the element, because the label now composes `Text` rather
  than restating the token classes.

- 5880796: feat(product-switcher): adopt Menu for the product dropdown, and reconcile the Menu spec

  `ProductSwitcher` no longer owns a dropdown. It renders `Menu`,
  `MenuContent`, `MenuItem` and `MenuSeparator`, and no longer imports
  `@radix-ui/react-dropdown-menu` at all. Deleted outright: the private
  `productSwitcherItemClass` row, the panel's own class list, and the private
  separator. This is the follow-up PR that `Menu.rfc.md` §7 deferred (Q7,
  option C), executed on option B — it adopts Menu's values rather than
  keeping its own by override.

  **Visible change, checkpointed before merge.** Of 28 properties measured
  before and after in both modes, 21 are unchanged: the private panel was
  already a faithful copy of the same surface, which is why owning two of them
  was duplication rather than differentiation. What moves:

  - row padding-right 8px → 16px. **Neither the row height nor the label
    typography moves**, and both of those were withdrawn against the node
    rather than against a preference. The height shipped as 36px → 32px because
    Menu's 32px had been read off a stale Figma composition, while the
    component set — and this component's own node — are both 36px; Menu is now
    `min-h-9`. The label shipped as 14px → 12px because Menu's row sat on the
    compact ramp; the design has since put the `MenuItem` label on
    `Content/base`, so Menu is now `content-base` and the label renders at the
    size it always did
  - panel min-width 192px → 200px, plus a new 300px cap and a viewport-bounded
    max-height, so a long product list scrolls instead of overflowing
  - the divider's margin 2px → 4px per side — a fidelity correction that was
    owed regardless of this adoption (the old value was a hand-mapping of a
    superseded Figma file; the current one binds `--spacing-1` explicitly)
  - the group header band 24px → 32px, following the same node re-read
  - a disabled row is painted with the disabled tokens instead of `opacity-60`,
    which used to fade the product logo itself

  Three things get strictly better. The row highlight now fires on **keyboard**
  navigation, not only the mouse — it was a `hover:` variant, so arrowing
  through the product list highlighted nothing. The panel is bounded. The focus
  ring no longer gets clipped by the neighbouring row.

  The 100px product wordmark passes through `MenuItem`'s `startIcon` with its
  colour explicitly pinned: unpinned, an asset would inherit Menu's icon-slot
  colour _and change colour under the cursor_. Pinned, it renders the identical
  hex it rendered before the migration, in both modes.

  **Menu spec reconciliation.** A complete, independently written Menu kit
  (RFC, public surface, meta) was contributed by @fimow, produced without
  knowledge that the component had just shipped. Confronting it with the
  delivered component surfaced that the Figma itself had been extended after
  the build — closing three gaps the RFC had logged as open. The separator's
  token was ratified and its spacing settled at the invented 4px after a pass
  at 8px; the panel shadow converged with zero code change, the implemented
  value having been exactly right. Two new gaps are recorded rather than invented: no open-state token
  for a row owning a sub-menu (the designed value is a literal alias of the
  panel's own fill, so it would render an invisible highlight), and no
  destructive tone for a menu row. Full accounting, with credit, in
  `Menu.rfc.md` §10.

  No API change to either component: no prop added, removed or renamed on
  `ProductSwitcher` or `Menu` itself. (The new `MenuSub`, `MenuSubTrigger` and
  `MenuSubContent` exports are a separate, additive surface, unrelated to this
  adoption and covered by their own changeset, `menu-submenus.md`.)

- 3442003: feat(product-switcher): let the trigger logo carry a home destination

  New optional `logoHref`/`logoTo` (+ `logoLabel`) on `ProductSwitcher`. The
  trigger logo becomes a real anchor and the chevron `IconButton` stays the
  sole menu trigger. Additive and opt-in, non-breaking: consumers who pass
  none of the three see zero behavior change and zero visual change.

  One thing in this round is NOT opt-in, and is a fix rather than a feature:
  inside a **collapsed** `Navbar` the logo slot changes for everybody (see
  `logoCollapsed` below). Consumers rendering a collapsible `Navbar` will see
  the collapsed rail render a 28px mark slot instead of the 126px wordmark
  slot that overflowed it, and will get a dev-only warning until they pass
  `logoCollapsed`. Expanded rendering is untouched in every configuration.

  Naming and mutual-exclusion semantics are copied verbatim from
  `NavbarSubmenu`'s own `href`/`to` pair (the exact in-library precedent),
  with a `logo` prefix because `ProductSwitcherOption` already owns unprefixed
  `href`/`to` with a **different** meaning — a sibling product, opened in a
  new tab. `logoHref`/`logoTo` point at the product's OWN home page: same tab,
  no `target="_blank"`, no external-link affordance.

  Grounded in a real product pattern, re-read before implementing: openaev's
  `LeftBarHeader.tsx` wraps the logo in `<Link to="/admin">` and renders the
  chevron `IconButton` + popover only when `navOpen`; opencti's does the same
  with `<Box component={Link}>`. The library modeled the whole trigger as the
  menu opener, so no product could express that split.

  - **Expanded mode**: the logo is a native `<a href>` placed before the
    chevron — two tab stops in reading order, each with its own accessible
    name. Nothing intercepts its click, so Ctrl/Cmd/middle-click keep the
    browser's native open-in-new-tab, along with "copy link address" and the
    status-bar preview. It is deliberately NOT a Radix `asChild` trigger and
    NOT an `onClick` prop: either would have re-introduced exactly the click
    interception `NavbarSubmenu`'s own link trigger had to work around.
  - **Collapsed mode** is destination-dependent (arbitrated by @sandy).
    WITH a destination, the collapsed logo IS the home link and the product
    menu is not reachable until the rail is expanded — no `DropdownMenu` is
    mounted at all, so nothing announces a menu that cannot be opened, and
    the announced name is the destination rather than the menu. That is
    iso-products (openaev renders its chevron only when `navOpen`: you expand
    the rail to switch product). WITHOUT either prop, both collapse states
    are strictly unchanged.
  - **Collapsed rendering, `logoCollapsed`** (same round, found at @sandy's
    visual checkpoint): the collapsed rail is 48px wide but the trigger's logo
    slot is a 126px wordmark, so the collapsed switcher rendered a logo bleeding
    out of the rail. **This predates this branch**: the collapsed branch comes
    from PR #43 (`7ea6c51`, 2026-07-24), where the slot had no fixed width and
    the demo used a mark-only glyph; PR #65 (`e7a8ab4`, 2026-07-31, current
    `origin/main`) added both the Figma-measured `w-[126px]` and the real
    wordmark demo assets — and it is #65's own `Navbar` "Collapsed" demo that
    has been showing the overflow since. New optional `logoCollapsed`
    (`ReactNode`) is rendered in place of `logo` while collapsed, in BOTH
    collapsed branches: without a destination the icon stays the menu trigger,
    with `logoHref`/`logoTo` the icon is the home link. Products already own the
    asset pair (`theme.logo` / `theme.logo_collapsed`), so this is their
    existing split, not a new concept. The slot is a 28px square (`h-7`, the
    same Figma-measured logo height as expanded, mirrored by `w-7` — plain
    spacing multiples, no new arbitrary value). Omitting it while collapsed
    falls back to `logo` **clipped** to the slot, left-aligned so Filigran's
    mark-then-text wordmarks still show their mark, plus a dev-only warning:
    a bounded degradation instead of an empty rail or an overflow. The library
    deliberately never crops the wordmark automatically as the designed path —
    only the consumer knows where its mark ends. `logoCollapsed` is
    `aria-hidden` exactly like `logo`, so no accessible name changes.
  - **Accessible name**: `logoLabel` is optional at the type level but MUST
    be passed, localized, whenever a destination is set — the logo is
    `aria-hidden`, so it is the link's only name. Omitting it falls back to
    `label` (which names the MENU, leaving the two adjacent controls
    announced identically) and emits a dev-only `console.warn` naming the
    fix. Warn-with-fallback, never throw — the same convention this component
    already uses for the `href`+`to` violation.
  - **Type-surface widening, flagged rather than silent**: `ref` goes from
    `HTMLButtonElement` to the `HTMLElement` common supertype, narrowed per
    branch exactly like `Chip`'s polymorphic root. The forwarded element is
    the chevron `<button>` in every configuration except
    collapsed-with-destination, where it is the logo `<a>`. Both object refs
    and callback refs are unaffected at the type level — `RefObject`'s
    `current` and `RefCallback`'s parameter are both checked leniently by
    `@types/react` (the documented `bivarianceHack`), so a consumer holding
    `useRef<HTMLButtonElement>(null)` or a callback typed
    `(el: HTMLButtonElement | null) => void` still compiles unchanged under
    `strict`. What DOES change is what the ref may point at: in the
    collapsed-with-destination configuration it now holds an
    `HTMLAnchorElement`, so any code narrowing it to a button must guard.
  - **No new visual state and no new `contrastPairs` entry**: the anchor adds
    layout classes plus the library's standard focus ring — a state the logo
    simply did not have before, being non-focusable — and no resting or hover
    treatment at all. Its ring sits on the same ambient `Navbar` gradient as
    the two already-declared `trigger focus ring` stops.

  **Docs/RFC**: `ProductSwitcher.rfc.md` amended (§1 summary, §3.6 the two new
  Figma-gap rows including the arbitrated collapsed branch, §4.1 interface,
  §4.2 justification incl. the two rejected alternatives, §4.3 composition and
  the `ref` consequence, §5.1 semantics, §5.3 the two-tab-stop model and the
  `logoLabel` contract, §6.3 usage rules, §7 out-of-scope, §8 checklist).
  §3.6 also dates and attributes the collapsed-logo defect and records the
  `logoCollapsed` resolution, §4.2 the rejected auto-crop alternative.
  `ProductSwitcher.meta.ts` updated (`props`, a new example, a new
  logo-with-destination demo section, a new side-by-side collapsed demo
  showing both branches, accessibility notes) — version bumped 0.2.0→0.3.0.
  Both collapsed demos, and `Navbar.meta.ts`'s own `demoHeader` (the one that
  carried the visible defect), now pass a mark-only `logoCollapsed`.

  **Tests**: 24 new tests in `ProductSwitcher.keyboard.test.tsx` — two tab
  stops in order and a single tab stop when unset, logo click does not open
  the menu, Ctrl-click left to the browser in both collapse modes, `logoTo`
  alias, collapsed with and without a destination, `ref` forwarding to both
  branch elements, `logoHref`-wins and missing-`logoLabel` warnings, silence
  in the clean configurations, and the `process`-undefined bare-runtime guard. Plus, for `logoCollapsed`:
  the icon replacing the wordmark in each collapsed branch, being ignored while
  expanded, and the fallback-with-warning and its clipping slot classes. The
  five pre-existing collapsed tests were updated to pass the prop, which is
  what a collapsible-`Navbar` consumer must now do.

  Plus four tests pinning the **rest-prop contract as one across the three
  rendered branches** (`id`, `data-*`, a forwarded handler, and `logoLabel`
  still winning over a caller-supplied `aria-label`): the
  collapsed-with-destination `<a>` was returning without `{...props}` at all,
  silently dropping them in that branch only while the two menu-trigger
  branches forwarded them. Reported by the Copilot review, reproduced red
  before the fix.

  **Also fixes two documentation imprecisions on this component** reported by
  the PR #65 review (documentation-only — no `contrastPairs`, class or gate
  verdict changes):

  - `ProductSwitcher.meta.ts` cited hand-written DARK focus-ring ratios of
    `8.94:1`/`8.38:1`, **below** the gate's own computed values. Re-read
    directly from `pnpm check:contrast`: `#42caff on #070d18` = **10.30:1**
    and `#42caff on #0c1527` = **9.65:1**. The light figures (11.22:1 /
    12.55:1) were already correct.
  - `ProductSwitcher.rfc.md` §5.4 still carried ONE un-split `trigger focus
ring` row (naming `--bg-elevation-default`, a token the gate does not
    evaluate for this component) long after `contrastPairs` had been split
    into `(stop 1)`/`(stop 2)`, one per `Navbar` gradient stop. Replaced by
    the two real rows with the real gate-computed ratios.

  **Bundle-size budget**: measured on this branch against a clean
  `origin/main` (same machine, same run): 541.0→544.6 KB minified /
  174.9→176.0 KB gzip, i.e. **+3.6 KB minified / +1.1 KB gzip**. No new
  dependency; the Lucide module count is unchanged (188/300), so this is not a
  tree-shaking regression. Split by re-measuring the new component against the
  old `ProductSwitcher.meta.ts`: the component code itself is +0.7/+0.3 (one
  JSX branch, one early return, two dev-only warnings — enough on its own to
  exceed the previous 0.1 KB gzip headroom), and +2.9/+0.8 is
  `ProductSwitcher.meta.ts`, which every `<Name>.meta.ts` re-export in
  `src/index.ts` genuinely ships: prop docs, accessibility notes, a new example
  and the two new demo sections. Already trimmed once (-0.7/-0.2: condensed
  notes, both collapsed demos built from one shared factory); the demos were
  kept deliberately, being what the visual checkpoint verifies. Budget raised
  542→545 / 175→177 in `scripts/check-bundle-size.ts`, documented inline with
  these figures — explicitly authorized by @sandy after being shown them and
  the alternative of cutting the collapsed demo, not silently raised.

  The `logoCollapsed` round was measured the same way against this branch's
  own previous commit: 544.6→545.8 KB minified / 176.0→176.4 KB gzip
  (+1.2/+0.4), split into +0.6/+0.2 of component code (the fix itself: one
  prop, the shared collapsed slot, a third dev-only warning) and +0.6/+0.2 of
  `.meta.ts` (prop doc plus `logoCollapsed` in the three demos that render a
  collapsed rail), after one more prose trim (-0.3 KB minified). Gzip stays
  under its 177 budget, so only the minified ceiling moves, 545→547 — again
  measured, documented inline and explicitly authorized.

- 0ba64ab: **`ProgressBar` gains a `tone` axis: `"default" | "success" | "error"`.**

  Additive and opt-in. `tone` defaults to `"default"`, which renders exactly the
  bar that shipped in #115 — same track, same fill, same classes. Every existing
  call site is byte-identical and needs no change; a test asserts that rather
  than the changeset merely claiming it.

  **Why it exists.** openaev's bulk-operations panel
  (`BulkOperationsIndicator.tsx`) colours its determinate bar by
  `bulk_operation_status` — success when COMPLETED, error when FAILED, the brand
  default while RUNNING. #115's inventory concluded "no product colours a
  progress bar" from checkouts that predated that panel; a re-measure against the
  products' own default branches (opencti `origin/master`, openaev `origin/main`
  `d5b38fbff`) found it. OpenCTI still colours none of its 7 sites.

  **What a consumer should anticipate.** Nothing changes visually unless you pass
  `tone`. When you do, note that the **track changes with it**: the semantic tones
  do not reuse the neutral rail. Against that rail they measure 1.96:1 (success)
  and 1.59:1 (error), under WCAG 1.4.11's 3:1, so each tone takes its own
  30%-alpha companion (`--color-feedback-{tone}-secondary-transparency`, the
  family `Chip` already fills with) and reaches 5.59:1 / 4.46:1 and 4.71:1 /
  4.49:1 dark/light. A `success` bar and a `Slider` therefore no longer draw the
  same trough. No token was added or changed.

  **`tone="warning"` is deliberately absent, and the absence is measured.**
  `--color-feedback-warning-primary` (#e6700f) clears 3:1 against no track token
  in `theme.css` in light mode — 1.07:1 on the neutral rail, 2.51:1 on its own
  transparency companion, 2.81:1 on the best candidate in the file. It sits at
  mid-luminance. Shipping it would be a known accessibility failure; the fix is a
  new token and is a design decision, tracked in `ProgressBar.rfc.md` §9 Q11/Q12.

  **Colour is never the sole cue (WCAG 1.4.1, RULE-04).** `tone` only repeats a
  status the caller is already showing in text and in an icon, exactly as the
  panel does. Nothing about it reaches the accessibility tree.

- e1725cc: feat(progress): add Spinner and ProgressBar, and make Button consume Spinner

  Two new components replacing MUI `CircularProgress` and `LinearProgress`.
  Not opt-in: `Button`'s loading spinner now stops under `prefers-reduced-motion`,
  which it did not before. Arbitration: `Spinner.rfc.md`, `ProgressBar.rfc.md`.

- d6baf45: feat(package): publish to the public npm registry

  `npm install @filigran/design-system` now resolves from the registry, so
  consumers no longer need to pin a commit SHA of this repository. The published
  tarball also carries its Apache-2.0 license text and its changelog. See
  AGENTS.md > "Consumers".

- ea8fed6: feat(radio): add the horizontal orientation from Figma node 7416:23634

  `RadioGroup` accepts `orientation="horizontal"` (default `"vertical"`), laying the
  items on a row with the same 16px gap. Keyboard operability is unchanged in both
  axes: one tab stop, both arrow pairs traverse the group. Reasoning and the two
  open design questions: `Radio.rfc.md` §3.6.

- 83295d9: feat(search-field, button-group): compose ButtonGroup into the header SearchField

  Retires the `_pendingButtonGroup` entry in `SearchField.figma.json`, which had
  deferred this work explicitly rather than inventing a segmented control inside a
  SearchField change. ButtonGroup landed in #160, so the deferral is over.

  Re-read node `2682:8640` at the root. The 10 symbols and every field value are
  unchanged; what changed inside symbol `2682:8639` is the cluster: the three loose
  `buttonGroupItem` instances in a hidden `Frame 607` are gone, replaced by one
  **visible** `buttonGroup` instance (`7333:42499`, 108×36 — three md items).

  `SearchField` gains a `buttonGroup` slot, rendered last. It is composition only:
  the field renders what it is given and restates none of ButtonGroup's styles.
  Filling the slot drops the wrapper's right padding, because in the reference
  header assembly (`6958:19681`) the group spans x 292→400 inside a 400-wide field
  — its right edge _is_ the field's edge. The slot is inert when the field is
  disabled, on the same mechanism as `searchOption`, and SearchField adds no ARIA
  around it, so the field stays one search landmark containing one radiogroup.

  `ButtonGroup` gains a third `corner` value, **`end`**, which rounds the trailing
  edge only. The assembly's items read Corner=Square, Square, Rounded
  left-to-right. This is the mixed shape RFC §9 Q7 had called one "no symbol in
  the node describes" — the assembly describes it, so that reasoning is corrected
  in place. Q7's decision stands: `corner` stays on the container, which is the
  only thing that knows which child is last.

- 56f7e59: feat(slider): add the Min/Max bounds row, per-thumb accessible names, and fix the field anatomy

  Follows the design wave of 2026-08-04, in which the Figma `Slider Field`
  master component gained three properties and its anatomy was re-read in both
  modes across four nodes (`6460:24999`, `6682:24776`, `6706:32547`,
  `6706:33417`). What is bound in Figma is built; what is not is recorded as a
  gap rather than invented.

  **`showBounds` — the Min/Max row** (`hasMinMaxValue`, nodes `6706:28402` and
  `6706:31376`). Full-width row under the track, ends pushed apart,
  `Content/compact` on `--text-default-secondary`, substituting
  `--text-default-disabled` when disabled. Two deliberate departures from the
  Figma defaults, both documented in `Slider.rfc.md` §13.1: it defaults to
  **off** where Figma defaults to on, because turning it on by default would
  silently add a row to every `Slider` already rendered in three products; and
  the row is `aria-hidden`, because Radix already publishes both bounds on
  every thumb through `aria-valuemin` / `aria-valuemax`. `minLabel` and
  `maxLabel` accept real-world bounds ("0 €", "Cold") in place of the raw
  numbers.

  **`thumbLabels` — per-thumb accessible names.** The shipped component was
  probed rather than assumed: a two-element value already renders two
  independently keyboard-operable thumbs, so a range needs no new component.
  One thing was genuinely missing — both thumbs carried the _same_ accessible
  name, so a screen-reader user heard "Price" twice with no way to tell which
  end had focus. `thumbLabels` names each end by index via `aria-labelledby`,
  which yields "Price Minimum" rather than replacing the field name; unnamed
  thumbs fall back to the shared name, so a partial array degrades instead of
  breaking.

  **Anatomy fix (`Slider.rfc.md` §12).** The field is two nested groups, not a
  flat stack: a text group at `--spacing-0` (label row, then help text) and a
  track group at `--spacing-2` (rail, then bounds row), 16px apart. The help
  text therefore sits **above** the track, flush under the label. The previous
  version rendered it below the rail in one flat 8px column. Two tests now
  pin the order and the grouping, each verified red against the previous
  structure. No gate could catch this — `check:figma-fidelity` verifies token
  and class _presence_, never DOM order — which is logged as a repo-scope
  blind spot in `process/AI-BACKLOG.md` with a proposed control.

  **Not shipped, and why.** `displayValue`: the value bubble is drawn but
  exports as a raster with no binding on its fill, radius, padding or pointer,
  so it is deferred to v3 with the exact list of what remains to bind
  (`Slider.rfc.md` §13.3). Its asymmetric default — on for `Slider`, off for
  `Range Slider` — is recorded as a design decision, not an inconsistency: two
  bubbles would overlap near the centre. `valueInLabel`: bound to
  `--text-input-placeholder` for a real, present value, which design confirmed
  is a copy-paste; implementing it as bound would encode a disowned token and
  substituting one would be an invention, so it is logged as GAP-S5.

  `wcagStatus: "pass"`. The two new bounds-text pairs are declared and
  measured, not assumed: 8.99:1 dark / 7.89:1 light, and 9.38:1 / 7.20:1
  when disabled. No new allow-list entry needed for either — both pass
  normally.

  The rail's own light-mode pair (`--color-feedback-neutral-secondary`) is a
  different story, and it **is** in this release. Rebasing onto main during
  Mission 0 pulled in PR #76 (Switch's token export), which had already
  rebound the light value from `--gray-500` to `--gray-400` — unrelated in
  scope to Slider — and this silently dropped the previously-passing `track
rail` pair below 3:1: 2.63:1 against the reference surface, 4.26:1
  against the filled range, 2.74:1 against the disabled filled range. Dark
  mode is unaffected (`--gray-600`, 3.25:1, still declared normally). The
  entry drafted for exactly this scenario in `process/AI-BACKLOG.md` was
  applied once the numbers were re-verified against the rebased tree: the
  `track rail` pair was removed from `Slider.meta.ts`'s declared
  `contrastPairs` in favour of the allowlist entry, and `check:contrast`
  re-run to confirm. `wcagStatus` stays `"pass"` — the control is identified
  by the thumb and the filled range, both well above threshold; the rail is
  a secondary extent cue. Honesty reservation carried into the entry itself:
  this coverage bears on the rail against its surface, not a decorative
  reinforcement like a hover halo — it is a step more engaging than the
  Button/IconButton and Checkbox/Radio precedents it otherwise follows.

  **Documentation page reorganised** (`Slider.rfc.md` §14). Reported by design as
  unreadable: the demos stacked into one unbroken column and only the first two
  groups labelled their examples, so the page showed three fields captioned
  `Confidence / Between 0 and 100` that a reader could not tell apart. The demos
  are now grouped into four intent tabs — Basics, Display options, States, Range
  — with every example carrying a title stating what it demonstrates and the
  name of the prop(s) that produce it. This follows the convention the library's
  other multi-intent components already use (`Tabs`, `Dialog`, `Menu` and
  `Select` all drive `render()` from a `TabsList`) rather than a local invention;
  the flat caption-and-row shape stays right for components with a single axis of
  variation. The `Display options` tab is where the deferred `displayValue`
  bubble will land in v3, so that arrival needs no regrouping. No component code
  changed.

  **Thumb halo aligned on the library's halo width** (`Slider.rfc.md` §15). The
  hover/focus halo goes from `ring-4` to `ring-8`, read back from the Figma nodes
  (`2721:4729`, `2721:4735`) after design widened the ellipse from 24×24 to 32×32
  around the 16px thumb. Framed accurately, **this is not "the halo grows": it is
  the Slider rejoining the value the rest of the library already uses.** `Checkbox`,
  `Radio` and `Switch` all ring their transparency halo at 8, and the Slider was
  the only component ringing at 4 — in the code and in the design file alike. The
  comparison with MUI (measured live on 6.5.0: 8px hover, 8px focus, 14px drag) is
  what surfaced the inconsistency, not what motivates the fix.

  MUI's third, drag-sized halo is deliberately **not** implemented: the help text
  sits 18px above the thumb centre, and a `ring-12` half-extent of 20px would
  overlap it in the one state where attention is on the control. The unblocking
  move is an anatomy change (widening the text-to-track gap), logged for design.

  No contrast ratio moves — the token is untouched, and the halo's 1.17:1 dark /
  1.22:1 light is a property of its 10 % alpha, not of the ring's size. The
  supplemental-coverage entry was reworded only because it quoted the old 24×24
  geometry. `wcagStatus` stays `"pass"`.

  Four tests now pin the halo width, written red against `ring-4` first. Nothing
  had asserted it before: it was guarded only by `check:figma-fidelity`'s declared
  classes, which cannot catch an edit that changes the code and the declaration
  together. A survey found 113 of 153 declared geometry classes across 19
  components (74 %) are in that same position, logged with a proposed control.

- 35a4768: feat(spinner): add a 32px `size="xl"` tier for the ring-around-a-glyph motif

  New `size="xl"` (32px) alongside sm/md/lg. Additive: consumers who never pass
  it see no change. It deliberately exceeds `Icon`'s 16/20/24 vocabulary without
  extending `Icon`. Arbitration: `Spinner.rfc.md` Q10.

- e710971: fix(switch): add off hover halo, correct track/thumb colors, add thumb overflow

  The Figma source (`2686:5152`) changed after the Switch RFC was approved. Four
  corrections; the first three were re-verified live against Figma variable
  bindings on the 8 crossed symbols and green-lit by @fimow on 2026-08-03, the
  fourth landed with the 2026-08-04 tokens export:

  1. **Off (unchecked) hover halo** — Figma `2686:5927` defines a hover state for
     the off value too, which the approved spec shipped as checked-only. The
     unchecked halo now renders, mirroring the checked halo but with a
     mode-adaptive neutral token (`ring-feedback-contrast-secondary` — white@10%
     dark / black@10% light), anchored on Root's `group-hover:` (the Thumb is
     `pointer-events-none`).
  2. **Corrected track/thumb colors** — the #58 build used approximated tokens
     that did not match Figma's bindings: track checked
     `--color-feedback-info-secondary` → `--color-filigran-brand-primary-transparency-50`;
     track unchecked `--bg-elevation-disabled` → `--color-feedback-contrast-primary`;
     thumb unchecked `--icon-default` → `--icon-neutral`, superseded within this
     same change set by the dedicated token in point 4 below. This also resolved 3 of
     the 4 known WCAG 1.4.11 contrast failures (now 1 residual: the translucent
     off-track).
  3. **Thumb overflow** — the thumb Ø (20px, `size-5`) is larger than the visible
     14px track pill, so it protrudes ±3px. Implemented as a transparent 20px Root
     frame + a centred `h-3.5` pill + the overflowing `size-5` thumb.
  4. **Dedicated off-thumb token (additive — this is why the bump is `minor`)** —
     the 2026-08-04 Figma export adds `--color-feedback-neutral-off`
     (Figma `Feedback/Neutral/Off`, dark `--gray-100` / light `--gray-500`), and
     the unchecked thumb binds it via `fill-feedback-neutral-off` instead of
     piggy-backing on `--icon-default`, which diverged in light mode. The same
     export re-maps light `--color-feedback-neutral-secondary` from `--gray-500`
     to `--gray-400`; its only live consumer is Chip's neutral tone, whose three
     light pairs stay green (see `src/tokens/PROVENANCE.md`, 2026-08-04 entry).

  The RFC, `Switch.figma.json`, `Switch.meta.ts`, `Switch.test.tsx` and the
  `wcag-allowlist.json` reason are re-captured/re-audited accordingly. Halos are
  decorative/hover-only (WCAG 2.1 SC 1.4.11 exempt) and non-blocking. These
  changes correct an approved component and require designer re-validation (noted
  in the RFC revision note); status is intentionally not self-promoted.

- d7826f4: TabsTrigger.badge: add color variants, a display cap, and a conditional
  invisible state — always purely decorative (per
  process/TABS-BADGE-COLOR-API-PROPOSAL.md).

  - `badgeColor?: "brand" | "error"` (default `"brand"`, unchanged visual for
    existing consumers) selects the badge's background/text token pair.
    `"error"` uses `bg-alert-error` (`--color-feedback-error-secondary-transparency`),
    contrast-checked at 15.80:1 dark / 11.94:1 light against
    `text-default-primary`.
  - `badgeMax?: number` caps a numeric `badge` value, rendering `` `${badgeMax}+` ``
    once exceeded (e.g. `badge={150} badgeMax={99}` → "99+"); uncapped by
    default. String badges are never capped. `aria-label` reflects the
    displayed (post-cap) value, not the raw count.
  - `badgeInvisible?: boolean` (default `false`) fully omits the badge
    element from the DOM when `true`, instead of hiding it with CSS.

  All three props are ignored when `asChild` is set, exactly like the
  existing `icon`/`badge` props — composing a clickable badge/chip (e.g.
  OpenCTI's `EEChip`) stays out of this component's scope, built via
  `asChild` on the consumer side.

### Patch Changes

- fb8c3cc: fix(breadcrumbs): keep the adornment beside the path

  The list no longer grows, and the current entry's width cap is `max-w-lg`
  (32rem) instead of a fraction of the track. `grow` existed only to give that
  percentage a basis and made the list fill the track, pushing `adornment`
  content to the far end of it. Details: `Breadcrumbs.rfc.md` §6.1.

- bac6c6e: fix(breadcrumbs): give the current entry's width cap a track to resolve against

  The list now grows, so `max-w-2/5` is a fraction of the row instead of a
  fraction of its own content — the current label was truncated even on a
  full-width screen. Narrow-track behaviour is unchanged. Details:
  `Breadcrumbs.rfc.md` §6.1.

- e3001ce: fix(breadcrumbs): apply the narrow-track mechanism in the right direction

  The current entry carried a `flex-shrink` factor of 5, which made it shrink
  five times FASTER than an ancestor — the opposite of the arbitration. It is
  `shrink-0` with the two-fifths cap again, and the ancestors carry the
  shrinking. Retraction and measurements: `Breadcrumbs.rfc.md` §6.1.

- fda6d73: fix(button-group): the selected glyph was painting UNDER its own wash

  The selected segment read as a flat opaque block instead of a veil, and its
  glyph was barely visible. Cause: the wash is an absolutely positioned `before:`
  layer and the glyph span was its static sibling. A positioned element paints
  above a static sibling in the same stacking context, so the 55% veil covered the
  icon.

  The glyph span is now `relative`, which puts it after the pseudo-element in
  paint order. Figma's own Active symbol marks its icon `relative` for the same
  reason (node 2785:16749). A negative z-index on the pseudo-element would not
  work: it would drop the wash behind the item's own background and hide it
  entirely.

  Worth recording because the contrast gate could not catch this: it composites
  declared TOKENS and had the pairs right (3.54:1 state, 3.90:1 glyph), while the
  DOM painted something else. The rendered composites now match the declared
  values in both modes — dark 3.54 / 3.90, light 3.98 / 3.91.

- f86e76e: fix(chip): reduce the EE label to 12px — EE only, no other severity moves

  Sandy reduced the EE chips' font size on Figma node `2752:19169`. `Severity=EE`
  moves from `Content/base-medium` (14px, `--text-3`) to `Content/compact-medium`
  (12px, `--text-2`). **Size only:** the weight stays `--font-weight-medium` (500),
  family, line-height and colour are unchanged, and letter-spacing follows
  `--tracking-normal` at the new size (0.105px → 0.09px), the same relative token
  as before.

  Read at the ROOT of the EE symbol `6929:17860` by both means: `get_variable_defs`
  returns `Content/compact-medium` with `--text-2` = 12 and `--font-weight-medium`
  = 500 and no `--text-3` at all, and `get_design_context` on the same root emits
  `text-[length:var(--text-2,12px)]`, `font-[var(--font-weight-medium,500)]` and
  `tracking-[0.09px]`.

  **EE only, and measured rather than asserted.** The six feedback severities and
  the nine entity tones still bind `Content/base` (14px/400) — re-read at two
  non-EE symbol roots (`2906:6850` neutral, `6590:38679` critical) — and every chip
  the docs site renders was measured in Chrome on the compiled CSS, before and
  after, in both themes: of 1064 measured values across 28 chips, the only ones
  that move belong to the 4 EE chips, and only their font-size (14 → 12px),
  letter-spacing (0.105 → 0.09px), line box (21 → 18px) and resulting label width.
  Every non-EE chip is identical to the digit. Chip height stays 24px on all 28,
  in both themes, and the weight split stays 500 for EE / 400 for the rest.

  **Contrast: no threshold and no ratio moved.** The risk a smaller font carries is
  falling out of WCAG's large-text allowance and having the requirement rise from
  3:1 to 4.5:1. It does not apply here, and not by luck: 14px at weight 500 was
  never large text either — SC 1.4.3 large text starts at 14px **bold** — so the EE
  label pair was already declared and computed at 4.5:1. No colour token changed,
  so the figures are unchanged: `label-ee` **11.89:1** dark / **7.67:1** light,
  `label-ee-hover` 15.66:1 / 14.79:1, all against 4.5:1. `icon-ee` and the focus
  ring are graphical-object / UI-component pairs at 3:1 and are size-independent.

  The 24px height absorbs the smaller line box with more room than before, not
  less: 12px at 150% is 18px against a 24px floor, where 14px gave 21px.

  No API change: `severity="ee"` renders exactly as it did, two pixels smaller.

- da333e7: fix(combobox): scroll the active row into view on the keyboard path

  Arrowing down a list longer than the panel walked past the bottom edge, leaving
  the highlight out of sight. Each keyboard move now scrolls its row into view by
  the minimum and with no animation; a hover moves the highlight, never the list.

- 88a4885: fix(combobox): reset the native input box and size the field as a border box

  Without a host preflight the browser painted a grey inset border inside every
  Combobox and the field rendered 46px for its declared 36px floor. Both classes
  are the ones SearchField already carries.

- 0ef8721: fix(overlay): route the Combobox panel through the `--fds-z-overlay` doctrine

  The Combobox option panel shipped a literal `z-50` and ignored the stacking
  property every other floating surface reads, so a host could not raise it out
  from under its own modal backdrop. Consumer recipe unchanged: README.md
  § "Overlay stacking".

- 9a925c2: Deduplicate the Radix dependency graph: 80.1 KB off the runtime surface, no API
  change.

  The twelve top-level `@radix-ui/*` packages had drifted onto four different
  release generations, and Radix pins its shared internals EXACTLY — 0 of 24
  internal dependencies is declared with a range. Twenty-two internal packages
  were therefore bundled in two to four copies at once (`react-dismissable-layer`
  four times, `react-presence` four, `react-collection` three), for 78.8 KB of
  pure duplication, 18 % of the runtime bundle.

  Six ranges move forward, all within one coherent set: every one of the twelve
  latest versions was published on 2026-07-24 and they pin a single mutually
  consistent set of internals, with zero divergence across the 24 shared packages.

  Measured on real builds — esbuild for the aggregate, and the products' own
  bundler (vite 8 / rolldown) on real `dist` for what a consumer ships:

  |                                        | before   | after    |
  | -------------------------------------- | -------- | -------- |
  | runtime aggregate, minified            | 447.9 KB | 367.8 KB |
  | runtime aggregate, gzip                | 140.7 KB | 113.7 KB |
  | duplicated packages in the bundle      | 22       | 0        |
  | importing five Radix-backed components | 364.7 KB | 304.2 KB |
  | importing every export                 | 600.6 KB | 495.8 KB |

  Components that pull no Radix primitive are unchanged, as expected: `Text` and
  `Paper` stay at 48.8 and 48.3 KB.

  Non-breaking: the runtime and `/meta` export surfaces were diffed name by name
  across both builds — 97 and 39, identical.

- 114854d: fix(combobox, meta): reset the browser defaults left on a list and two demo buttons

  Combobox's selected-values row was a bare `<ul>`: in a host without preflight the
  browser added a marker, a 40px indent and block margins, floating a multiple
  field to 66px against its declared 36px floor. The Badge and Tooltip demos wrote
  bare `<button>` elements and painted a 2px outset border. All three now carry the
  resets the library already uses elsewhere.

- af0deef: Add `--color-feedback-error-secondary-transparency-20`, the hover background for
  destructive secondary and tertiary buttons. One token, three declarations, from the
  2026-08-26 Figma export; nothing else changed.
- 6b5ce1f: Bind the `--icon-*` tokens the Figma nodes bind. Chip's delete control and
  Dialog's close control paint `--icon-default` instead of the brand accent — a
  close/delete glyph is not an accent — and Dialog's close control goes back to
  the node's bare 24×24 geometry. IconButton's tertiary tint, IconButton's
  secondary disabled tint, Slider's range and thumb and Chip's five severity icons
  now name their `--icon-*` token instead of a same-valued alias: no pixel moves.
  ProductSwitcher's spec is re-anchored on the current file's Menu instance.
- 6e659a2: fix(styles): declare a transparent background on Switch, Checkbox and Radio

  The three button-rooted controls PR #70 gave the UA-default treatment to
  without its `bg-transparent` half. In a host with no `<button>` reset — which
  is what `dist/index.css` ships into — their root painted Chromium's
  `buttonface`, measured `rgb(239, 239, 239)`. Switch is the one that showed:
  its translucent track composited over that grey instead of the page.

- 51e7202: fix(cn): stop tailwind-merge from silently dropping custom text-\* classes

  `cn()` used plain `twMerge` with no classGroup config, so tailwind-merge
  didn't recognize this theme's custom `text-*` names and bucketed all of
  them into one conflict group. Combining a typography-size class (e.g.
  `text-content-base`, `text-title-lg`) with a text-color class (e.g.
  `text-default-secondary`) in the same `cn()` call silently dropped one of
  the two. Fixed via `extendTailwindMerge`, registering the size-scale/Named
  Style names under the built-in `font-size` group and the semantic color
  tokens under `text-color`, so both now coexist correctly. Found while
  building Text, whose v1 contract routes all additional styling (most
  commonly a color override) through `className`.

  Also registers the 4 `text-gradient-*` @utility names (`focus`, `warning`,
  `ia`, `default`) under the same `text-color` group — found in review before
  release. They were previously unregistered and happened to fall into
  tailwind-merge's own default color heuristic, which incidentally conflicted
  them correctly against solid semantic colors but wasn't a guaranteed,
  documented outcome. A dedicated `cn.test.ts` now covers the full v1
  variant/className-color combination matrix directly, rather than relying
  on a component test to notice a drop incidentally.

- 51e7202: fix(button,tabs): apply the intended font-weight on decomposed typography classes

  The decomposed typography pattern (`font-<name> text-<name> leading-<name>
tracking-<name>`, used by every component that needs a Named Style without
  the single bundling `@utility <name>` class) only ever resolves the
  `font-<name>` class to theme.css's `font-family` custom property. It never
  applied the sibling `--font-weight-<name>` property the way the composite
  `@utility <name>` block does — confirmed empirically against the compiled
  CSS (`.font-content-button { font-family: var(--font-content-button); }`,
  no `font-weight` declaration at all).

  This silently left `Button`'s label (`content-button`, used unconditionally
  on every button) and `Tabs`' active-tab state (intended "bold text" per the
  code's own pre-existing comment) at the browser/inherited 400 weight
  instead of their intended 600 (semibold). Fixed by adding Tailwind's own
  native `font-semibold` keyword utility alongside the existing family class
  — it maps directly to the same `--font-weight-semibold: 600` token and
  does not touch `font-family`, so both classes coexist without conflict.
  `Tooltip` was audited against the same pattern and confirmed unaffected
  (only uses the regular-weight `content-compact`, no change needed).

  Found and fixed alongside the same gap in the new `Text` component (see the
  `add-text-component` changeset) — `check-figma-fidelity.ts` only verified
  font-size numerically and class-name textual presence, never resolved
  actual CSS, so the gap was invisible to CI (AI-BACKLOG entry added to
  harden the gate).

- b0b12eb: fix(tokens): bump --color-feedback-info-primary from blue-600 to blue-700 in light mode

  Fixes WCAG 2.1 AA focus border contrast (3:1 minimum for UI components).
  The previous value (#009edb / blue-600) achieved only 2.41:1 against
  --bg-input-default (#e4e5e7). The new value (#0079a8 / blue-700) achieves
  3.87:1. This token is transverse — affects all components consuming
  --border-input-focus in light mode.

- ad10875: fix(install): restore installability for git-dependency consumers, and gate it

  `main` could not be installed by **any** package manager since PR #73. That
  PR added `@radix-ui/react-checkbox` and `@radix-ui/react-radio-group` to
  `packages/filigran-design-system/package.json` and `pnpm-lock.yaml`, but not
  to the repo-root `package.json` — the install proxy npm, pnpm and Yarn each
  install as `@filigran/design-system`, because none of them can target a
  subdirectory of a git dependency — and not to `yarn.lock`, whose last
  refresh dated from PR #68. The install-time build therefore resolved against
  a manifest that had never heard of those two packages and died in tsup's
  declaration step with `Cannot find module '@radix-ui/react-checkbox'`.
  Reproduced from a blank external project on all three package managers, and
  bisected: `9cd4271` (PR #74) installs cleanly, `4e2b0bf` (PR #73) is the
  first broken commit.

  The fix mirrors both dependencies into the root manifest and regenerates
  `yarn.lock` with its official command; installs from a blank project are
  green again on Yarn Berry, npm and pnpm, with the package importable and its
  runtime, type and CSS entry points resolvable.

  The reason this reached `main` at all is that no gate consumed the library
  the way a product does — every check ran on the pnpm workspace, which no
  consumer ever sees. Two now do:

  - **`Consumer install proof`**, a step of `ci.yml`'s `build-and-check` job
    (the repository's only required status check), installs the commit under
    test into a blank Yarn Berry project as a git dependency and asserts the
    package builds, imports (CJS and ESM), and exposes usable type and CSS
    entry points. Verified non-vacuous: it is red on `b6855f4` (`main`) and
    green on `9cd4271`.
  - **`pnpm check:manifest-parity`**, part of `pnpm report:conformity`, is its
    offline counterpart: it fails in milliseconds, naming the exact line, when
    the two manifests drift, when `prepare` and `prepack` disagree, or when
    `yarn.lock` no longer matches the root manifest.

  `ci.yml` also stops passing `--frozen-lockfile=false` to `pnpm install`,
  which had disabled pnpm's own lockfile-drift detection.

  No component, token or public API change.

- c16f301: fix(navbar-item): give button-rendered rail rows the pointer cursor

  `NavbarItem` is the single row `Navbar` uses everywhere, and it renders two
  different elements: an `<a>` on the `asChild` path (leaf navigation links) and
  a native `<button>` everywhere else — `Navbar`'s built-in collapse toggle, and
  `NavbarSubmenu`'s trigger in both its expanded (accordion) and collapsed
  (flyout) modes. The row declared no `cursor` of its own, and a browser only
  gives the hand cursor to links (the UA sheet's `cursor: auto` resolves to
  `pointer` over an `<a href>`), never to buttons. The rail was therefore
  inconsistent by construction: link rows had the hand cursor, every
  button-rendered row showed a plain arrow.

  Reported on the OpenAEV pilot as a loss of iso-functionality against the MUI
  navigation being replaced, which set the pointer cursor on every row regardless
  of the element rendered — so this affects any product adopting `Navbar`, not
  just OpenAEV.

  `cursor-pointer` is now declared once on the shared row class, so both render
  paths agree and neither depends on the host's UA sheet. Disabled rows need no
  counterpart: `disabled:pointer-events-none` already makes the pointer ignore
  the row entirely.

  Regression-locked by
  `src/components/navbar-item/NavbarItem.cursor.test.tsx`, which asserts the
  computed `cursor` — not the class name — on all four button-rendered rows,
  against the library CSS compiled at test time from the same entrypoint
  `pnpm build` uses. Products ship no style build of their own, so a class
  present in the source but absent from the compiled stylesheet would fail
  silently in every one of them; the suite also asserts the utility's presence in
  that compiled sheet directly.

- b6855f4: fix(navbar): open the rail's item list flush against the header, removing an invented 8px top inset

  The scrollable content list shipped with the `py-2` shorthand, whose top half
  put 8px of `padding-top` between the header block — a `ProductSwitcher` in
  every product — and the list's first row. Reported on the OpenAEV pilot as the
  first row visibly detaching from the header, and reproduced in Chrome at
  exactly 8.00px in both rail states and both themes (header bottom 68.00px,
  first row top 76.00px).

  Figma binds no inset there, identically in both collapse symbols (`2843:4073`
  open / `2843:5134` close): `productLogo` occupies y=0..68, the `content` frame
  starts at y=68, its `Menu` slot at y=0, and that slot's first `navbar menu
item` at y=0 — first row top = 68px, flush with the header. `Navbar.figma.json`
  now declares that as an explicit `list-padding-top` = `0px` / `--spacing-0`
  pair, the same negative-fact treatment the density pass gave `item-gap`.

  Corrected to `pb-2`: only the top half is removed. The list keeps its 8px
  bottom breathing room and the footer column's own `py-2` is untouched, so the
  foot of the rail does not move; the density pass's own values (zero inter-row
  gap, `my-1` separators, `h-9` + `shrink-0` rows) are equally untouched, so no
  item density changes. Re-measured after the fix: the seam is 0.00px in both
  rail states × both themes, row heights and pitch are byte-identical to before,
  and a short rail overflows 8px less. Guarded on the real compiled CSS by
  `scripts/lib/navbar-list-top-padding.test.ts`.

- 0f3b7c9: fix(tokens): clamp overlay width utilities to the viewport

  Fixes a viewport overflow: a fixed-width overlay (e.g. Dialog size="lg",
  960px) overflowed both sides of the viewport below ~992px, pushing the
  footer action button out of reach. `w-overlay-sm/md/lg/xl` now add
  `max-width: calc(100vw - var(--spacing) * 8)` (32px total safe margin, a
  multiple of Tailwind's native --spacing unit) alongside the unchanged
  `width: var(--width-overlay-*)`. Desktop/wide-viewport behavior is
  unchanged (fixed width, no shrink-with-content); only narrow viewports
  now fall back to the viewport-relative cap.

  Note for implementers: this intentionally uses two declarations
  (`width` + `max-width`), not a single `width: min(var(...), calc(...))`.
  Every `--width-overlay-*` token lives in the `--width-*` Tailwind v4
  `@theme` namespace, so Tailwind's core width plugin also auto-generates
  its own bare `.w-overlay-{size} { width: var(--width-overlay-{size}); }`
  for each size — verified (real `@tailwindcss/cli` compile) to be emitted
  after this file's own `@utility` rule and to win the `width` property in
  the cascade, silently making a `min()`-in-`width` form inert. `max-width`
  sidesteps this since Tailwind's namespace-derived utility never sets it.
  See theme.css's `@utility w-overlay-*` block comment and PROVENANCE.md
  (2026-07-27 entry) for the full account.

  No token values changed (see `pnpm diff:tokens`); only `@utility` bodies.

- 5e1b83b: fix(cursor): declare the pointer cursor on the shared interactive layers

  Every interactive surface now paints the hand cursor in a host without
  preflight, where buttons showed an arrow. `SelectItem` gains it (RULE-11);
  the `Slider` track takes `pointer`, its thumb `grab`/`grabbing` (§3.3).

- 0837403: fix(search-field): render the leading magnifier at 16px

  The `md` field's leading search icon shipped at 24×24, which reads as
  oversized inside its 36px box — two thirds of the field's height, outweighing
  the 14px placeholder beside it. It now renders at 16px (`size-4`) in both
  sizes, matching what `sm` already did.

  Visual only: the field's height (`h-9` / `h-7`), its `items-center` vertical
  centering, and Figma's 8px icon→text spacing (`gap-2`) are unchanged. The
  placeholder consequently starts 8px further left, exactly as in `sm`. The
  clear cross is untouched. Recorded in `SearchField.rfc.md` §9, decision D6.

- 179ee2e: fix(tokens): correct systemic line-height and letter-spacing drift at the generator level

  Every Named Style now renders the typography Figma actually declares: a
  **150% line box** and a letter-spacing **proportional to the font size**
  (0.75% of it), instead of the `115%` (`content-*`) / `120%` (`title-*`)
  and the flat, non-scaling `--tracking-normal: 0.75px` shipped until now.
  At the sizes the library uses, the line box goes 16.1 → 21px at 14px,
  13.8 → 18px at 12px and 11.5 → 15px at 10px, while tracking goes from a
  constant 0.75px to 0.105 / 0.09 / 0.075px respectively. This affects
  every delivered component (Text, Button, Tabs, Tooltip, Dialog, Select,
  Input, SearchField, Chip, Paper, Navbar…), which is why it ships as one
  mono-subject change rather than component by component.

  `theme.css` is a generated artifact, so the fix is in the generator and
  `theme.css` was regenerated, never hand-edited (`src/tokens/PROVENANCE.md`,
  2026-08-02). Two independent pipeline defects were responsible, both
  confirmed against live read-only reads of the Figma file — the design
  source was correct all along:

  - `extract-tokens.mjs` read Figma's deprecated `lineHeightPercent`
    (a percentage of the font's own _normal_ line height) instead of
    `lineHeightPercentFontSize`. The same 150% style reports 115.38 in IBM
    Plex Sans and 120.0 in Geologica, which is exactly how both families
    ended up wrong in different ways from a single misread field.
  - `normalize-w3c.mjs` typed the `Letter-spacing/*` primitives as
    `dimension`, appending `px` to a bare number whose Figma semantics is a
    percent of font size. It is now normalized to a ratio and emitted as
    `em`; `transform-tailwind.mjs`'s bare-number fallback was flipped from
    `px` to `em` in the same commit so the trap cannot be re-armed.

  Token values only — no API, class name or component markup changed, and no
  token was renamed or removed. Fixed-height boxes are unaffected
  (measured in a real browser, both modes): `Select` items stay 32px and its
  viewport still shows exactly 5 items, `Tabs` triggers stay 44px, chevrons
  stay centred. Text simply runs slightly narrower and breathes more
  vertically — the Figma-true rendering.

- 41a0a57: Fix the git-dependency install path (#63) to also work under Yarn Berry
  (v2+), which both OpenAEV and OpenCTI run. Previously, `yarn add
"@filigran/design-system@github:XTM-Foundation/filigran-design-system#<sha>"`
  failed with `Assertion failed: Unsupported workflow`: absent a
  `packageManager` field, Yarn detects a git dependency's package manager by
  lockfile (`yarn.lock` → `package-lock.json` → `pnpm-lock.yaml`), and it has
  no install workflow for pnpm at all — which this repo's root
  `pnpm-lock.yaml` was falling back to.

  Fixed by:
  - Removing the root `packageManager` field (pnpm version now pinned via
    `engines.pnpm` instead, which pnpm enforces as a hard failure on
    mismatch).
  - Adding a root `yarn.lock` solely so Yarn's own detection resolves to
    "Yarn" before reaching the pnpm fallback — it does not drive local
    development, which stays on pnpm.
  - Adding a `prepack` script (Yarn's `pack --install-if-needed` bootstrap
    never calls `prepare`) that mirrors the existing `prepare` build.
  - Fixing the root `files` field (`dist` → `dist/**`) — Yarn's own pack-list
    algorithm does not recurse into a bare directory entry the way npm/pnpm
    do, so CSS, type declarations and source maps were silently dropped from
    the packed tarball under the un-globbed form.

  No change to the published component API, import surface, or the
  npm/pnpm install path (both re-verified end to end from blank external
  projects). Consumers on Yarn additionally need
  `approvedGitRepositories: ["https://github.com/XTM-Foundation/filigran-design-system.git"]`
  in their own `.yarnrc.yml` — see README.md "Yarn (Berry / v2+) setup" and
  AGENTS.md "Consumers" § "4. Installation status" § "Yarn" for the full
  consumer-side setup.

- 278508e: fix(scripts): verify RESOLVED font-weight in check-figma-fidelity.ts, not textual substrings

  `check-figma-fidelity.ts` verified `expectedClasses` with `tsxSource.includes(expectedClass)`
  — a whole-file substring search with no notion of which variant it was checking, and no
  concept of a "real applied class" vs. any matching text. This is exactly how the decomposed
  typography pattern (`font-<name> text-<name> leading-<name> tracking-<name>`, used whenever a
  component needs a Named Style without the single bundling `@utility <name>` class) shipped
  silently missing its font-weight across 6 components: `font-<name>` only ever resolves
  theme.css's `font-family` custom property, never the sibling `--font-weight-<name>`, and the
  gate had no way to notice the weight was never actually applied — the family class name being
  present as _text somewhere in the file_ was enough to pass.

  **New: AST-scoped class extraction (`scripts/lib/tsx-classnames.ts`).** Indexes classes using
  the TypeScript compiler API, strictly from `className=` JSX attributes, `cn(...)` call
  arguments, and `cva(...)`'s base classes + per-variant `variants.<group>.<key>` entries +
  `compoundVariants[].className`/`.class` — never from comments or unrelated string literals
  (prop values, icon names, etc.). Scoped per-variant wherever the AST shape allows it (falls
  back to whole-file indexing for components not using `cva`).

  **Check #4 (`expectedClasses` presence)** now looks up the AST index instead of doing a
  substring search — fixes the blind spot where an `expectedClasses` entry could match a code
  comment or an unrelated attribute's value instead of a real applied class.

  **New check #5 (resolved font-weight cross-check).** For every variant whose spec declares
  `tokens["font-weight"]`, resolves that token through theme.css (parsed live from the compiled
  custom properties — no hardcoded class↔token table) and confirms at least one of the variant's
  _real_ applied classes independently resolves to that same numeric weight. This is what catches
  the actual incident shape even when the family class **is** correctly listed in
  `expectedClasses` and matches: check #4 passing only proves the class-name text is present,
  never that it carries the intended weight.

  **`Text.figma.json` backfilled**: added `tokens["font-weight"]` (base literal token, e.g.
  `--font-weight-semibold`) and the matching real weight-utility class in `expectedClasses` for
  its 14 non-regular-weight variants (18 spec'd variants checked in total — `content-code` has no
  Figma node reachable from this pass and is intentionally left unspec'd rather than guessed; see
  AI-BACKLOG.md).

  **Collateral fixes surfaced by the hardening** (kept in this same patch — direct precedent:
  the Navbar `.figma.json` stale-field cleanup in LEARNINGS-ARCHIVE.md):
  - `tsx-classnames.ts`: `Icon.tsx`'s bare numeric `cva` variant keys (`{16: ..., 20: ..., 24:
...}`) were silently dropped by the AST walker's property-key handling; `IconButton.tsx`'s
    `compoundVariants` (its only source for variant×priority classes like
    `bg-filigran-brand-primary`) were never traversed at all. Both are extraction-completeness
    fixes in the walker, not component behavior changes.
  - `ProductSwitcher.figma.json`: removed 2 `expectedClasses` entries on the "chevron button"
    variant that were never real classes — one matched a code comment, one matched an icon-name
    prop value (`size="sm"` and `chevron-down`). Exactly the substring blind-spot this gate now
    closes.
  - `SearchField.figma.json`: 4 `expectedClasses` entries were missing their real Tailwind state
    prefixes (`hover:`/`focus-within:`) — the bare, unprefixed names only matched by substring
    against the real `hover:border-input-hover`/`focus-within:ring-focus` classes.

  **Tests**: `scripts/lib/tsx-classnames.test.ts` (extraction module, including the two walker
  regressions above) and `scripts/check-figma-fidelity.test.ts` (gate-level, exercised against
  the real theme via `loadTheme()` — proves RED for the literal incident shape, the "class listed
  but resolves to the wrong weight" case, and non-vacuity across variants sharing a class name).
  Both wired into a new `pnpm test:scripts`, itself called from `pnpm pr:ready` and both CI
  workflows.

- 7e7b417: feat(header): add Figma's leading separator to HeaderGroup, opt-in

  Design feedback from Samuel, validated by Sandy: the bar was missing a vertical
  rule between clusters. Sandy updated the Figma, and the rule now ships from the
  library rather than from each product — node
  [`6968:20936`](https://www.figma.com/design/0PmhuZzF9XcaIEfMMW2a51/Design_System_2026?node-id=2823-1330)
  (`Vector 27`) is its whole specification.

  `HeaderGroup` gains one boolean prop:

  ```tsx
  <HeaderGroup>
    <Button variant="ia" priority="tertiary">
      Ask Ariane
    </Button>
    <HeaderGroup separatorBefore className="gap-0">
      {accountMenu}
    </HeaderGroup>
  </HeaderGroup>
  ```

  Every value comes from the node: 1px thick, `--border-elevation-subtle` (bound
  on the vector itself, the same token as the bar's own bottom hairline) at 50%
  opacity, the height of the action row — **not** the bar's 68px — and 16px of
  clear space on each side.

  **Nothing changes for an existing consumer.** The prop defaults to `false`, and
  the node draws the rule between one specific pair of clusters in one specific
  bar, so a default-on rule would have appeared in OpenCTI, OpenAEV and the docs
  shell, none of which asked for one. A test asserts both halves of that: a
  cluster rendered without the prop carries none of the rule's classes, and every
  class it carried before is still present with the prop on.

  **The rule is decorative and is drawn as a `::before`.** That is stronger than
  `aria-hidden` on a rendered element: there is no DOM node at all, so nothing to
  announce, nothing for Tab to reach, and no `role="separator"` for a later
  refactor to attach. It is also what makes the geometry hold — a rendered flex
  sibling would take its spacing from the parent cluster's `gap`, drawing 16px of
  clear space in a `gap-2` cluster and none in the `gap-0` one Figma binds on
  `Access`.

  **Two findings that are escalated rather than silently resolved.**

  - **The node puts the rule on a different side than the request described.** The
    feedback described a rule between the base actions and the IA buttons. The
    node puts it _after_ the IA button, between IA and the account cluster; the
    base-actions cluster sits before the IA button with no rule. The component
    implements the node. The side is pinned by its own test, because a `border-r`
    spelling would still look like a separator in a screenshot while separating
    the wrong two clusters.
  - **The `Right` frame's own gap moved from `--spacing-2` to `--spacing-4`**
    (8px → 16px) in the same Figma update. `HeaderGroup` keeps `gap-2`: a
    cluster's gap governs every child it holds, so following it would re-space
    existing bars as a side effect of adding a rule. Recorded as GAP-H10 for
    arbitration, with the separator's own 16px supplied independently either way.

  Also recorded: the 50% opacity is bound to no variable (GAP-H9, resolved through
  the native opacity utility exactly as the background layer's 94% was), and the
  node defines no separator behaviour when the bar compresses (GAP-H11 — the
  vector is `shrink-0`, so the rule ships at 1px at every width).

  Documented in `Header.rfc.md` §3.7, specified in `Header.figma.json`, and shown
  with and without the rule on the Header documentation page.

- f86e76e: fix(header): follow the node's 24px leading padding — the bar's padding is no longer uniform

  Sandy moved the bar's `padding-left` from 16px to 24px on Figma node
  `2823:1330`. The other three sides are unchanged, so the padding stops being a
  uniform `p-4`: `--spacing-6` (24px) on the leading edge, `--spacing-4` (16px) on
  the top, right and bottom.

  Read at the ROOT of the node by the two independent means
  `Header.figma.json`'s `_note` prescribes — `get_design_context`, which now emits
  `pl-[var(--spacing-6,24px)] pr-[var(--spacing-4,16px)] py-[var(--spacing-4,16px)]`,
  then `get_variable_defs` on the same root, which now returns `--spacing-6` = 24
  where it previously did not — and corroborated by the node's own geometry rather
  than by the code output alone: the first visible child sits at x=24 inside the
  997px-wide symbol and the trailing cluster's right edge at 981.

  **Every `Header` moves its leading content 8px right.** Measured in Chrome on
  the compiled CSS, in both themes: computed padding
  `16px 16px 16px 24px`, and the first cluster's left edge lands at exactly 24px
  from the bar's own left edge (was 16px). Nothing else moves — the bar stays
  68px tall and `border-box`, the trailing inset stays 16px, both cluster gaps
  stay 8px, the backdrop blur stays 4px, and the opt-in leading rule is
  byte-identical (1px, `--border-elevation-subtle` at 50%, 36px tall, 16px clear
  on each side, its own `ml-2`/`pl-4` untouched). A full geometry snapshot of
  every bar the docs site renders — 958 measured values across both themes —
  differs in exactly three places: the padding itself, the resulting inset, and
  the x of the clusters that inset moves.

  Written as `py-4 pr-4 pl-6` rather than `p-4 pl-6`: the two render the same
  today, but the second leaves the leading value to `tailwind-merge`'s conflict
  resolution, and this library has already shipped a class silently dropped that
  way. A consumer's own `p-*`/`pl-*` override through `className` behaves
  identically against either form.

  Nothing in the public API changes, and no consumer that already lets the
  component own its padding has anything to edit.

- 359ab8c: fix(input): paint the placeholder with --text-default-secondary, as the node binds

  The empty field was rendering at the typed value's brightness. Consumers see a
  placeholder that is now legibly dimmer than a real value; no API change.
  Reasoning: `Input.rfc.md` §9 and `Input.figma.json`.

- 5258f45: fix(button, icon-button): declare the hover states as measured contrast pairs, and put the glyph bar back at 3:1

  The nine `scripts/contrast-coverage-allowlist.json` entries covering Button and
  IconButton, added 2026-07-24 and expiring 2026-08-31, are replaced by real
  `contrastPairs`. Those entries recorded that a rendered token had **no declared
  pair** — not that the pair had been measured and passed. Nobody had measured
  them, which is how a genuine failure sat behind a green gate for five weeks:
  Button's `default × primary` hover label read **3.60:1 in dark** against a 4.5
  minimum, on the most-used button in the library.

  That one is fixed at the source rather than derogated — the 2026-08-25 token
  export moved `--color-filigran-brand-tertiary` `blue-700 → blue-600`, taking the
  pair to **5.79:1** dark (light was never affected, 16.86:1).

  IconButton's `primary-icon` pair also moves from `minRatio: 4.5` to `3`. An icon
  is a non-text UI component and WCAG 1.4.11 governs it at 3:1; this component
  renders no text at all. The over-requirement was not harmless — it made the
  component hold its rest glyph to a bar its own hover glyph could not meet, which
  is why the hover pairs were parked in the coverage allow-list rather than
  declared.

  One pair did not clear on measurement: `destructive secondary·tertiary
hover/active` computed **4.490:1** in light against a 4.5 minimum — a real
  failure by 0.01, on a knife-edge (4.490 unrounded, 4.504 composited to 8-bit
  channels as a browser paints it).

  It was fixed at the source rather than derogated or rounded away. Design added
  `--color-feedback-error-secondary-transparency-20` (2026-08-26 export, #162),
  and Button and IconButton now bind it for the destructive secondary/tertiary
  hover, active and pressed fills: **4.927:1 dark / 4.929:1 light**. The alpha
  moved, not the hue and not the label. `--color-feedback-error-secondary-transparency-30`
  is untouched and still serves Chip and ProgressBar, which declare it for
  themselves.

- 2d4b6e5: fix(menu): keep the keyboard focus ring off rows the pointer highlights

  Hovering a `MenuItem` (and a collapsed `NavbarSubmenu` flyout row) painted the
  keyboard focus ring, because Radix focuses those rows from `pointermove`. The
  pointer highlight is unchanged. Mechanism: `src/lib/pointer-nav.ts`.

- 5880796: fix(menu): give a wrapped MenuItem label 4px clear of the row's edges

  A `MenuItem` whose label wraps past the panel's 300px cap grew its row, as
  RULE-05 and RULE-06 require, but the row had no vertical padding at all — a
  two-line label filled its 42px box edge to edge and sat flush against both
  boundaries. The row now carries `py-1`.

  It costs a single-line row nothing. A 14px label on a 1.5 line height is a
  21px box, so the row wants `21 + 4 + 4 = 29px` and stays under the 36px
  floor `min-h-9` sets. Every existing row renders at exactly the height it did
  before, `ProductSwitcher`'s included.

  `py-1`, not the `py-2` the Figma node itself binds: `21 + 8 + 8 = 37px`
  exceeds the `h-[36px]` bound on that same node, so following the padding
  would have cost every row in the library 1px in order to serve the roughly
  3.5% of real product labels that wrap. The node overrides its own autolayout
  padding with a fixed height; CSS cannot, so the two declarations have to be
  reconciled rather than copied.

  The arithmetic is asserted against compiled theme values in
  `scripts/lib/menu-row-padding.test.ts`, so a change to `--spacing`,
  `--text-3` or `--leading-normal` fails a test instead of silently
  invalidating the reasoning.

  Also documented, as a transverse rule rather than a local decision
  (`Menu.rfc.md` §6.4): truncate when the width is imposed from outside the
  component, wrap when the container sizes itself to its content. That is why
  `NavbarItem` and the `Select` trigger truncate while `Select`'s content rows
  and `MenuItem` labels wrap — a split that had looked like inconsistency and
  is not.

- b0d40a6: fix(navbar): tighten the rail's vertical rhythm to the Figma density

  The OpenAEV pilot was losing visible entries to vertical space the design
  never asked for. Re-read from the two reference frames Sandy adjusted for
  this pass — `6668:12107` (dark reference frame) and `6668:12108`
  (light reference frame), both modes, geometry identical in the two — three
  bindings did not match what shipped:

  - separator vertical padding is `--spacing-1` (4px per side), not 8px:
    `NavbarSeparator` goes from `my-2` to `my-1`;
  - the `Menu` container binds no gap at all and its rows sit contiguously, so
    the `gap-1` on the content list and on the footer column is removed —
    group separation is carried by `NavbarSeparator` alone, as Figma intends;
  - the `Submenu` container binds `bg-[var(--bg-elevation-default)]`, so an
    expanded submenu group now paints its own backdrop instead of showing the
    rail's gradient through it. The collapsed flyout already had this fill and
    is untouched; the trigger row deliberately stays on the gradient, exactly
    as in Figma.

  The same pass fixes a defect the pilot reported alongside the density
  complaint, and which the density change would otherwise have made easier to
  hit: rows visibly compressing past a certain number of entries. The content
  list is `overflow-y-auto`, so its children are flex items with the default
  `flex-shrink: 1`, and `h-9` is a size an item shrinks _from_, not a floor —
  measured in real Chromium at 21px instead of 36px in the worst case. Figma
  binds `shrink-0` on every child of `Menu`; it is now applied on `NavbarItem`,
  `NavbarSeparator`, `NavbarSubmenuItem` and the submenu's accordion root, so
  the 36px row height is a guarantee.

  Measured effect, real Chromium, on a realistic 15-entry rail (12 rows +
  3 submenu groups, split into 5 groups by 4 separators): the same entries now
  need 601px of list instead of 717px — 116px recovered, −16.2%, i.e. 3.2 rows
  of 36px. In a 720px rail that is 15 entries fully rendered at 36px instead of
  12, identically in both rail states. Against the code as shipped (density and
  the missing `shrink-0` together) the same rail goes from 3 correctly-rendered
  entries to 15.

  Removing the gap has one consequence outside spacing, handled here too: the row
  focus indicator is `ring-2` + `ring-offset-2`, i.e. 4px of box-shadow painted
  outside the border box, which is exactly what the old 4px gap used to hold. With
  rows flush and every row `relative` at `z-index: auto`, a selected or hovered row
  directly below the focused one would paint over its ring. `NavbarItem` and
  `NavbarSubmenuItem` therefore carry `focus-visible:z-10`. Stacking order only —
  no geometry and no token change.

  Visual change only, no API change: `patch`. Consumers relying on the previous
  looser spacing will see their rails get denser — that is the intent.
  `ProductSwitcher` and `Tabs` geometry are byte-identical before and after
  (re-measured element by element in headless Chromium), and all contrast pairs
  were recomputed for the new submenu backdrop: 8.99:1 dark / 7.89:1 light, no
  regression.

- 0472f45: Remove the navbar rows' hover left accent — it painted a white bar in dark mode.

  Both rail levels dropped `hover:border-l-text-default-primary`. That token
  resolves to `#f2f2f3`, so the hover state drew a white vertical bar down the left
  edge of every row in dark mode, which is what the real render showed. The
  maquette had pointed the accent at the wrong token; @sandy corrected both
  component sets (`navbar menu item` 2837:13147 / `navbar submenu item`
  2837:14715) by REMOVING the accent rather than repointing it, so hover is now a
  background and nothing else.

  Everything else about hover is unchanged and re-verified against the same read:
  the background stays `--bg-elevation-highlight`, the first level's icon still
  brightens to `--icon-default`, and the second level's label and icon still keep
  their resting tones. The other four states on both levels are untouched.

  No layout change. The 2px border reserved on all four sides is unchanged — only
  its colour was ever toggled — and geometry was measured across all five states on
  both levels in both themes: one border-box value, one border width, one content
  offset per level, identical everywhere.

  The `@utility border-l-text-default-primary` added for that accent is removed
  with it: nothing else used it, and it no longer appears in the compiled CSS.
  Hosts that referenced the class directly (there is no reason to, it was internal)
  would need to drop it.

- 3bee101: fix(navbar): truncate long rail labels with an ellipsis and a tooltip, never a wrap

  Long labels on `NavbarItem` and `NavbarSubmenuItem` now cut with an ellipsis at both
  levels and expose the full label on hover/focus; the accessible name is unchanged. The
  rows' hover background also moves to `--bg-elevation-hover`. Doctrine: `NavbarItem.rfc.md` §3.7.

- 2951492: Demo the five rail states with icons at both navbar levels, and guard the icon
  tone in a real browser.

  No component behaviour changes. The submenu row's per-state icon tone was
  re-read at the root of its component set and re-measured in the rendered DOM
  first: label and icon already resolve to the same colour in all five states, in
  both themes, on both surfaces the row renders on (the expanded accordion and the
  collapsed flyout panel). Measured tones, dark then light — default `#afb0b6` /
  `#494a50`, hover and focus unchanged from default, selected `#42caff` /
  `#0015a8`, disabled `#a0b4e3` / `#2b4f8d`, icon equal to label in every cell.

  What was missing was a way to SEE that. Both demos put an icon on a resting row
  only, so "selected with an icon" and "disabled with an icon" were unreachable on
  the documentation site and a per-state icon tone could drift without anything
  visible changing there. Both demos now show all five states with an icon on
  every row, the submenu one repeats them inside the collapsed flyout, and the two
  levels are captioned so their deliberate difference reads as a rule rather than
  as an inconsistency: the second level's icon takes the tone of its own label in
  every state, the first level's is subtle under a primary label at rest and
  brightens once the row is active.

  Hover and focus stay live rather than pinned by a forced class, because at the
  second level neither state retones anything — pinning them would paint a tone
  the component never applies.

  A new browser test measures the resolved colours on the published demo and pins
  the exact expected set, both levels, both themes, both surfaces. The existing
  source-level guard reads class lists and resolves tokens, which can be green
  while the rendered colour is something else — that is exactly what happened once
  on this element, when an unlayered `a { color: inherit }` reset in a consuming
  app beat the row's own utility class.

- b0327e5: Floating surfaces read their stacking order from `var(--fds-z-overlay, 50)`
  instead of a hardcoded `z-50`, so a host can lift the whole library above its
  own chrome (MUI `AppBar` is 1100) with one `:root` declaration.
- fc24f4b: Publish `dist` as one module per source module instead of one bundled chunk, so
  consumer tree-shaking works.

  `tsup` was bundling every component into a single ~1.2 MB chunk that
  `dist/index.mjs` merely re-exported. Inside one module a top-level
  `forwardRef(...)` / `cva(...)` call cannot be proven side-effect-free, so a
  product's bundler could drop nothing. Measured with the products' own bundler
  (vite 8 / rolldown, `react` external, minified), on real `pnpm build` output
  before and after:

  | Consumer imports       | Before   | After    |
  | ---------------------- | -------- | -------- |
  | every export           | 600.6 KB | 600.6 KB |
  | five components        | 583.8 KB | 242.4 KB |
  | one component (`Text`) | 583.8 KB | 48.8 KB  |

  `bundle: false` also stops Radix, `lucide-react` and `tailwind-merge` from being
  copied into `dist`: they stay bare imports the consumer resolves from its own
  `node_modules`, which is what declaring them in `dependencies` is for.

  Non-breaking. The `exports` map, both entry points, the `/meta` subpath, the CSS
  subpaths and the bundled `dist/index.d.ts` / `dist/meta.d.ts` are unchanged, and
  the runtime and `/meta` export surfaces were diffed name by name across the two
  builds: 97 and 39 exports, identical.

- 9c57023: fix(product-switcher): hover on the dedicated hover token, and document the row's logo slot

  The collapsed rail control now hovers on `--bg-elevation-hover` like the rail rows
  (#107), and `options[].logo`'s prop doc states the 100px slot width it lands in —
  the gap that made a pilot size its wordmarks for the trigger's 126px slot.

- 36e4039: feat(components): promote 10 components beta -> stable

  `ComponentMeta.status` flipped `beta` → `stable` for: **Icon**, **Tabs**,
  **Tooltip**, **IconButton**, **SearchField**, **Text**, **Navbar**,
  **NavbarItem**, **NavbarSubmenu**, **ProductSwitcher**.

  Each promotion was run through `pnpm promote:component <Name>` (never
  hand-edited), which re-verifies stable eligibility itself
  (`scripts/lib/stable-eligibility.ts`: was `beta`, CI-confirmed
  `accessibility.wcagStatus: "pass"`, no matching entry in
  `scripts/wcag-allowlist.json`) and stable-tier docs completeness
  (`scripts/lib/docs-completeness.ts`: full description, ≥1 usage
  example, every prop documented, `figmaLink` present) before touching
  anything. All 10 passed both checks against the actual, current-main
  gate output — not inferred from source reading.

  Non-blocking notes carried over from arbitration (informational only,
  do not affect eligibility as the gates are written today): **Tabs**
  has no committed `Tabs.figma.json` (`LEGACY_WITHOUT_SPEC`, predates the
  figma-fidelity gate); **Tooltip**/**IconButton**/**SearchField** each
  ship a `Status: draft` RFC (`*.rfc.md`) alongside an already-committed
  `*.figma.json` — `check-figma-fidelity`'s RFC-approval rule only
  applies when a `figma.json` is _absent_, so the draft status never
  triggers a blocking rule for these three; tracked as separate process
  debt in `AI-BACKLOG.md`.

  **Button is intentionally excluded** — `accessibility.wcagStatus` is
  `"fail"` and it carries an active `scripts/wcag-allowlist.json` entry
  (expires 2026-08-31); either alone blocks stable per the STABLE GATE
  (`AGENTS.md`), and stays `beta`.

  No prop, variant, or token changed — this is a status-only promotion
  (observable in the published `ComponentMeta`, per-component docs pages,
  and `README.md`/`llms.txt`/`llms-full.txt`), hence `patch` rather than
  `minor`/`major` — bump policy category added in the same PR
  (`process/PLAYBOOK.md`).

  Arbitrated line-by-line by Sandy, workstream
  `roadmap-sync-status-promotions`, 2026-07-24.

- ef95c26: fix(styles): make every component self-defensive against browser UA defaults

  `dist/index.css` intentionally ships without Tailwind preflight, so a host
  without its own CSS reset let the browser's user-agent stylesheet fill every
  property a component never declared. Measured in OpenAEV: every library button
  — the Navbar collapse toggle first — painted on Chromium's native `buttonface`
  grey `rgb(239, 239, 239)` inside a 2px `outset` border; `<hr>` separators
  rendered 2px inset, `<input>`s fell back to `13.3333px Arial`, `Text` links
  turned `rgb(0, 0, 238)`, headings/paragraphs regained UA margins, and every
  fixed-size box grew by its own padding under `content-box`.

  Each affected component now restates locally what a reset would have provided
  (`bg-transparent`, `border-0`, `p-0`/`m-0` ahead of its real spacing,
  `box-border`, `text-inherit`, the `font-*`/`leading-*` inheritance chain on
  controls, `align-middle` on `Icon`) — nothing global, so MUI/emotion hosts stay
  untouched. Every added class is a verbatim restatement of what preflight does,
  so hosts that already ship one render exactly as before: measured in real
  Chromium, 486 computed properties change in a bare host and zero rendered
  properties (and zero geometry) change in a preflight host.

  `appearance` is deliberately left alone: preflight declares `appearance: button`,
  which is the value Chromium already computes for a bare `<button>`, so neither
  its presence nor its absence changes rendering — while forcing `appearance:
none` would.

  `DialogTrigger`, `DialogClose` and `TooltipTrigger` were previously re-exported
  as raw Radix primitives; they are now wrapped so their default (non-`asChild`)
  native `<button>` is defended too. On the `asChild` path the defense is
  deliberately skipped — Radix's `Slot` concatenates `className` without
  tailwind-merge, and the child element already carries its own.

  Regression-locked by `src/__tests__/no-preflight-host.test.tsx`, which renders
  the components against the real compiled library CSS plus Chromium's UA
  form-control stylesheet, with no reset in between. See `README.md`
  § "Host Integration".

- 584d236: fix(tokens): let element children keep their own fill inside a gradient label

  An element nested in an `ia`/`highlight` Button label (a `Chip`, an inline `Icon`,
  a `Spinner`) is now filled with the colour it resolves for itself, not the label's
  transparency; text-only gradient labels render pixel-identically. Origin: OpenCTI
  LIBRARY-FEEDBACK #25.

- 2ed8ba7: chore(i18n): translate remaining French content in the package to English

  Two comments in `Text.tsx` and `cn.test.ts` citing the Text RFC's
  arbitration title were still in French; both now read "already-settled
  arbitration", matching the RFC's own translated heading. No perceptible
  API/behavior change — comment/citation text only, part of the repo-wide
  English-only sweep (AGENTS.md; new `pnpm check:language` gate).

- b838d43: fix(tokens,button,icon-button): WCAG 2.1 AA contrast remediation for interactive components

  Figma-sourced token refresh bringing the interactive components' non-text and
  hover states to WCAG 2.1 AA (3:1 non-text / 4.5:1 text) across both themes.
  Key value changes: brand-primary `blue-500 → blue-400` and brand-tertiary
  `blue-600 → blue-700` (Button/IconButton hover + Slider + Switch ON),
  error-tertiary `red-200 → red-300` (destructive hover, paired with the
  Button/IconButton `error-secondary → error-tertiary` hover swap), neutral
  re-mapping (Slider rail + Switch OFF track, previously failing 2.63:1 in light,
  now ≥3:1), and light tonic-primary `turquoise-600 → turquoise-700`.

  Button `highlight` variant: in light mode the label now renders solid
  brand-primary (11.22:1) instead of the failing text gradient (design decision
  @fimow 2026-07-30); the dark-mode gradient is unchanged (8.06:1) and the border
  gradient is kept at 2px.

  Also stabilises the recurring `--gradient-default` Figma export defect: the
  90deg correction is now applied durably in the token generator
  (`scripts/extract-tokens/transform-tailwind.mjs`) rather than hand-patched after
  each export, and a generator regression test locks the angle. No token renamed
  or removed.

## Pre-npm history

Everything below this heading predates the first publication to the npm
registry. It was maintained by hand at the repository root. Released versions
are added above this heading by `changeset version`, newest first, and are
compiled from the files contributors add under `.changeset/`.

### Unreleased at the time of the first publication

- Audit-foundations tooling (2026-07): executable WCAG gate, computed
  contrast verification, token-enforcement lint, generated artifacts
  (llms.txt / README components / docs registry), `ComponentMeta.examples`,
  `ComponentMeta.accessibility.contrastPairs`, changesets + Prettier setup.

### 0.1.0 — pre-release baseline

- Token system (`theme.css`, Figma-generated): primitive + semantic layers,
  dark/light modes, elevation layer classes, gradients, typography styles.
- Button component (beta — WCAG failures documented in its meta; rebuild
  from the real Figma guidelines scheduled).
- Tabs component (beta): compound Radix-based tabs with icon/badge/asChild.
- Dual CSS distribution: `dist/index.css` (pre-compiled, no preflight) and
  `dist/tokens/theme.css` (`@theme` source for Tailwind v4 consumers).
- AI-first documentation: AGENTS.md, llms.txt, llms-full.txt, per-component
  `.meta.ts` contracts, docs Next.js app.
